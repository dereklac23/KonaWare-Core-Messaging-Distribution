package konaware.util;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ParserWrapper {
	enum TOKEN_HEAD_TYPE {SearchFile, ListFile, OpenFile, WriteFile, DeleteFile};
	
	public ParserWrapper () {
		
	}
	public boolean parse(String line) {
		
		return true;
	}
	
	
	
	private class ParserEnum {
		String label=null;
		TOKEN_HEAD_TYPE tht;
		Pattern pat = null;
		
		public ParserEnum(String _label, TOKEN_HEAD_TYPE _tht, String _compileSyntax) {
			label = _label;
			pat  = Pattern.compile( _compileSyntax);
			tht=_tht;
		}
		
	}
	
	private class ParserEngine {
//		 HashMap <String, KWMap > hashP = new HashMap<String, KWMap>();
		ArrayList <ParserEnum> parserArray= new ArrayList<ParserEnum>();
		public ParserEngine() {
			 for (int i=0; i < TOKEN_HEAD_TYPE.values().length;i++) {
				 ParserEnum pe  = new ParserEnum("SearchFile", TOKEN_HEAD_TYPE.SearchFile, "SearchFile*"); 
				 parserArray.add(pe);
			 }
		}
		public ParserEnum match(String _line) {
			Iterator iter = parserArray.iterator();
			while (iter.hasNext()) {
				ParserEnum peItem=(ParserEnum)iter.next();
				Matcher match1 = peItem.pat.matcher(_line);
				if (match1.hasMatch()) {
					return peItem;
				}
			}
			return null;
		}
		
	}
}
