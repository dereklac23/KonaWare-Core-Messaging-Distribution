package starship.atom;

public interface AtomInterface {
    public String token=null;
	abstract AtomInterface getValue();
	abstract String getToken();
	int getIntValue();
	String getStringValue();
	
	
}
