package starship.util;

import javax.swing.JTextArea;

public class StateOperationException extends Exception {
    private String errorString=null;
	public StateOperationException  (String es) {
		super();
		errorString = es;
	}
	public void print(JTextArea _taOutput) {
		_taOutput.append("\nerrorString");
	}
	
}
