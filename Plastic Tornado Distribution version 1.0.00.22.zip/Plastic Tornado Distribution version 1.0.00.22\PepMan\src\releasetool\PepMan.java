package releasetool;
import releasetool.gui.*;
import releasetool.gui.ButtonSelection.BSTypeDistribution;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;





public class PepMan implements ChangeListener {
	

	private static PepMan releaseTool =null;
	public  enum PANEL_TYPE {  SETTINGS,DISTRIBUTION, CUBE_CONTROL, PVM, HELP};
	private String targetDirString="d:\\dev";
	PathUtil pathSettings=null;
    PathUtil pathHtml =null;
	private HTMLOutput htmlOutput=null;
	
	
	JComboBox<ButtonSelection> jCombo[];
	JComboBox comboPointer=null;
	private PanelStruct panelArray [] = new PanelStruct[PANEL_TYPE.values().length];

	public ButtonSelection selectPointer= null;
	JPanel framePanel=null;
	private JFrame globalFrame=null;
	public  PepMan() {
		
		    globalFrame= new JFrame("PepMan");
		    framePanel = (JPanel) globalFrame.getContentPane();
	        globalFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        globalFrame.setSize(700, 650);
	        // Add a label to the frame
	        JLabel label = new JLabel("Release Tool!", JLabel.CENTER);
	        framePanel.setLayout(new BorderLayout());
	        

	        


   
	        
	        jCombo = new JComboBox[PANEL_TYPE.values().length];
	        jCombo[PANEL_TYPE.SETTINGS.ordinal()] = new JComboBox ();
	        jCombo[PANEL_TYPE.SETTINGS.ordinal()].setRenderer(new ComboRenderer(this));
	        jCombo[PANEL_TYPE.DISTRIBUTION.ordinal()] = new JComboBox ();
	        jCombo[PANEL_TYPE.DISTRIBUTION.ordinal()].setRenderer(new ComboRenderer(this));
	        
	        ArrayList<ButtonSelection> listSetting = new ArrayList<ButtonSelection>();
	        listSetting.add(new ButtonSelection(ButtonSelection.BSTypeSettings.GTML,"GTML resource folder"));
	        listSetting.add(new ButtonSelection(ButtonSelection.BSTypeSettings.STAGGING,"Temporary folder for staging file for assembly"));
	        
	        listSetting.forEach(btnSetting->jCombo[PANEL_TYPE.SETTINGS.ordinal()].addItem(btnSetting));
	        
	        ArrayList<ButtonSelection> listDistribution= new ArrayList<ButtonSelection>();
	        listDistribution.add(new ButtonSelection(BSTypeDistribution.COPY_KCM,"Copy files from Stagging to Plastic Tornado Distribution."));
	        listDistribution.add(new ButtonSelection(BSTypeDistribution.COPY_TOMCAT,"Copy files to tomcat."));
	        listDistribution.add(new ButtonSelection(BSTypeDistribution.LOAD_GTML,"Load private files from GTML resource folder."));
	        
	        
	        
	        listDistribution.forEach(btnDistribution->jCombo[PANEL_TYPE.DISTRIBUTION .ordinal()].addItem(btnDistribution));
	        
	        //synchronized (globalFrame) {
	        framePanel.add(BorderLayout.NORTH, getNorthPanel());
	        framePanel.add(BorderLayout.CENTER, getCenterPanel());
	        //}
	        
	        
	        
	        
	        
	        
	        
	        
	        //globalFrame.pack();
	        globalFrame.setLocationRelativeTo(null);
	        globalFrame.setVisible(true);	    
	        
	        performProvision();	        

	}
	private LocalContainer localContainer= null;
	PathExec pathExec=null;
	
	private void performProvision() {
		pathHtml =
				new PathUtil(  
				jCombo[PANEL_TYPE.DISTRIBUTION.ordinal()],menuPackage);
		
		
		pathSettings =
				new PathUtil( 
				jCombo[PANEL_TYPE.SETTINGS.ordinal()],menuSettings);

		PathUtil pathSet[] = new PathUtil[2];
		pathSet[0]= pathHtml;
		pathSet[1]= pathSettings;
		localContainer = new LocalContainer(pathSet);
		
		
		
		pathExec= new PathExec(localContainer);
		
		File fileTarget = new File(targetDirString);
		pathExec.doExecute(localContainer,SeafloorExec.LEVEL.BASEMENT0, SeafloorExec.TYPE.PROVISION, SeafloorExec.ATTR.HTML_MAIN);
		
	
	}

	
	
	public static void main(String args[] ) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
		
	}
	private static void createAndShowGUI() {
        // Create the frame
		releaseTool = new PepMan();      
    }
	
    private JPanel controlPanel =null;
    private JButton btnGo =null;
	private JPanel getNorthPanel() {
  		controlPanel= new JPanel();
  		controlPanel.setLayout(new FlowLayout());
		   
		   btnGo=new JButton("Go");
	       btnGo.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	try {
	            	if (selectPointer==null) {
	            		 
	            	} else if (selectPointer.typeDistribution == ButtonSelection.BSTypeDistribution.COPY_KCM) {
	            		performCopy();
	            	} else if (selectPointer.typeDistribution == ButtonSelection.BSTypeDistribution.COPY_TOMCAT) {
	            		performCopyWar2Tomcat();
	            	} else if (selectPointer.typeDistribution == ButtonSelection.BSTypeDistribution.LOAD_GTML) {
	            		performLoadGtml();	            		
	            		
	            	}
	            	
	            	} catch  (KCMException kcp) {
	            		
	            	} catch (IOException ioe) {
	            		System.out.println("\nIOE"+ ioe.toString());
	            	}
	            	
	            }
	        });

		controlPanel.add(comboPointer=jCombo[PANEL_TYPE.SETTINGS.ordinal()]);
		controlPanel.add(btnGo);
		
		return controlPanel;
	}
	
	
	
	
	private MenuPackage menuPackage = null;

	private MenuSettings menuSettings=null;
	private JTabbedPane tabbedPane=null;
	private JPanel getCenterPanel()  {
		JPanel panel = new JPanel();
		tabbedPane = new JTabbedPane();			
		ComboRenderer comboRSettings = new ComboRenderer(this);
		PanelStruct panelSettings = new PanelStruct(comboRSettings,"Settings", 
				"Basement layer 1 for settings.\nExamples would be staging directories for file assembly.", KeyEvent.VK_1);
		
		panelArray[PANEL_TYPE.SETTINGS.ordinal()] = panelSettings; 
		tabbedPane.addTab(panelSettings.title,panelSettings.comp);		
		JPanel panelLayerSettings =(JPanel)panelSettings.comp;
		panelLayerSettings.removeAll();
		menuSettings = new MenuSettings();
		panelLayerSettings.add(BorderLayout.CENTER, menuSettings);
		
		
		
		
		ComboRenderer comboDistribution = new ComboRenderer(this);
		PanelStruct panelDistribution = new PanelStruct(comboDistribution,"Distribution", 
	    		"Basement layer  0 for local file  and working directory.", KeyEvent.VK_0);		
	    panelArray[PANEL_TYPE.DISTRIBUTION.ordinal()] = panelDistribution;
		tabbedPane.addTab(panelDistribution.title,panelDistribution.comp);		
		JPanel panelLayerPackage =(JPanel)panelDistribution.comp;
		panelLayerPackage.removeAll();
		menuPackage= new MenuPackage(panelDistribution, jCombo[PANEL_TYPE.DISTRIBUTION.ordinal()]);		
		panelLayerPackage.add(BorderLayout.CENTER, menuPackage);
		
		
		
		
		
		
		panel.add(tabbedPane);
		tabbedPane.addChangeListener(this);
					
		return panel;
	}
	private void performCopy() throws IOException {		
		//pathUtil.performCopy();
	}
	
  
	private void performCopyWar2Tomcat () throws KCMException {
		File fileTarget = new File(targetDirString);
		//pathUtil = new PathUtil(fileTarget, menuHtml);		
		//pathUtil.performCopyWar2Tomcat();
		
	}
	private void performLoadGtml() {
		pathHtml.loadHtmlPage();
	}
	
	private class MyModel extends DefaultComboBoxModel {
		
	}
	public class MyActionListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
	@Override
	public void stateChanged(ChangeEvent e) {
		
		int index = tabbedPane.getSelectedIndex();
		synchronized (globalFrame) {
		comboPointer=jCombo[index];
		}
		controlPanel.removeAll();
		
		controlPanel.add(comboPointer);
		controlPanel.add(btnGo);
		controlPanel.repaint();
		globalFrame.pack();
		tabbedPane.invalidate();
		
		
		// TODO Auto-generated method stub
		
	}
}


