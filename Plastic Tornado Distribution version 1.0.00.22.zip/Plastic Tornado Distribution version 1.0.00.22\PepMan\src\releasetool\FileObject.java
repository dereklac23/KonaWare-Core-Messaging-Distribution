package releasetool;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;

public class FileObject {
  File fileRoot=null;
  ArrayList<Files> fileList = new ArrayList<Files>();
  ArrayList<PageObject> pageList = new ArrayList<PageObject>();
 public FileObject(File  _root) {
	 fileRoot = _root;
 }
 public void add(File f) {
	 pageList.add(new PageObject(f));
 }
 public void processGTMLContent() {
	 
	 pageList.forEach(p->processPage(p));
	 
 }
 private void processPage(PageObject p) {
	 try {
     	 p.process();
	 } catch (KCMException kcm) {
		 System.err.println("Error in processing page of bundled jar resource");
	 }
 }


 
}
