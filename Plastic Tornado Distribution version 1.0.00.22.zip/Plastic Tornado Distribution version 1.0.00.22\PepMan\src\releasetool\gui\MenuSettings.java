package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import releasetool.LocalContainer;


public class MenuSettings extends JPanel implements MenuInterface{
	  	
	  private String htmlIndexPage=null;
	  private LocalContainer localContainer=null;
		
 public MenuSettings () {
	 
	 setLayout(new BorderLayout());
		//add(BorderLayout.NORTH, editor);
	add(BorderLayout.NORTH,new PropertiesPage(localContainer));
		//editor.setContentType("text/html");		
		//editor.addHyperlinkListener(new HCustomListener());
		//editor.setSize(new Di)
		//editor.setPreferredSize(new Dimension(500,500));
		//editor.attachHeader();		
		//editor.attachP("This is a settings page.");
		//editor.attachP("Configure the local directory for GTML loading isuing ClassLoader#getResourceFolder ");		
		//editor.attachEnder();
		//editor.printPage();	
		//add(editor);
		//JEditorPane edit2= new JEditorPane();
		//edit2.setSize(new Dimension(400,400));
	    HTMLOutput editor2= new HTMLOutput();
	    editor2.setSize(new Dimension(400,400));
	    //editor = (HTMLOutput) new JEditorPane();
	    //editor.setPreferredSize(new Dimension(200,300));
//		add(BorderLayout.CENTER, new JTextArea(20,20));
	    add(BorderLayout.CENTER, editor2);
	
	
	 
 }
	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			System.out.println("Event entered");
			// TODO Auto-generated method stub
			
		}
	
	}

}
