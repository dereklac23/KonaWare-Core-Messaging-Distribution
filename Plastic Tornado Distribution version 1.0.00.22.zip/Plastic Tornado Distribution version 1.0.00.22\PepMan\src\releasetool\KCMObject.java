package releasetool;

import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class KCMObject {
    public File directoryPointer=null;
    
    private final static String  PREFIX="Plastic Tornado Distribution version ", KMP="KMP.war", KonaWare ="StarShip.jar", PepMan ="PepMan.jar", 
    		DEV_ROOT="D:\\dev";
    private File fileKMP, fileKonaWare, filePepMan;
    
    public KCMObject targetDirectory=null;
    public DirectoryObject directoryObject=null;
	
	public KCMObject(DirectoryObject _do) {
	 	directoryObject =  _do;
	}  
    
    public KCMObject(File root, String name) throws KCMException {
		directoryPointer = new File(root, name);
		if (!directoryPointer.isDirectory()) {
			throw new KCMException("\nroot has to be a directory");
		}
		Matcher matcher=compile(PREFIX+"(\\d+)\\.(\\d+)\\.(\\d+)\\.(\\d+)", name);
		directoryObject  = new DirectoryObject(directoryPointer,PREFIX,matcher);
	
	}
	public KCMObject(File root,  KCMObject kObj) {
		fileKMP = new File(root, KMP);
		fileKonaWare = new File(root, KonaWare);
		filePepMan = new File(root, PepMan);
		targetDirectory = kObj;
		
	}
	

	
	
	public KCMObject () {
		directoryObject = new DirectoryObject();
	}
	
    public void performCopy() throws IOException {
    	File targetKMP = new File(targetDirectory.directoryObject.docRelease, KMP);
    	File targetKonaWare = new File(targetDirectory.directoryObject.docRelease, KonaWare);
    	File targetPepMan= new File(targetDirectory.directoryObject.docRelease, PepMan);
    	
    	System.out.println("\ntargert KMP:"+ targetKMP.getAbsolutePath());
    	System.out.println("\ntargert KMP:"+ targetKonaWare.getAbsolutePath());
    	 
    	System.out.println("\nfile StarShip:"+ fileKMP.getAbsolutePath());
    	System.out.println("\nfile StarShip:"+ fileKonaWare.getAbsolutePath());

    	
    	System.out.println("\nfile PepMan:"+ fileKMP.getAbsolutePath());
    	System.out.println("\nfile PepMan:"+ fileKonaWare.getAbsolutePath());

    	Files.copy(
    			
    			Paths.get(fileKMP.getCanonicalPath()),
    			Paths.get(targetKMP.getCanonicalPath()), 
    			StandardCopyOption.REPLACE_EXISTING);
    	Files.copy( 
    			Paths.get(fileKonaWare.getCanonicalPath()),
    			Paths.get(targetKonaWare.getCanonicalPath()), 
    			StandardCopyOption.REPLACE_EXISTING);
    	
    	Files.copy( 
    			Paths.get(filePepMan.getCanonicalPath()),
    			Paths.get(targetPepMan.getCanonicalPath()), 
    			StandardCopyOption.REPLACE_EXISTING);
    	
    	
    }
    public void performCopyWarBinaries() throws IOException {
    	File devRoot = new File(DEV_ROOT	);
    	File warSourceFile = new File(devRoot, KMP);
    	warSourceFile.isFile();
    	String warFileStr= warSourceFile.getCanonicalPath();
    	File targetKMPWarFile = new File(directoryObject.fileDirectoryTarget, KMP);
    	Files.copy(
    			Paths.get(warFileStr),
    			Paths.get(targetKMPWarFile.getCanonicalPath()),
    			StandardCopyOption.REPLACE_EXISTING);
    }
	private Matcher compile(String regex, String targetString) {		
		    Pattern pattern = Pattern.compile(regex);
		    Matcher matcher = pattern.matcher(targetString);		    
		    if (matcher.find()) {
		    	return matcher;
		        
		    }
		    return null;
		      
	}
	


}