package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.event.*;

import releasetool.PepMan;
import releasetool.PepMan.PANEL_TYPE;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class MenuPackage extends JPanel implements MenuInterface {
    
 	public MenuPackage(PanelStruct panelS, JComboBox<ButtonSelection> _comboPointer) {
		
		add(BorderLayout.NORTH, editor);
		
		editor.setContentType("text/html");
		
		editor.addHyperlinkListener(new HCustomListener());
		editor.setPreferredSize(new Dimension(500,500));
		editor.attachHeader();
		
		editor.attachP("Welcome to the Distribution page!");
		editor.attachP("This is a manual page to download the proper Java, Tomcat distrubution to be extracted and provisioned.");
		
		editor.attachEnder();
		editor.printPage();
			
		}
		//editorHtml.removeh
		
		
	
	
	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			System.out.println("Event entered");
			// TODO Auto-generated method stub
			
		}
	
	}


	

}
