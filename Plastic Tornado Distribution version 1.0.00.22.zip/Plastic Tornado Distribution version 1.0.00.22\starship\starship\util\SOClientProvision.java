package starship.util;

import javax.swing.JTextField;

import starship.util.ExecCallable;

public class SOClientProvision implements ExecCallable {
    JTextField tfHost=null, tfContext=null, tfServlet=null;
    
    public SOClientProvision () {
    	
    	
    }
	public void doExecute() {
		// TODO Auto-generated method stub
		//localContainer.globalContainerPointer.soClientProvision =this;
			
	}
	
	
	
}

