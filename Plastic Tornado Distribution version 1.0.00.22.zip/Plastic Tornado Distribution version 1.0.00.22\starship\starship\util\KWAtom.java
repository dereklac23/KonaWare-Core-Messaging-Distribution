package starship.util;
import starship.atom.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;


/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/


/**
 * 
 * The smallest unit of a data structure to be used from BufferedInput and 
 * Output of the HTTPServlet Request and Response API. A HashMap is the next
 * higher-level wrapper that uses the Atom as both the key and data.
 * 
 *  The KWMessageWrapper are used to transport the bits to and from the client 
 *  to the Servlet using the same shared package library: konaware.util.
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
 
public class KWAtom {
    public String tokenType=null;
    private String data=null;
    int     payloadInt=0;
    long    payloadLong =0;
    double  payloadDouble =0.0;
    float   payloadFloat = 0.0f;
    boolean payloadBoolean =false;
    char    payloadChar ='0';
    short   payloadShort=0;
    byte    payloadByte=0;
    static public String HEADER_TEXT ="KWGateway 1.22";
    static public int HEADER_INT = 4269;
    public KWTYPE type =KWTYPE.NULL;
    public int ordinal=0;
	public enum KWTYPE  {
			STRING , INT, LONG
			, DOUBLE,
			FLOAT, BOOLEAN, CHAR, SHORT, BYTE, NULL;
	}
	public KWAtom kwTokenMap[] = new KWAtom[KWTYPE.values().length];
    public KWAtom() {
    	
    }
	
	/*
	 * You have to create an instance and using lower-case type such as "int" or "string"
	 * to specify the Atom Type. The types are: string, int, long, double, float, boolean,
	 * char, short, byte.
	 * 
	 *
	 * 
	 * 
	 */
    public KWAtom(String _tok) throws AtomException {
    	
    	if (_tok.equals("string")) {
    		tokenType=_tok;
    		ordinal = KWTYPE.STRING.ordinal();    		
  		    kwTokenMap[ordinal] = new KWAtom();
  		    kwTokenMap[ordinal].type=KWTYPE.STRING;
    	} else if (_tok.equals("int")) {
    		tokenType=_tok;
    		ordinal = KWTYPE.INT.ordinal();
    		kwTokenMap[ordinal] = new KWAtom();
  		    kwTokenMap[ordinal].type=KWTYPE.INT;
    	} else if (_tok.equals("long")) {
    		tokenType=_tok;
    		ordinal = KWTYPE.LONG.ordinal();
    		kwTokenMap[ordinal] = new KWAtom();
  		    kwTokenMap[ordinal].type=KWTYPE.LONG;    		
    	} else if (_tok.equals("double")) {
    		tokenType=_tok;
    		ordinal = KWTYPE.DOUBLE.ordinal();
    		kwTokenMap[ordinal] = new KWAtom();
  		    kwTokenMap[ordinal].type=KWTYPE.DOUBLE;    		
    	} else if (_tok.equals("float")) {
    		tokenType=_tok;
    		ordinal = KWTYPE.FLOAT.ordinal();
    		kwTokenMap[ordinal] = new KWAtom();
  		    kwTokenMap[ordinal].type=KWTYPE.FLOAT;
    	}else if (_tok.equals("boolean")) {
    		tokenType=_tok;
    		ordinal = KWTYPE.BOOLEAN.ordinal();
    		kwTokenMap[ordinal] = new KWAtom();
  		    kwTokenMap[ordinal].type=KWTYPE.BOOLEAN;
    	}else if (_tok.equals("char")) {
    		tokenType=_tok;
    		ordinal = KWTYPE.CHAR.ordinal();
    		kwTokenMap[ordinal] = new KWAtom();
  		    kwTokenMap[ordinal].type=KWTYPE.CHAR;
    	} else if (_tok.equals("short")) {
    		tokenType=_tok;
    		ordinal = KWTYPE.SHORT.ordinal();
    		kwTokenMap[ordinal] = new KWAtom();
  		    kwTokenMap[ordinal].type=KWTYPE.SHORT;
    	}else if (_tok.equals("byte")) {
    		tokenType=_tok;
    		ordinal = KWTYPE.BYTE.ordinal();
    		kwTokenMap[ordinal] = new KWAtom();
  		    kwTokenMap[ordinal].type=KWTYPE.BYTE;
    	}
    
    }
    public KWTYPE getType() {
    	return kwTokenMap[ordinal].type;
    }
	public KWAtom(KWTYPE _type) {
		
	  switch (_type) {
	  
	  case KWTYPE.STRING:
		  tokenType = "string";
		  ordinal = KWTYPE.STRING.ordinal();
		  type = KWTYPE.STRING;
		  kwTokenMap[ordinal] = new KWAtom();
		  kwTokenMap[ordinal].tokenType = "string";
	  break;
	  
	  case KWTYPE.INT:
		  tokenType="int";
		  type = KWTYPE.INT;
		  ordinal = KWTYPE.INT.ordinal();
		  kwTokenMap[ordinal] = new KWAtom();
		  kwTokenMap[ordinal].tokenType = "int";
		  break;
	  
	  case KWTYPE.LONG:
		  tokenType="long";
		  type = KWTYPE.LONG;
		  ordinal = KWTYPE.LONG.ordinal();
		  kwTokenMap[ordinal] = new KWAtom();
		  kwTokenMap[ordinal].tokenType = "long";
		  break;
	  
	  case KWTYPE.DOUBLE:
		  tokenType="double";
		  type = KWTYPE.DOUBLE;
		  ordinal = KWTYPE.DOUBLE.ordinal();
		  kwTokenMap[ordinal] = new KWAtom();
		  kwTokenMap[ordinal].tokenType = "double";
		  break;
	
	  case KWTYPE.FLOAT:
		  tokenType="float";
		  type = KWTYPE.FLOAT;
		  ordinal = KWTYPE.FLOAT.ordinal();
		  kwTokenMap[ordinal] = new KWAtom();
		  kwTokenMap[ordinal].tokenType = "float";
		  break;
		  
	  case KWTYPE.BOOLEAN:
		  tokenType="boolean";
		  type = KWTYPE.BOOLEAN;
		  ordinal = KWTYPE.BOOLEAN.ordinal();
		  kwTokenMap[ordinal] = new KWAtom();
		  kwTokenMap[ordinal].tokenType = "boolean";
		  break;

	  case KWTYPE.CHAR:
		  tokenType ="char";
		  type = KWTYPE.CHAR;
		  ordinal = KWTYPE.CHAR.ordinal();
		  kwTokenMap[ordinal] = new KWAtom();
		  kwTokenMap[ordinal].tokenType = "char";
		  break;

	  case KWTYPE.SHORT:
		  tokenType ="short";
		  type = KWTYPE.SHORT;
		  ordinal = KWTYPE.SHORT.ordinal();
		  kwTokenMap[ordinal] = new KWAtom();
		  kwTokenMap[ordinal].tokenType = "short";
		  break;

	  case KWTYPE.BYTE:
		  tokenType="byte";
		  type = KWTYPE.BYTE;
		  ordinal = KWTYPE.BYTE.ordinal();
		  kwTokenMap[ordinal] = new KWAtom();
		  kwTokenMap[ordinal].tokenType = "byte";
		  break;

	  }
	 
	}
	public KWAtom (BufferedReader reader) throws AtomException  {
		try {
		String line = reader.readLine();
		if (line ==null) {
			throw new AtomException("Error: Protocol KWAtom expects a type such as 'string' or 'long'");
		} 
		} catch (IOException ioe) {
			throw new AtomException("Cannot read data in KWAtom input stream pipe.");
		}
	}
	
	public int getInt() {
		if (type  != KWTYPE.INT) {
			return 0;
		} else {
			return Integer.parseInt(kwTokenMap[ordinal].data);
		}
	}
	public long getLong() {
		if (type  != KWTYPE.LONG) {
			return 0;
		} else {
			return Long.parseLong(kwTokenMap[ordinal].data);
		}
	}
	
	public double getDouble() {
		if (type  != KWTYPE.DOUBLE) {
			return 0;
		} else {
			return Double.parseDouble(kwTokenMap[ordinal].data);
		}
	}
	
	public float getFloat() {
		if (type  != KWTYPE.FLOAT) {
			return 0;
		} else {
			return Float.parseFloat(kwTokenMap[ordinal].data);
		}
	}
	public boolean getBoolean() {
		if (type  != KWTYPE.BOOLEAN) {
			return false;
		} else if (kwTokenMap[ordinal].data.equals("true")) {
			return true;
			
		} else {
		 return false;
		}
	}
	
	public char getChar() {
		if (type  != KWTYPE.CHAR) {
			return 0;
		} else {
			return kwTokenMap[ordinal].data.charAt(0);
		}
	}
	
	public int getByte() {
		if (type  != KWTYPE.BYTE) {
			return 0;
		} else {
			return Byte.parseByte(kwTokenMap[ordinal].data);
		}
	}
	
	
	public void printString(PrintWriter pw) {
		KWAtom kwm = kwTokenMap[ordinal];
	    	
		if (kwm.tokenType !=null && 
			kwm.kwTokenMap[kwm.ordinal] !=null &&
			kwm.kwTokenMap[kwm.ordinal].data !=null) {
			//System.out.println("\nKWATom print string with writer:"+ kwm.kwTokenMap[kwm.ordinal].type.t
			System.out.println("\nKWATom print string data:"+ kwm.data);
			System.out.println("\ndescribe string:"+ describeString());
		    pw.println(kwm.tokenType);
			pw.println(kwm.kwTokenMap[kwm.ordinal].data);
		}
	}
	

	public String describeString() {
		KWAtom kwm = kwTokenMap[ordinal];
		StringBuffer sb= new StringBuffer();
		if (kwm.tokenType!=null) {
			sb.append(kwm.tokenType);
			sb.append(":");
		} 
		return sb.toString();
	}
 public void setData(String data) {
	 if (data ==null) {
	 return;
	 } 
	KWAtom mInstance = kwTokenMap[ordinal];	
	//mInstance.ordinal=ordinal;
	mInstance.data=data;
	}
public String getData() {
	return kwTokenMap[ordinal].data;	

}

 public void setData(BufferedReader br) throws AtomException  {
	 try {
	   KWAtom atom = new KWAtom(br.readLine());
	   atom.setData(br.readLine());
	 } catch (IOException ioe) {
		throw new AtomException ("The data line is null"); 
	 }
	   
   }
   public void write(PrintWriter pw) {
	     System.out.println("Printing at writer token:"+ 
                       kwTokenMap[ordinal].tokenType);
	     System.out.println("Printing at data token:"+ 
                       kwTokenMap[ordinal].data);
	     
	     pw.println(tokenType);
	   	 pw.println(kwTokenMap[ordinal].data);
   }
   public String getString() {
	   StringBuffer sb  = new StringBuffer();
	   sb.append(tokenType+"\n");
	   sb.append(kwTokenMap[ordinal].data+"\n");
   	   
   	   return sb.toString();
   }
   
   public void read(BufferedReader br) throws AtomException {
	   try {
		String tokenKey= br.readLine();
		KWAtom atomKey = new KWAtom(tokenKey);
		String tokenData = br.readLine();
		atomKey.setData(tokenData);
		
		KWAtom atomData = new KWAtom(tokenData);
		String dataLine = br.readLine();
		
		if (dataLine ==null) {
			throw new AtomException ("Data line is null. The data protcol exchange has a mis-match");
		}
		atomData.setData(dataLine);
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
   }
   
 
	
}
