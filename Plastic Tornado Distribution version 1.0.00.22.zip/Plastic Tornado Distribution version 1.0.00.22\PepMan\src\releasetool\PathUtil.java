package releasetool;
import releasetool.gui.*;

import java.io.BufferedInputStream;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
//import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

//import konaware.server.atom.KWServerHashMapEntry;

//import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

public class PathUtil {
	  private final static String TOMCAT="D:\\utility\\apache-tomcat-11.0.3"; 
	  public HashMap <String, KCMObject> kwMapEntry = 
				new HashMap<String, KCMObject>();
	  public Map<String, KCMObject> eMap =  Collections.synchronizedMap(kwMapEntry);
	  
	
	  private StringBuffer pageBuffer=new StringBuffer();
	  private JComboBox<ButtonSelection> combo=null;
	  

 public PathUtil( ) {
	 InputStreamReader reader = new InputStreamReader(System.in);
 	try {
     DocumentBuilderFactory builderFactory =
             DocumentBuilderFactory.newInstance();
     DocumentBuilder builder = null;

		 builder = builderFactory.newDocumentBuilder();
		 Document doc = builder.parse(new File("resource/html/PAGE.001.xml"));
		 XPathFactory xpathfactory = XPathFactory.newInstance();
		 XPath xpath = xpathfactory.newXPath();
		 XPathExpression expr = xpath.compile("//listener/port/text()");
		 Object result = expr.evaluate(doc, XPathConstants.NODESET);
		 NodeList nodes = (NodeList) result;
		 

		 for (int i = 0; i < nodes.getLength(); i++) {
	  	   System.out.println("leng"+nodes.getLength());
		   System.out.println(nodes.item(i).getNodeName());		   
		   System.out.println("value="+nodes.item(i).getNodeValue());
		   
		 }
	 
	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException ioe) {
		System.err.println("ioe error"+ioe.getMessage());
	} catch (SAXException sax) {
		
	} catch (XPathExpressionException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
 
 }
 
 KCMObject directoryKCM= new KCMObject();
 public MenuInterface menuInterface=null;
 public PathUtil(JComboBox<ButtonSelection> _comb, MenuInterface _menuI) {
	 combo= _comb;
	 menuInterface= _menuI;
 }
 

 public PathUtil (File _target, MenuInterface menuI) {
	 File file[] = _target.listFiles(new FileFilterSh(FileFilterSh.FT.RELEASE_NAMING));
	 KCMObject  kObject=null;
	 for (int i=0; i < file.length; i++) {
		 try {
		 
		 kObject = new KCMObject(_target, file[i].getName());
		 
		 } catch (KCMException kcm) {
			 System.out.println("\nkcm"+kcm.description);
		 }
		 if (kObject !=null) {
		   	 
		   eMap.put(kObject.directoryObject.getVersionString(), kObject);
		 }
		 
	 }
	 Set<String> keySet=eMap.keySet();
	
	 
	 for (Map.Entry<String, KCMObject> entry : eMap.entrySet()) {
		 KCMObject object = entry.getValue();
		 if (directoryKCM.directoryObject.compare(object.directoryObject.version)) {
			 
			 directoryKCM = object;
		 }
	 }
	 
	 menuInterface = menuI;
	
 }
 
 public FileObject getResourceFolderFiles(ClassLoader loader, String pList[]) {
	 FileObject fObject=null;
	 return fObject;
 }
 public FileObject getResourceFolderFiles(ClassLoader loader,String folder) throws KCMException {

	   try {
		  
     URL url = loader.getResource(folder);
     if (url ==null) {
    	 throw new KCMException ("\nClasspath not set");
     }
     String path = url.getPath();
     String pathList []= path.split(":");
     if (pathList.length > 0) {
    	 FileObject fObject = getResourceFolderFiles(loader,pathList);    	 
    	 
     } 
     
     File file = new File(path);
     
     if(file.isDirectory()){
    	FileObject fileObject = new FileObject(file);    	    
            Files.walk(file.toPath()).filter(Files::isRegularFile).forEach(f -> fileObject.add(f.toFile()));
         return fileObject;
     }else{
    	 FileObject fileObject = new FileObject(file);
       fileObject.add(file);
       return fileObject;
     }
     
     } catch (IOException e) {
         throw new KCMException ("\nGTML read error.");
     } catch (NoClassDefFoundError ne) {
    	 System.err.println("\nClasspath needs to be set using -cp");
    	 throw new KCMException("\nError: Classpath not set");
     }
    
 }
 
 public void getResourceFiles(String folder) throws KCMException {
	 
	   /*
	 try {	  
  // ClassLoader loader = Thread.currentThread().getContextClassLoader();
   ClassLoader loader = releasetool.PepMan.getClassLoader().
   InputStream is = loader.getResourceAsStream(folder);
	      
   BufferedReader br = new BufferedReader(new InputStreamReader(is));
   
String line=     br.readLine();
if (line !=null) {
	System.out.println("\nline=="+line);
}
   } catch (IOException ioe) {
  	 
   }
   */
   
  
} 

 
 public void getResourceFolder(String _folder) throws KCMException {
	    ClassLoader loader = Thread.currentThread().getContextClassLoader();
	    FileObject resourceFolderFile = getResourceFolderFiles(loader,"gtml");
			 resourceFolderFile.processGTMLContent();
 }
		
	 
 
 

private void convertPageHtml(StringBuffer sb) {
	 
	 menuInterface.editor.attachHeader();
	 menuInterface.editor.attachP(sb.toString());
	 menuInterface.editor.attachEnder();
	 menuInterface.editor.printPage();
 }

 private void processTxt(File f) throws FileNotFoundException, IOException  {
	 BufferedReader br= new BufferedReader(new FileReader(f));
	 String line = null;
	 
	 while ((line = br.readLine()) !=null) {
		 pageBuffer.append(line);
	 }
	
	 
	 
 }
 private void processXml(File f) {
		try {
		     DocumentBuilderFactory builderFactory =
		             DocumentBuilderFactory.newInstance();
		     DocumentBuilder builder = null;

				 builder = builderFactory.newDocumentBuilder();
				 Document doc = builder.parse(f);
				 XPathFactory xpathfactory = XPathFactory.newInstance();
				 XPath xpath = xpathfactory.newXPath();
				 XPathExpression expr = xpath.compile("//listener/name/text()");
				 Object result = expr.evaluate(doc, XPathConstants.NODESET);
				 NodeList nodes = (NodeList) result;
				 

				 for (int i = 0; i < nodes.getLength(); i++) {
			  	   System.out.println("\nleng:"+nodes.getLength());
				   System.out.println("\n"+nodes.item(i).getNodeName());		   
				   System.out.println("value="+nodes.item(i).getNodeValue());
				   
				 }
			 
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException ioe) {
				System.err.println("ioe error"+ioe.getMessage());
			} catch (SAXException sax) {
				System.err.println("sax error:");
			} catch (XPathExpressionException e) {
				System.err.println("x path exception error:");
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
 }
	 public void performCopy() throws IOException {
		KCMObject kcmDevTarget = new KCMObject(new File("d:\\dev"), directoryKCM);
		kcmDevTarget.performCopy();
	 }
	 
	 
	 public void performCopyWar2Tomcat() throws KCMException {
		 try {
		 DirectoryObject directoryTomcat= new DirectoryObject(new File("D:\\utility\\apache-tomcat-11.0.3\\webapps"));
		 KCMObject kcmDevTarget = new KCMObject(directoryTomcat); String DEV_ROOT="D:\\dev";
		kcmDevTarget.performCopyWarBinaries();
		 } catch (IOException ioe) {
			 throw new KCMException (ioe.toString());
		 }
		 
	 }
	 public void loadHtmlPage() {
		 if (pageBuffer ==null) {
			 System.err.println("\nPages not loaded");
			 return;
		 }
		 String output=null;
		 menuInterface.editor.attachHeader();
		 menuInterface.editor.attachP(output=pageBuffer.toString());
		 menuInterface.editor.attachEnder();
		 menuInterface.editor.printPage();
		 
		// htmlOutput.revalidate();
	 } 

	 
 
     public void createWrite() throws ParserConfigurationException,
		            TransformerException {

		        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		        DocumentBuilder builder = factory.newDocumentBuilder();
		        Document doc = builder.newDocument();

		        Element root = doc.createElementNS("zetcode.com", "users");
		        doc.appendChild(root);

		        root.appendChild(createUser(doc, "1", "Robert", "Brown", "programmer"));
		        root.appendChild(createUser(doc, "2", "Pamela", "Kyle", "writer"));
		        root.appendChild(createUser(doc, "3", "Peter", "Smith", "teacher"));

		        TransformerFactory transformerFactory = TransformerFactory.newInstance();
		        Transformer transf = transformerFactory.newTransformer();

		        transf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		        transf.setOutputProperty(OutputKeys.INDENT, "yes");
		        transf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

		        DOMSource source = new DOMSource(doc);

		        File myFile = new File("d:\\dev\\gnoo1\\users.xml");

		        StreamResult console = new StreamResult(System.out);
		        StreamResult file = new StreamResult(myFile);

		        transf.transform(source, console);
		        transf.transform(source, file);
		    }
 private static Node createUser(Document doc, String id, String firstName,
         String lastName, String occupation) {

     Element user = doc.createElement("user");

     user.setAttribute("id", id);
     user.appendChild(createUserElement(doc, "firstname", firstName));
     user.appendChild(createUserElement(doc, "lastname", lastName));
     user.appendChild(createUserElement(doc, "occupation", occupation));

     return user;
 }

 private static Node createUserElement(Document doc, String name,
         String value) {

     Element node = doc.createElement(name);
     node.appendChild(doc.createTextNode(value));

     return node;
 }
 public boolean checkTomcatDirectory(File _file) {
	 File binFile =  new File(_file,"bin");
	  File listFile [] =binFile.listFiles(new FileFilterSh());
	 //File listFile [] =binFile.listFiles();
	 return listFile !=null && listFile.length > 5;
			 
	
 }

}

