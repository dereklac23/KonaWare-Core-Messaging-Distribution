package starship.atom;



public class  AtomCore {
  	    public  String payloadToken=null;
	    public  String payloadData=null;
	    int     payloadInt=0;
	    long    payloadLong =0;
	    double  payloadDouble =0.0;
	    float   payloadFloat = 0.0f;
	    boolean payloadBoolean =false;
	    char    payloadChar ='0';
	    short   payloadShort=0;
	    byte    payloadByte=0;
	    static public String HEADER_TEXT ="KWGateway 1.22";
	    static public int HEADER_INT = 4269;
	    
	    public int ordinal=0;
		
        
		public static AtomCore getAtom(String string) throws AtomException {
			// TODO Auto-generated method stub
			if (string.equals("int")) {
			  return new IntegerAtom();
			} else if (string.equals("string")) {
			  return new StringAtom();
			} else {
				throw new AtomException("Undefined type in AtomCore token"+string);
			}
			
		}
		public AtomCore() {
			
		}


       
		private static AtomCore IntegerAtom(String string) {
			return null;
			// TODO Auto-generated method stub
			//return new IntegerAtom();
		}
	   
	    
}
	    	
	

   
	
