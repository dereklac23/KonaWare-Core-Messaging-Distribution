package starship.util;
import starship.atom.*;

import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;


//import konaware.util.KWAtom.KWTYPE;

/*
 * 
 * The wrapper is used to house the KWHashMap to be transported using a BufferedWriter or
 * BufferedReader. This wrapper is shared for both client and server API.
 * 
 * To use this wrapper as part of the HttpServlet api, put this jar file (KonaWareCoreMessage_1xx.jar)
 * into the WEB-INF/lib. Make sure you do not extract the jar file.
 * 
 * To import on Eclipse, you use the import->file system to package the jar into the WEB/lib 
 * directory. Next, add the path in Build Path -=> Configure Build Path.
 * 
 * 
 * 
d */

public class KWMessageWrapper {
	
    StringBuffer returnBuffer = new StringBuffer();
    private PrintWriter printWriter=null;
    HashMap <String, KWHashMapEntry> kwMapHME = 
    		new HashMap<String, KWHashMapEntry>();
    
 	Map<String, KWHashMapEntry> eMap = Collections.synchronizedMap(kwMapHME);
 	
 	
 	private static char DIV='/';		 
 	
 	/*
 	 * 
 	 * If the hostname, context, and servlet name is given, this is a post HttpServlet request.
 	 * A kw-atom (also known as a James Clear Data Type, is the fundamental building block 
 	 * of a KWHashMap that is housed in the KWMessageWrapper.
 	 * Alternative to kw-atom, there is kw-octet-stream which is used for file upload and download. 
 	 * 
 	 * 
 	 */
 	private HttpURLConnection connection=null;
 	private String contextName =null, servletName=null, hostName =null;
 	public KWMessageWrapper() {
 		
 	}
 	private URI getURI(String _hostname, String _context, String _servlet) 
 			throws URISyntaxException {
 		return new URI(_hostname+ DIV + _context + DIV + _servlet);
 	}
 	URL urlString;
 	public KWMessageWrapper(String _hostname, String _context, String _servletname) 
 				 throws StateOperationException {
 		   try {
 	  	      URI uri = getURI(_hostname, _context, _servletname);
 			   urlString = uri.toURL();
 			  //connection = (HttpConnection) 
 			  System.out.println("\n createion url is"+ urlString.toString());
 			  connection = (HttpURLConnection)urlString.openConnection();
 			  contextName = _context;
 			  servletName=_servletname;
 			 System.out.println("\nDone with creation:"+ urlString.toString());
 		   } catch (IOException ioe ) {
 			   throw new StateOperationException ("IOE Exception within KWMessageWrapper");
 		   } catch (URISyntaxException uri) {
 			   throw new StateOperationException ("URI Syntax within KWMessageWrapper");
 		   }
 	}


 	

/*
 * This KWMessageWrapper constructor takes in the file name for file upload and download requests.
 * If the deposition argument is "download" then it is saved to the local client with fileName as the file persistent name. 
 * If the deposition argument is  "upload" then it is uploaded to the HttpServer with the context path being the root and the
 * fileName is as file persistent name. 
 * 
 * 
 */
private LocalContainer globalContainer=null;

public KWMessageWrapper(LocalContainer gc) {
	globalContainer=gc;
}

public KWMessageWrapper(URI hostname, String context, String servletname, String fileName) 
		 throws StateOperationException  {
	 try {

	
	  urlString= hostname.toURL();		
	  System.out.println("\nstring url");
	  connection = (HttpURLConnection)urlString.openConnection();
	  System.out.println("\npost open connection:");
	  connection.setRequestMethod("POST");
	  connection.setDoOutput(true);
	 } catch (IOException ioe) {
		throw new StateOperationException("IO exception with KWrapper"); 
	 } 
}
    /*
	public void put(String _key, KWAtom _map) throws AtomException {
 		if (_key==null) {
 			throw new AtomException("Key is null"); 			
 		} else if (_map==null) {
 			throw new AtomException("Data is null");
 			
 		}
 		KWAtom atomPair [] = new KWAtom[2];
 		atomPair[0] = new KWAtom(KWAtom.KWTYPE.STRING);
 		atomPair[1] = _map;
 		aMap.put(_key, atomPair);
 		
 	}
 	*/
/*

	public KWAtom get(String _key) {
 		KWAtom mapPair []=( KWAtom[]) aMap.get(_key);
 		return mapPair[1];
 	}
*/
    
	public KWMessageWrapper(PrintWriter pw) throws IOException {
		printWriter =pw;
	}
	
	public void addEntry(String _key, String _data) throws AtomException {
		
		StringAtom atomKey =  (StringAtom)AtomCore.getAtom("string");
		atomKey.setString(_key);
		
		StringAtom atomData = (StringAtom)AtomCore.getAtom("int");
	}
	
	
	public void add(long data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.LONG);
		map[1].setData(String.valueOf(data));
		
		
	}

	public void add(double data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.DOUBLE);
		map[1].setData(String.valueOf(data));
	}

	public void add(float data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.FLOAT);
		map[1].setData(String.valueOf(data));
	}

	public void add(boolean data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.BOOLEAN);
		map[1].setData(String.valueOf(data));
	}

	public void add(char data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.CHAR);
		map[1].setData(String.valueOf(data));
	}

	public void add(short data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.SHORT);
		map[1].setData(String.valueOf(data));
	}

	public void add(byte data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.BYTE);
		map[1].setData(String.valueOf(data));
	}
	
   public void put(KWHashMapEntry entry) {
	   StringAtom key=(StringAtom)entry.getKeyAtom();	   
	   kwMapHME.put(key.getString(), entry);
   }

 
    
   
    public synchronized DimensionStateOperation getDSO (KWHashMapEntry _widthEntry, 
    		   KWHashMapEntry _heightEntry) throws AtomException {
    	return  new DimensionStateOperation(_widthEntry, _heightEntry);
    }
    public void Send(AtomCore  _atomKey, AtomCore _atomData) throws AtomException {
        try {
     	   IntegerAtom atomI =null;
     	   PrintWriter pWriter = new PrintWriter(new OutputStreamWriter(
 					connection.getOutputStream()));
 			StringAtom atomKey = (StringAtom)_atomKey;
 			AtomCore atomData = (AtomCore)_atomData;
 			atomKey.print(pWriter);
 			
 			if (atomData instanceof IntegerAtom ) {
 				atomI = (IntegerAtom)atomData;
 			    atomI.print(pWriter);
 			}
 			atomI.print(pWriter);
     	   
        } catch (IOException ioe) {
     	   throw new AtomException("\nConnection error in sending AtomCores");
        }
     }

 	public void Send() throws AtomException {	  
		try {
		Iterator <String> iterator = eMap.keySet().iterator();
		while (iterator.hasNext()) {			
			
			String key = (String)iterator.next();			
			KWHashMapEntry entryKey= (KWHashMapEntry)eMap.get(key);
			KWHashMapEntry entryData= (KWHashMapEntry)eMap.get(key);
			
			PrintWriter pWriter = new PrintWriter(new OutputStreamWriter(
					connection.getOutputStream()));
			StringAtom atomKey = (StringAtom)entryKey.getDataAtom();
			AtomCore atomData = (AtomCore)entryData.getDataAtom();
			atomKey.print(pWriter);
			
			if (atomData instanceof IntegerAtom ) {
				IntegerAtom atomI = (IntegerAtom)atomData;
			    atomI.print(pWriter);
			}
			
			
		}
		} catch (IOException ioe) {
			throw new AtomException ("Error: IOException in sending KWHashMapEntry");
		}
	}
	
	public String DescribeEachItem() {
		returnBuffer.setLength(0);
		Iterator <String> iterator = eMap.keySet().iterator();

		while (iterator.hasNext()) {			
			String  key= (String)iterator.next();

			
		}
		return returnBuffer.toString();
	}
	
	public String DescribeString() {
		return returnBuffer.toString();
	}
	
	
	public void ReceiveFillMap() throws StateOperationException {
		if (connection ==null) {
			System.out.println("connection is null");
			return ;
			
		}
		 
		System.out.println("\n@@@Initializing ReceiveFillMap");
		try {
			 connection.setRequestMethod("GET");
			  connection.setDoOutput(true);
			  BufferedReader in = new BufferedReader(
					new InputStreamReader(connection.getInputStream()));
			  String token=null, line=null, key=null;
			       while ((token=in.readLine()) !=null) {
			    	   System.out.println("\nToken "+token);
			    	   AtomCore atomToken = AtomCore.getAtom(token);
			    	   if (atomToken ==null) {
			    		   throw new StateOperationException("Error: The token needs to be a string according to the KWHashMapEntry protocol");
			    	   }
			    	   StringAtom atomString =null;
			    	   if (atomToken instanceof StringAtom) {
			    		   atomString =(StringAtom)atomToken;
			    		   atomString.setString(in.readLine());
			    	   }
			    	   AtomCore atomData= AtomCore.getAtom(in.readLine());
                       IntegerAtom atomDataInteger =null;
			    	   if (atomData ==null) {
			    		   throw new StateOperationException("Error: The datapayload needs to be a type.")	;
			    	   } else  if (atomData instanceof IntegerAtom) {
			    		   atomDataInteger =(IntegerAtom)atomData;
			    		   atomDataInteger.setInteger(Integer.parseInt(in.readLine()));
			    	   }
			    	   		    	   
			    	  KWHashMapEntry entryRealm = new KWHashMapEntry(atomString, atomDataInteger);
			    	  
			    	  StringAtom atomKey= (StringAtom)entryRealm.getKeyAtom();
			    	  eMap.put(atomKey.getString(), entryRealm);
			    	  
			    	  IntegerAtom atomi = (IntegerAtom)entryRealm.getDataAtom();
			    	  System.out.println("\n###Got fill map:\n[<"+atomKey.getString()+">]:"+ atomi.getInteger()+":"+
			    	     atomKey.getString());
			    	  
			       } 
			         
				 in.close();
		} catch (IOException ioe) {
			throw new StateOperationException ("Error: State operation exception");
		} catch (AtomException ae) {
			throw new StateOperationException("Error: The protcol to send the AtomCore paris for KWHashMapEntry has an mismatch");
		}

	}
	public DimensionStateOperation getDSO() {
		System.out.println("\n[@@]size"+ eMap.size()+ DimensionStateOperation.BOARD_PROVISION_X_STRING);
		KWHashMapEntry entryWidth  = eMap.get(DimensionStateOperation.BOARD_PROVISION_X_STRING);
		KWHashMapEntry entryHeight= eMap.get(DimensionStateOperation.BOARD_PROVISION_Y_STRING);
	    DimensionStateOperation dso = new DimensionStateOperation(
			   entryWidth, entryHeight);
	   return dso;
			   
	   	   
			   
			   
	}

	//!!@doGet
	public void doGet() throws StateOperationException {
		
		
			
	}


	
private final static int contentLength=27;
public void doPostBiDirection() throws StateOperationException {
	 String token=null;
	 String line=null;
	      try {
		  connection.setRequestMethod("POST");
		  connection.setDoOutput(true);
		  PrintWriter pw= new PrintWriter(connection.getOutputStream());
		  String header = "POST /"+contextName+"/"+servletName+" HTTP/1.1"+"\n\n";		  
		  pw.write(header);		  
		  pw.write("Host: "+hostName+"\n");
		  pw.write("Content-Type: application/x-www-form-urlencoded\n");
		  pw.write("Content-Length: "+contentLength+"\n");
		  pw.write("kw-atom");
		  pw.close();
		  KWAtom map=null;	  
		  BufferedReader in = new BufferedReader(
				new InputStreamReader(connection.getInputStream()));
		 
		  
		  while ((line = in.readLine()) !=null) {
			  
			  KWAtom key= new KWAtom(line);  
			  KWAtom data = new KWAtom(in);
			  KWAtom pair[] = new KWAtom[2];
			  pair[0] = key;
			  pair[1]= data;
//			  eMap.put(line , pair);
			   
		  }
		  
		    	   
			         	    	   
		        
		  in.close();
	      } catch (ProtocolException pe) {
	    	   throw new StateOperationException(pe.toString());
	       } catch (IOException ioe) {
	    	   throw new StateOperationException(ioe.toString());
	       }  catch (AtomException ae) {
				  System.err.println("Error in protcol inputstream reading for token"+token);
			  }
	}

public void doPost2() throws StateOperationException   {
	try {
    connection=(HttpURLConnection)urlString.openConnection(); 
	connection.setRequestMethod("POST");
	connection.setDoOutput(true);
	PrintWriter pw= new PrintWriter(connection.getOutputStream());
    String header = "POST /"+contextName+"/"+servletName+" HTTP/1.1"+"\n\n";		  
	pw.write(header);		  
	pw.write("Host: "+hostName+"\n");
	pw.write("Content-Type: application/x-www-form-urlencoded\n");
	pw.write("Content-Length: "+contentLength+"\n");
	pw.write("kw-octet-stream\n");
	pw.close();
	KWAtom map=null;	  
	  BufferedReader in = new BufferedReader(
			new InputStreamReader(connection.getInputStream()));
	  String token=null;
	  String line=null;
	       while ((token=in.readLine()) !=null) {
	    	   /*
	    	   System.out.println("\n reading line of input"+token);
	    	   KWAtom atom1 = new KWAtom(token);
	    	   line = in.readLine();
	    	   atom1.setData(line);
	    	   
	    	   KWAtom atom2 = new KWAtom(in);
	    	   line = in.readLine();
	    	   atom2.setData(line);
	    	   
	    	   KWAtom pair [] = new KWAtom[2];
               eMap.put(atom1.getData(), pair);
		         */
		        // returnBuffer.append(line);
	       }
	in.close();
	
	
	}  catch (MalformedURLException mfe) {
		throw new StateOperationException(mfe.toString());
	} catch (ProtocolException pe) {
		throw new StateOperationException(pe.toString());
	} catch (IOException ioe) {
		System.out.println("ioe exception in doPost:" +(ioe ==null));
		throw new StateOperationException(ioe.toString());
	} 
		  
}

}
