package starship.atom;

import java.io.PrintWriter;

public class StringAtom extends AtomCore {
	String payload=null;
    final static String token = "string";
	
    public StringAtom() {
    	
    }
    public StringAtom(String _payload)  {
    	payload = _payload;
    	
    }

    public String getString() {
    return payload;
    }
	public void print(PrintWriter printWriter) {
		printWriter.println(token);
		printWriter.println(payload);
	}
	public void setString(String _payl) {
		payload = _payl;
	}





}
