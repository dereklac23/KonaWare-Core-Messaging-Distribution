package releasetool;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;

public class FileObject {
  String fileHeadString=null;
  File fileRoot=null;
  ArrayList<File> fileList = new ArrayList<File>();
  ArrayList<PageObject> pageList = new ArrayList<PageObject>();
  StringBuffer sb = new StringBuffer();
 public FileObject () {
	 
 }
 public void setFileHeadString(String _head) {
	 fileHeadString = _head;
 }
 public FileObject(File  _root) {
	 fileRoot = _root;
 }
 public FileObject(String _root) {
	 fileList.add(new File(_root));
}
 public void addFile(File _f) {
	 fileList.add(_f);
 }
 public void addPage(File _f) {
	 pageList.add(new PageObject(_f));
 }
 public void addBuffer(String _str) {
	 sb.append(_str);
 }
 public void processGTMLContent() {
	 
	 pageList.forEach(p->processPage(p));
	 
 }
 
 private void processPage(PageObject p) {
	 try {
     	 p.process();
	 } catch (KCMException kcm) {
		 System.err.println("Error in processing page of bundled jar resource");
	 }
 }


 
}
