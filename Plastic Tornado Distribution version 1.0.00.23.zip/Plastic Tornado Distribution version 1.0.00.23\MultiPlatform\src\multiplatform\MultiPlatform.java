package multiplatform;

import javax.swing.JComboBox;
import javax.swing.SwingUtilities;

import releasetool.PepMan;

public class MultiPlatform {
    private static MultiPlatform multiPlatform =null;
    JComboBox<ButtonSelection> jCombo = null;
	private static void createAndShowGUI() {
        // Create the frame
		multiPlatform = new MultiPlatform();      
    }
    public MultiPlatform() extends JFrame {
    	
    }
	public static void main(String args[] ) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
		
	}
	
	
}
