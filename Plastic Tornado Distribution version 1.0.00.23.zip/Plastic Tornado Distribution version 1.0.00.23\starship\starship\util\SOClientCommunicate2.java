package starship.util;
import starship.atom.*;


public class SOClientCommunicate2 implements ExecCallable {
		 public LocalContainer cpL1=null;
		
	    public SOClientCommunicate2 (LocalContainer _loc) {
          cpL1 = _loc;
        }
  
	
		@Override
		public void doExecute() {
			// TODO Auto-generated method stub
			cpL1.taTextArea.append("\nProvisioning SOClient Communicate");
   
			
			try {
            LocalContainer globalPointer=cpL1.getGlobalContainer();
            		
			KWMessageWrapper wrapper=null;
			
				 wrapper =
						new KWMessageWrapper(
								globalPointer.tfHostName.getText(),
								globalPointer.tfContextName.getText(), 
								globalPointer.tfServletName.getText());
				 
				 globalPointer.kwMessageWrapper= wrapper;
				 
				 
				
				 wrapper.ReceiveFillMap();
				 DimensionStateOperation dso = wrapper.getDSO();
				 
				 LocalContainer gC=cpL1.getGlobalContainer();
				 gC.dso=dso;
				
			} catch (StateOperationException soe) {
				  cpL1.taTextArea.append("\nState operation:"+soe.toString());
					
				}
				
			
		

			
		}



		
	}
	
