package releasetool;

import javax.swing.JComboBox;



public class LocalContainer {
	private JComboBox jCombo=null;
    public PathUtil pathSet[]= null;

	public LocalContainer(PathUtil _path[]) {			
		pathSet = _path;
	}
}
