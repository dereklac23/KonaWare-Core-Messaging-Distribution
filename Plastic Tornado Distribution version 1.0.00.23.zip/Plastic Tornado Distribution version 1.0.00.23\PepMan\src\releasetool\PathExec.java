package releasetool;

import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import releasetool.gui.HTMLOutput;


public class PathExec implements SeafloorExec {


	private PathUtil pathSet[]=null;
	
	public void doExecute(LocalContainer _lc, LEVEL _level, TYPE _type, ATTR _attr) {
		// TODO Auto-generated method stub
		if (_type == SeafloorExec.TYPE.PROVISION) {
			pathSet=_lc.pathSet;
		}
	}
    public LocalContainer localContainer;
	
	public PathExec(LocalContainer _lc) {
		localContainer = _lc;
			
	}


	@Override
	public void doExecute( ATTR _attr) throws KCMException {
		// TODO Auto-generated method stub
		if (_attr == ATTR.HTML_MAIN) {
			HTMLOutput editor = pathSet[1].menuInterface.editor2;
			
			editor.attachHeader();
			editor.attachP("<p>Choose the following options to load resource:<p>");
			editor.attachRaw("<table><thead><tr><th>Type</th></tr></thead>");
			editor.attachRaw("<tbody>");
			editor.attachRaw("<tr><td>Load resource stream as:");
			editor.attachURL("gtml", "GTML from jar file");
			editor.addHyperlinkListener(new HCustomListener());
			editor.attachRaw("</td></tr>");
			editor.attachRaw("<tr><td>Load resource stream from Classpath.</td></tr>");
			editor.attachRaw("<tr><td>Load from Classpath.</td></tr>");
			editor.attachRaw("<tr><td>Currently the active head of the bundled jar file is 'gtml'");
			editor.attachRaw("</table>");
			editor.attachEnder();
			editor.printPage();
			localContainer.pathSet[0].getResourceFolder("gtml");
		}
		
	}

	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			System.out.println("Event entered");
			// TODO Auto-generated method stub
			
		}
	
	}
}
