package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import releasetool.gui.MenuPackage.HCustomListener;

public class MenuGTML extends JPanel implements MenuInterface {
	private ArrayList<ButtonSelection> btnList = new ArrayList<ButtonSelection>();
	public MenuGTML(PanelStruct panelS, JComboBox<ButtonSelection> _comboPointer, ArrayList<ButtonSelection> btnPackageList) {
		btnList = btnPackageList;
		add(BorderLayout.NORTH, editor2);
		
		editor2.setContentType("text/html");
		
		editor2.addHyperlinkListener(new HCustomListener());
		editor2.setPreferredSize(new Dimension(500,500));
		editor2.attachHeader();
		
		editor2.attachP("Welcome to the GTML page!");
		editor2.attachP("Create your books, chapters, and pages using GTML.");
		editor2.attachP("Your imagination starts at the 'gtml' directory as a bundled jar files and or local sandboxed files." );
		
		editor2.attachEnder();
		editor2.printPage();
			
		}
		//editorHtml.removeh
		
		
	
	
	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			System.out.println("Event entered");
			// TODO Auto-generated method stub
			
		}
	
	}
}

	



