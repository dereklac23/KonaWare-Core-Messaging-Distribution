/**
 * 
 */
/**
 * 
 */
module MultiPlatform {
	requires java.desktop;
}