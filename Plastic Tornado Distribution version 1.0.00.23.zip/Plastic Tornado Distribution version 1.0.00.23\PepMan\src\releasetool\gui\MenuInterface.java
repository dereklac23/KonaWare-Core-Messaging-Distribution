package releasetool.gui;

public interface MenuInterface {
	public HTMLOutput editor2=new HTMLOutput();

	//public abstract void printBody(String _body);
	
}
