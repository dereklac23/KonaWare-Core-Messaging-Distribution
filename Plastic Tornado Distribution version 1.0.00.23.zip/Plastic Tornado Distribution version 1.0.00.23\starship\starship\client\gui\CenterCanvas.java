package starship.client.gui;
import starship.util.*;
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class CenterCanvas extends JPanel {
    private Color colorInactive = Color.pink;
    private Color colorActive = Color.LIGHT_GRAY;
    private int width=100, height=100;
    private RealmRenderFunction rrf =null;
    
    private String errorString =null;

    public void setRRF(RealmRenderFunction _rrf) {
    	rrf=_rrf;
	      if (_rrf.dso !=null) {
	      width = _rrf.dso.getWidth();
	      height=_rrf.dso.getHeight();
	      super.setSize(width, height);
	      }
	    }
    

      
    public void paintComponent(Graphics g) {
              super.paintComponent(g);
              if (rrf !=null && rrf.dso !=null) {
              rrf.dso.paintComponent(g);
              } else {
            	  g.setColor(Color.RED);
            	  g.fillRect(0, 0, width, height);
            	  g.setColor(Color.WHITE);
            	  g.drawString("Initializing", 50,50);
              }
          
              
    }
    public CenterCanvas(int _w, int _h) {
     setSize(_w, _h);
	 
    }
   
 

 
}
