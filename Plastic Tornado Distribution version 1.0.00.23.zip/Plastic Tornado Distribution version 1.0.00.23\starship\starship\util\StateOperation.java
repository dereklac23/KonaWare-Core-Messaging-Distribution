package starship.util;

import java.awt.Dimension;
import java.awt.Graphics;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import starship.atom.*;


/*
 * 
 * The FileStateManager is used to manage the creation of folders and the content at the sub-level for both the Server and
 * the Client.
 * 
 * 
 */
public class StateOperation {

	
	   public enum SERVICE_LEVEL {
		   KERNEL,
		   SYSTEM,
		   FILE,
           COMMUNICATION,
		   REALM
	   }

  
   public enum SERVICE_EXECUTION {
	   INSTALL_IO,
	   INSTALL_GUI_SETS,
	   INSTALL_OPERATION_CLASS,
	   COMMUNICATE,
	   PROPAGATE
   }
   LinkedList <ClientExecutionFunction> listStatus= new LinkedList<ClientExecutionFunction>();
   JTextArea taOutput = new JTextArea ();
   LocalContainer localContainerL1=null;
   public ClientExecutionFunction cef;
   public StateOperation( LocalContainer _loC) {   
               
	   localContainerL1 = _loC;
	    
	   
	   listStatus.add(new ClientExecutionFunction(
			   _loC,
			   SERVICE_LEVEL.SYSTEM,
			   SERVICE_EXECUTION.PROPAGATE
			   ));
	   
	   listStatus.add(new ClientExecutionFunction(_loC,
			   
			   SERVICE_LEVEL.COMMUNICATION,
			   SERVICE_EXECUTION.INSTALL_GUI_SETS
			   ));
	  
	   listStatus.add(new ClientExecutionFunction(_loC,
			   SERVICE_LEVEL.COMMUNICATION,
			   SERVICE_EXECUTION.COMMUNICATE
			   ));

   }

   
   private boolean hasServiceMatch(SERVICE_LEVEL _sLevel, SERVICE_EXECUTION _sExecution) {
	   Iterator iter = listStatus.iterator();
	   ClientExecutionFunction fes =null;
	   
	   while (iter.hasNext())  {
		   fes = (ClientExecutionFunction)iter.next();
		   if (fes.serviceLevel == _sLevel && fes.serviceExecution == _sExecution ) {
			   return true;
		   }
	   
	   }
	   return false;
	   
   }

   
   public void execute(SERVICE_LEVEL _sLevel, SERVICE_EXECUTION _sExecution)  {
	     if (!hasServiceMatch(_sLevel , _sExecution)) {
	    	 return;
	     }
		
		 if (_sLevel == SERVICE_LEVEL.SYSTEM && _sExecution== SERVICE_EXECUTION.PROPAGATE) {
			 localContainerL1.soClientProvision = new SOClientProvision();
			  
		 } else if (_sLevel== SERVICE_LEVEL.COMMUNICATION && _sExecution== SERVICE_EXECUTION.COMMUNICATE) {
			 
			 localContainerL1.soClientCommunicate = new SOClientCommunicate2(localContainerL1);
			 localContainerL1.soClientCommunicate.doExecute();
		 } else  if (_sLevel == SERVICE_LEVEL.COMMUNICATION && _sExecution == SERVICE_EXECUTION.INSTALL_GUI_SETS ) {
			 
			 localContainerL1.soClientInstallGui= new SOClientInstallGui(localContainerL1);
			 localContainerL1.soClientInstallGui.doExecute();
			 
			  
		 }
	  		   
	   
   }
   
   
 
      
	
	
	
	
	public class ClientExecutionFunction {
		 
		
		private String actionLable=null;
		private String descripition=null;
		private String errorLabel=null;
		public ExecCallable fec=null;
		
		
		public SOClientProvision fecProvision=null;
		public SOClientCommunicate2 fecReceive=null;
		
		public SERVICE_LEVEL serviceLevel  = null;
		public SERVICE_EXECUTION serviceExecution= null;
		public ClientExecutionFunction(
				LocalContainer _localC,
				SERVICE_LEVEL _serviceLevel,
				SERVICE_EXECUTION _serviceExecution) {
		  localContainerL1 = _localC;
		  
		  serviceLevel = _serviceLevel;
		  serviceExecution =_serviceExecution;
		  
		}
		

		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
	
}
