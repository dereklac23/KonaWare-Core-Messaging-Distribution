package releasetool;

public abstract interface SeafloorExec {
	
	public enum LEVEL { BASEMENT0, BASEMENT1, BASEMENT2, BASEMENT3}; 
    public enum TYPE { PROVISION, ASSEMBLE, PROPAGATE};
    public enum ATTR  {SETTINGS, HTML_MAIN, SEAFLOOR, SKYLINE};
	
	public abstract void doExecute(LocalContainer _lc, LEVEL _level, TYPE _type, ATTR _attr);
	public abstract void doExecute( ATTR _attr) throws KCMException ;
	
}
 