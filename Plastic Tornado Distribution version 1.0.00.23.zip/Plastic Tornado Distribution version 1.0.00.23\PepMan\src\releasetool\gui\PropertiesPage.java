package releasetool.gui;



import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.Enumeration;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import releasetool.LocalContainer;


public class PropertiesPage  extends JPanel {
	private static int WIDTH=600, HEIGHT=200;
	public JTable tableList  = new JTable(new MyTableModel());
	private LocalContainer globalContainer=null;
	private String[][] data = {
    		{"File name", ""},
    		{"X Pos", "0"},
    		{"Y Pos", "0"}
    };
 
    public PropertiesPage(LocalContainer gc) {
        globalContainer = gc;		
		JScrollPane scrollPane = new JScrollPane(tableList);
		add(scrollPane);
		tableList.setPreferredScrollableViewportSize(new Dimension(WIDTH-30, HEIGHT/3));
		tableList.setDefaultRenderer(JLabel.class, new SettingsRenderer());
		Enumeration e = tableList.getColumnModel().getColumns();
	    TableColumn col = (TableColumn) e.nextElement();

	    col.setCellRenderer(tableList.getDefaultRenderer(String.class));
	    col.setCellEditor(tableList.getDefaultEditor(String.class));
    }

	
	class MyTableModel extends AbstractTableModel {
	    private String[] columnNames = {"Name", "Value"};
	    

	    public int getColumnCount() {
	        return 2;
	    }

	    public int getRowCount() {
	        return data.length;
	    }

	    public String getColumnName(int col) {
	        return columnNames[col];
	    }

	    public Object getValueAt(int row, int col) {
	        return data[row][col];
	    }

	   
	    /*
	     * Don't need to implement this method unless your table's
	     * editable.
	     */
	    public boolean isCellEditable(int row, int col) {
	        //Note that the data/cell address is constant,
	        //no matter where the cell appears onscreen.
	        return (col ==1);
	        
	    }

	    /*
	     * Don't need to implement this method unless your table's
	     * data can change.
	     */
	    public void setValueAt(Object value, int row, int col) {
	        data[row][col] = (String)value;
	        fireTableCellUpdated(row, col);
	    }
	    
	}

	public class SettingsRenderer extends JLabel implements TableCellRenderer {
		 
	    public SettingsRenderer()
	    {
	        super.setOpaque(true);
	    }
	     
	    @Override
	    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
	        boolean hasFocus, int row, int column)
	    {
	    	if (isSelected) {
	    		System.out.println("is selcted");
	    	}
	        String label= (String) value;
	        setText(value.toString()+"33");
	        if(label == "X Pos") {
	            super.setBackground(Color.GREEN);
	        }  else {
	        	super.setBackground(Color.PINK);
	        }
	        
	         
	        return this;
	    }
	     
	}
	
}
