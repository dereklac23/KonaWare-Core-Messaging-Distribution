package wepiano;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.sound.midi.MidiDevice;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Receiver;
import javax.sound.midi.Sequencer;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.Transmitter;
import javax.swing.BoxLayout;
import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.table.AbstractTableModel;

//import konaware.client.gui.FileProperties.FileObject;

public class WePianoFrame extends JFrame {
	PianoDialog pd=null;

	public static int WIDTH=800, HEIGHT=550;
	private JTable table= null;
	private JComboBox combo=null;
	private JScrollPane scrollPane =null;
	private Vector<MidiStructure> vectorMidi=null;
	private CellRenderer cellRender = null;
	private ArrayList<MidiStructure> structList = new ArrayList<MidiStructure>(); 
	@SuppressWarnings("unchecked")
	public WePianoFrame () {
    super("wepiano");
    
    
	
    super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    
    

    JPanel paneMain = new JPanel(); 
    		//(JPanel) getContentPane();
    
   
    vectorMidi = new Vector<MidiStructure>();
    MyTableModel tableModel = new MyTableModel(vectorMidi);
    
    
    JPanel topPanel = new JPanel();
    
    topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
    topPanel.add(new JLabel("Device:"));
    topPanel.add(combo=new JComboBox());
    topPanel.setPreferredSize(new Dimension(10,10));
    topPanel.setSize(10, 20);
    
    populate();
    combo.setModel(tableModel);
    paneMain.setLayout(new BoxLayout(paneMain, BoxLayout.Y_AXIS));
    paneMain.add(topPanel);
    //tableModel.addListDataListener(this);
    
    combo.setRenderer(new CellRenderer(vectorMidi));
    combo.setSize(new Dimension(40,40));
    combo.validate();
    
    
    paneMain.add(pd = new PianoDialog());
    
//    tableModel.
    //combo.revalidate();
    vectorMidi.add(new MidiStructure());    
    paneMain.setPreferredSize(new Dimension(600,800));
    
    setContentPane(paneMain);
    
    super.pack();
    //setSize(new Dimension(400,400));
    
    
    
    
//    combo.f
    
    super.setVisible(true);
    
    super.addWindowListener(new WindowAdapter()
		  {
		      public void windowClosing(WindowEvent e)
		      {
		      }
		  });
    super.revalidate();
	}
	private void populate() {
		  try {
	          // Get and open the default MIDI device
	          MidiDevice.Info[] infos = MidiSystem.getMidiDeviceInfo();
	          MidiDevice device = null;
	          for (MidiDevice.Info info : infos) {
	              device = MidiSystem.getMidiDevice(info);
	              if (device.getMaxTransmitters () != 0) {
	                  //break;
	              }
	              
	              device.open();
	              System.out.println("\n@Opened MIDI device: " + device.getDeviceInfo().getDescription());
	              vectorMidi.add(new MidiStructure(device));
	              device.close();
	          }
	          
	          if (device == null) {
	              System.out.println("No MIDI input device found.");
	              return;
	          }

	          
	          System.out.println("\n=Opened MIDI device: " + device.getDeviceInfo().getDescription());

	          // Get the transmitter and set a receiver to handle incoming messages
	          Transmitter transmitter = device.getTransmitter();
	          transmitter.setReceiver(new MidiInputReceiver());
	          
	          Sequencer seq = MidiSystem.getSequencer();
	          Transmitter  seqTrans = seq.getTransmitter();
	          
	          seqTrans.setReceiver(new MidiInputReceiver());
	          
	          Synthesizer synth = MidiSystem.getSynthesizer();
	          Receiver synthRcvr = synth.getReceiver();
	          
	        
	          

	      } catch (MidiUnavailableException e) {
	          e.printStackTrace();
	      }

		  }
	
	

	
	}
	


