package konaware.atom;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import konaware.client.gui.MenuLayer2;
import konaware.client.gui.MenuLayer3;
import konaware.util.StateOperation.SOClientProvision;
import konaware.util.KWMessageWrapper;
import konaware.util.RealmRenderFunction;
import konaware.util.StateOperation;
import konaware.util.StateOperation.SOClientCommunicate;
import konaware.util.StateOperation.SOClientInstallGui;
import konaware.client.gui.MenuLayer1;

public class LocalContainer {
  //public JPanel panel=null;  
  //public JButton btnLocal=null, btnTomcat=null;
  //private PathUtil pathUtil = new PathUtil();
  //public MenuLayer3 menuLayer3=null;

  
  public KWMessageWrapper messageWrapper=null;
  public enum LEVEL_TYPE {LEVEL1, LEVEL2, LEVEL3}
  public LEVEL_TYPE levelNumber= LEVEL_TYPE.LEVEL1;  
  //System output
  public JTextArea taTextArea=null;
  
  //Layer 1 data set
  public JTextField tfHostName, tfContextName, tfServletName;
  
  public SOClientProvision soClientProvision=null;
  
  //Layer 2
  public KWMessageWrapper kwMessageWrapper=null;
  public SOClientCommunicate soClientCommunicate=null;
  public SOClientInstallGui  soClientInstallGui=null;
  
  //Layer 3
  
  public RealmRenderFunction realmRenderFunction = new RealmRenderFunction();
  public int realmBorderWidth=0, realmBorderHeight=0;
  
  
  
  public LocalContainer globalContainerPointer =null;
  public LocalContainer (int _w, int _h) {
  	    realmBorderWidth = _w;
	    realmBorderHeight=_h;
	     
	    
	  
  }
  public LocalContainer(JTextField _tfHostname, JTextField _tfServletName, JTextField _tfContextName) {
	  tfHostName = _tfHostname;
	  tfServletName = _tfServletName;
	  tfContextName = _tfContextName;
	  
  }
  
  public LocalContainer(LocalContainer _globalC, LEVEL_TYPE _lt)  {
	  levelNumber=_lt;
	  globalContainerPointer=_globalC;
	  
	  
  }
  
  public LocalContainer(LEVEL_TYPE _lt)  {
      levelNumber = _lt;
	  if (_lt == LEVEL_TYPE.LEVEL2) {
	              
	    		
	  }
	  
  }
  public int getLevel() {
	  return levelNumber.ordinal();
  }
  public LocalContainer getLocalContainer() {
	  return globalContainerPointer;
  }
  public LocalContainer getGlobalContainer() throws AtomException {
	  if (levelNumber == LEVEL_TYPE.LEVEL1) throw new AtomException("Root level does not have global container pointer");
	  else return globalContainerPointer;
	  
  }

  /*
   * 
   * 
  public KWAtom getAtom(String _key) {
	  KWAtom atomPair [] =messageWrapper.getAtom(_key);
	  
	  return atomPair[1]; 
  }*/
  //public MenuLayer1 cps=null;
  /*
  public JPanel getBIOSPanel() {
	  
	   panel=new JPanel();
	   
	   fileChooserWorking.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);	   
	   fileChooserTomcat.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);	   
	   btnLocal= new JButton("Select LOCAL directory for disk storage");	 
	   
       btnLocal.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               // Show a message dialog when the button is clicked
           	 int returnVal = fileChooserWorking.showOpenDialog(panel);

                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooserWorking.getSelectedFile();                    
					if (file.isDirectory()) {
						btnLocal.setEnabled(false);
						fileChooserWorking.setCurrentDirectory(file);
						
						 
                } 
           }
       }              
       }); 
        
       
	   btnTomcat= new JButton("Select TOMCAT directory");	   
       btnTomcat.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               // Show a message dialog when the button is clicked
           	 int returnVal = fileChooserTomcat.showOpenDialog(panel);

                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooserTomcat.getSelectedFile();
                   
					if (pathUtil.checkTomcatDirectory(file)) {
						btnTomcat.setEnabled(false);
						fileChooserTomcat.setCurrentDirectory(file);
						
					} else {
						System.out.println("WORKING not set properly.");
					}
                } else {
                }
           }
       });
       panel.add(btnLocal);
       panel.add(btnTomcat);
       
       return panel;
       
  }
 */
   
  
}
