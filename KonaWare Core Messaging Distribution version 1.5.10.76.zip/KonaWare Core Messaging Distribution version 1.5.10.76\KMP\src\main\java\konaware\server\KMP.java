package konaware.server;

import jakarta.servlet.ServletContext;
import java.io.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import konaware.server.util.*;
//import konaware.util.KWMessageWrapper;


import java.io.IOException;
import java.io.PrintWriter;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

/**
 * Servlet implementation class KMP
 */
@WebServlet("/KMP")
public class KMP extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public konaware.server.KMPGateway pointerGateway=null;
    SOServerFunction ssf = new SOServerFunction();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public KMP() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * 
     * A general class to be created as an instance during the KMPGateway startup phase.
     * KMPGeneral has attribute load-on-startup. Within the init method, it will create 
     * a new instance called KMP("Description");
     * 
     * KMPGeneral will pass a pointer reference to pointerGateway to be used as inter-process
     * communication. 
     * 
     * @param string
     */
	public KMP(String description) {
		// TODO Auto-generated constructor stub
		
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 * 
	 * In order to transfer atoms to and from the client, you can use the KWMessageWrapper to house
	 * the KWHashMap containing KWAtom for the relay. See {@link KWMessageWrapper#KWMessageWrapper(java.net.URI, String, String)} 
	 * to get Dthe KWHashMap message using HttpServlet's doGet() routine.
	 * and {@link KWMessageWrapper#KWMessageWrapper(java.net.URI) to get KwHashMap message using HttpServlet's doPost routine;
	 * 
	 * On the server side, the instance creation is through this constructor KWMessageWrapper#KWMessageWrapper(PrintWriter) where
	 * the PrinterWriter can be obtained through the use of HttpServletResponse#getWriter().
	 * 
	 *  
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		  
//		   LocalSlocalS = (LocalServerContainer)getServletContext().getAttribute(KMPGateway.GLOBAL_CONTAINER);
		 ServletContext context = request.getServletContext();
		 //ssf.execute(SOServerFunction.MESSAGE_COMMAND.PROVISION, localS);
		 context.log("executing ssf SEND command");
		 if (ssf !=null) {
		 ssf.execute(SOServerFunction.MESSAGE_COMMAND.SEND); 
		 }
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		/*
		  ServletContext context = getServletContext();
		  //String returnStr = getStringFormInputStreamString(request);
		  
		  // * KonaWare Core Messaging 1.0 
		  PrintWriter printWriter= response.getWriter(); 
		  //System.out.println(printWriter)
		  KWMap map1 = new KWMap(KWMap.KWTYPE.STRING);
		  
		  KWMap mapInstance = map1.getInstance(KWMap.HEADER_TEXT);
		  mapInstance.write(printWriter);
		  KWMap map2 = new KWMap(KWMap.KWTYPE.INT);	
		  
		  mapInstance = map2.getInstance(String.valueOf(KWMap.HEADER_INT));
		  context.log("The ordinal is ..."+mapInstance.ordinal);
		  context.log("The token is ..."+ mapInstance.kwTokenMap[mapInstance.ordinal].token);
		  mapInstance.write(printWriter);
		  
		  context.log("Context path:"+request.getContextPath()+":"+request.getServletPath()+
		  request.getServletContext().getRealPath(File.separator));
		  
		  */
		  
		  /** KonaWare Core Messaging 1.2 **/
		  PrintWriter pw = new PrintWriter(response.getWriter());
//		  KWMessageWrapper kmw  = new KWMessageWrapper(pw);
	//	  kmw.add( KWAtom.HEADER_TEXT); 
		//  kmw.add(KWAtom.HEADER_INT);
		 // kmw.Send();
		   
 
		  
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * 
	 * The use of KWMessageWrapper to allow the message to be sent is through the 
	 * string tag kw-octet-stream.send and kw-octet-stream.receive.
	 * The octet streaming is only allow in the doPost routine.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = request.getServletContext();
		
		InputStream is =request.getInputStream();
		if (is==null) {
			context.log("is null");	
		}
		BufferedReader br = new BufferedReader( new InputStreamReader(is));
		
		String line =br.readLine();
		while ((line = br.readLine()) !=null) {
			if (line.equals("kw-atom")) {
				 PrintWriter pw = new PrintWriter(response.getWriter());
				 //KWMessageWrapper kmw  = new KWMessageWrapper(pw);
				 //kmw.add( KWAtom.HEADER_TEXT);
				 //kmw.add(KWAtom.HEADER_INT);
				 //kmw.Send();	
			} else if (line.equals("kw-octet-stream")) {
				line = br.readLine();
				if (line !=null) {
					
					context.log(request.getContextPath());
					context.log(line);
					
				}
				
			}	
		}
		  PrintWriter pw = new PrintWriter(response.getWriter());
//		  KWMessageWrapper kmw  = new KWMessageWrapper(pw);
	//	  kmw.add( KWAtom.HEADER_TEXT); 
		//  kmw.add(KWAtom.HEADER_INT);
		//  kmw.Send();

			
	}

}
