package konaware.server;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import konaware.server.util.DimensionServerStateOperation;
//.import konaware.util.DimensionStateOperation;
import konaware.server.util.LocalServerContainer;
//import konaware.util.KWMessageWrapper;
import konaware.server.util.SOServerFunction;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.imageio.ImageIO;

/**
 * Servlet implementation class ClockPng
 */
@WebServlet("/RealmSpace")
public class RealmSpace extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public final static String BOARD_PROVISION_X_STRING="board.x.provision";
	public final static String BOARD_PROVISION_Y_STRING="board.y.provision";
    public final static int BOARD_WIDTH=500, BOARD_HEIGHT=600;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RealmSpace() {
        super();
        // TODO Auto-generated constructor stub
    }
    private BufferedImage createRealmPage(DimensionServerStateOperation dso) {
        GregorianCalendar cal = new GregorianCalendar();
        if (dso ==null) {
        	return null;
        }
        BufferedImage img = new BufferedImage(dso.getWidth(), dso.getHeight(), BufferedImage.TYPE_3BYTE_BGR);
        Graphics2D g = img.createGraphics();

        // white background
        g.setColor(Color.ORANGE);
        g.fillRect(0, 0, dso.getWidth(), dso.getHeight());


        // draw hour hand
        return img;
    }



	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		DimensionServerStateOperation dso = processParameters(request);
		process( response, dso);
		
	}



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		DimensionServerStateOperation dso = processParameters(request);
		process(response, dso);


	}
	
	private void process( HttpServletResponse response, DimensionServerStateOperation dso) throws ServletException , IOException {
	    
	    
	    response.setContentType("image/png");
		OutputStream os = response.getOutputStream();
		BufferedImage image =createRealmPage(dso);
		if (image ==null) {
		return;	
		} else {
			ImageIO.write(image, "PNG", os);  // write image as PNG (more)		
		}
	}
	
	  private DimensionServerStateOperation processParameters(HttpServletRequest request) throws ServletException, IOException {
		  ServletContext context =this.getServletContext();
		  
		  SOServerFunction ssf = (SOServerFunction)getServletContext().getAttribute(KMPGateway.GLOBAL_CONTAINER);
		  DimensionServerStateOperation dsoPrime = ssf.getDSO();
		  if (ssf.getDSO() == null) {
			  return null;
		  }
		  context.log("\nGetting dso information:"+dsoPrime.getDescribeString());
		 return dsoPrime;
		  
	  }

}
