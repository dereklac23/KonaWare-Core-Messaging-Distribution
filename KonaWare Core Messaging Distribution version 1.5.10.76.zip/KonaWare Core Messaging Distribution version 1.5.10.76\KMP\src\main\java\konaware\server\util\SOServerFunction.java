package konaware.server.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ProtocolException;
import java.util.LinkedList;

import jakarta.servlet.ServletContext;

//import konaware.atom.KWHashMapEntry;
//import konaware.atom.KWHashMapEntry;
import konaware.server.KMPGateway;
import konaware.server.RealmSpace;
//import konaware.util.DimensionStateOperation;
//import konaware.util.KWAtom;
//import konaware.util.RealmRenderFunction;
//import konaware.util.StateOperationException;
import konaware.server.atom.KWServerHashMapEntry;

public class SOServerFunction  {

	public enum HASHMAP_WEB { PROVISION,  PRINT_TABLE,ADD, EDIT, REMOVE, CHECK, SEND};
    public  enum HTML_PARTS { HEAD, BODY, TAIL};
    public enum MESSAGE_COMMAND {PROVISION, FLATTEN, SEND, PUT};
	public KWServerMessageWrapper kwMessageWrapper=null;
	
    private DimensionServerStateOperation dso =null;
	public LocalServerContainer localContainer=null;
	public ServletContext servletContext=null;
	
	public SOServerFunction() {
		this(null);
		localContainer = new LocalServerContainer();
		kwMessageWrapper = new KWServerMessageWrapper();
		
	}
	public  SOServerFunction(LocalServerContainer _lc) {
		localContainer = _lc;
		/*
		hashMapCall[HASHMAP_WEB.PROVISION.ordinal()] = new HMProvision();
		hashMapCall[HASHMAP_WEB.PRINT_TABLE.ordinal()] = new HMPrintTable();
		hashMapCall[HASHMAP_WEB.ADD.ordinal()] = new HMAdd();
		hashMapCall[HASHMAP_WEB.EDIT.ordinal()] = new HMEdit();
		hashMapCall[HASHMAP_WEB.REMOVE.ordinal()] = new HMRemove();
		hashMapCall[HASHMAP_WEB.CHECK.ordinal()] = new HMCheck();
		hashMapCall[HASHMAP_WEB.SEND.ordinal()] = new HMSend();
		*/
		

		
	}
	public DimensionServerStateOperation getDSO() {
		return dso;
	}
	public void execute(MESSAGE_COMMAND mCommand, LocalServerContainer _lSC) {
		if (mCommand== MESSAGE_COMMAND.PROVISION) {
			localContainer = _lSC;
			dso = _lSC.dso;
			//kwMessageWrapper = new KWServerMessageWrapper();
		} 
		
	}
	public void execute(MESSAGE_COMMAND mCommand , DimensionServerStateOperation _dso) {
		if (mCommand== MESSAGE_COMMAND.PUT) {			
			dso = _dso;
			//kwMessageWrapper = new KWServerMessageWrapper();
		} 
	} 
	
	public void execute(MESSAGE_COMMAND mCommand) {
		if (mCommand == MESSAGE_COMMAND.FLATTEN) {
			
		} else if (mCommand == MESSAGE_COMMAND.SEND) {
		 	kwMessageWrapper.Send();
		} else if (mCommand == MESSAGE_COMMAND.PUT) {
			KWServerHashMapEntry mapEntryX = new KWServerHashMapEntry(
			  RealmSpace.BOARD_PROVISION_X_STRING, 
			  RealmSpace.BOARD_WIDTH);
		 	
			kwMessageWrapper.Put(RealmSpace.BOARD_PROVISION_X_STRING,mapEntryX);
			
			KWServerHashMapEntry mapEntryY = new KWServerHashMapEntry(
					  RealmSpace.BOARD_PROVISION_Y_STRING, 
					  RealmSpace.BOARD_HEIGHT);
				 	
					kwMessageWrapper.Put(RealmSpace.BOARD_PROVISION_Y_STRING,mapEntryY);
			dso = new DimensionServerStateOperation (mapEntryX, mapEntryY); 
		}
	}
	public void execute(ServletContext _con) {
		servletContext = _con;
	}
	
	
	
    
}

