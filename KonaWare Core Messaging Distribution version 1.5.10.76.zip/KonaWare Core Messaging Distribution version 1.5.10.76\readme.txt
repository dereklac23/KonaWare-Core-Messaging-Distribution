

In order to test of the KMP Gateway is working, use the following URL:
http://localhost:8080/KMP/KMP

Should see the following text:

string
KWGateway 0.1
int
4269

Next run the Java Application:

KWLauncher, go to the "Development" tab. Make sure the URL is the same as the KMP Gateway:
http://localhost:8080/KMP/KMP

You see the following responses:
KWGateway 0.1
4269
Response code verified match!
 


This version, "KonaWare Core Messaging.zip" has two options for HTTP pipe transfer: kw-atom and kw-octet-stream. Both are assembled to a KWHashMap using the KWMessageWrapper as an utility.


To deploy the War file after you package it from the konaware-core-api.jar, make you the jar file is located at KMP/src/main/WEB-INF/lib. It has to be a jar file and not extract. Next add the classpath into your build-path. Because the HttpServlet requires servlet.jar make sure you download the servlet.jar file from Apache.

If you don't have the right  classpath correctly, Eclipse will show up in the IDE as unknown API. 
If you don't have KonaWareMessageCore_1.24.jar then Tomcat will complain you do not have not have the konaware.util.* classes.

To package KonaWareMessageCore_1.24.jar (or whatever name you want to call it), use the export option to export the KonaWare directory. They contain the konaware.util dclasses. 

The javadoc is located in KonaWare/doc directory.


The both the Tomcat distribution requires Apache XPath API is called Xerces2.  They can be downloaded at: https://xerces.apache.org/xerces2-j/index.html. The actual download page is: https://xerces.apache.org/mirrors.cgi
 Make sure to add xml-api.jar to the build path for KMP (server) and KonaWare (client) distribution. 

The servlet.jar from Apache is required for KMP. Make sure in Eclispe you right-click on WEB-INF/lib and add "import->folder" to point to the servlet.jar. Next select the jar to add. That copies the jar for distribution. You can distribute or run it on external Tomcat the KMP.war using the export command. To run the war file externally, export the KMP.war file to $TOMCAT/webapps directory. 


Release notes: 1/5/2025
KonaWare Core Messaging Distribution has a "cleaner" release by getting rid of Eclipse files and use only the required source and import jar from Apache for distribution. The directory are: KMP, KMP/doc, KMP/src, KonaWare, KonaWare/doc/, KonaWare/src


 


