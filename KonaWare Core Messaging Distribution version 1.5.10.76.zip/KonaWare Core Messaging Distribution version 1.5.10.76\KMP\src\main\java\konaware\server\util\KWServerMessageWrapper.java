package konaware.server.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import jakarta.servlet.ServletContext;
//import konaware.atom.KWHashMapEntry;
import konaware.server.atom.KWServerHashMapEntry;  

//import konaware.atom.HWHashMapEntry;
/*
 * 
 * The wrapper is used to house the KWHashMap to be transported using a BufferedWriter or
 * BufferedReader. This wrapper is shared for both client and server API.
 * 
 * To use this wrapper as part of the HttpServlet api, put this jar file (KonaWareCoreMessage_1xx.jar)
 * into the WEB-INF/lib. Make sure you do not extract the jar file.
 * 
 * To import on Eclipse, you use the import->file system to package the jar into the WEB/lib 
 * directory. Next, add the path in Build Path -=> Configure Build Path.
 * 
 * 
 * 
 */

public class KWServerMessageWrapper {

	public PrintWriter printWriter=null;
    private InputStream inputStream=null;
    private BufferedReader bufferedReader =null;
 	HashMap <String, KWServerHashMapEntry> kwMapEntry = 
 			new HashMap<String, KWServerHashMapEntry>();
    Map<String, KWServerHashMapEntry> eMap =  Collections.synchronizedMap(kwMapEntry);
	        private static char DIV='/';		 
		 	

 	/*
 	 * 
 	 * If the hostname, context, and servlet name is given, this is a post HttpServlet request.
 	 * A kw-atom (also known as a James Clear Data Type, is the fundamental building block 
 	 * of a KWHashMap that is housed in the KWMessageWrapper.
 	 * Alternative to kw-atom, there is kw-octet-stream which is used for file upload and download. 
 	 * 
 	 * 
 	 * 
 	 */  
 	public KWServerMessageWrapper(PrintWriter _pwm, InputStream _is) {
       printWriter = _pwm;
       inputStream  = _is;
       bufferedReader = new BufferedReader(new InputStreamReader(_is));
       
       
 	}
 	public KWServerMessageWrapper() {
 		
 	}
 	public void Put(String key, KWServerHashMapEntry _entry) {
 	   eMap.put(key, _entry);	
 	}
 	public void Send() {
 		  KWServerHashMapEntry entry=null;
          Set<String> keySet=eMap.keySet();
          for (Iterator iter = keySet.iterator(); iter.hasNext(); 
        		    entry = (KWServerHashMapEntry)iter.next()) {
        	  printWriter.println(entry.getKeyAtom().toString());
        	  printWriter.println(entry.getDataAtom().toString());
        	  
          }
          eMap.get(keySet);
          
 		
 	}
 	/*
 	public void doGetSend() throws AtomException {
 		StringAtom atomKey = (StringAtom)AtomCore.getAtom("string");
 		atomKey.setString(RealmSpace.BOARD_PROVOISION_X_STRING);
 		printWriter.println(atomKey.toString());
 	}
 	public void put(String key, int data) {
 		/*
 		KWAtom keyAtom = new KWAtom (KWAtom.KWTYPE.STRING);
 		keyAtom.setData(key);
 		KWAtom dataAtom= new KWAtom(KWAtom.KWTYPE.INT);
 		dataAtom.setData(Integer.toString(data));
 		
 		KWAtom atomPair[] = new KWAtom[2];
 		atomPair[0] = keyAtom;
 		atomPair[1] = dataAtom;
 		System.out.println("\n@@@--putting into the map"+key);
 		kwMapHME.put(key,  atomPair);
 		*/
 		
 	
/*
 	
 	public void addEntry(String _key, int _value) throws AtomException {
 		  try {
 			StringAtom iAtomString = (StringAtom)AtomCore.getAtom("string");
			IntegerAtom iAtom = (IntegerAtom)AtomCore.getAtom("int");
			iAtom.setInteger(_value);
 		  } catch (AtomException ae) {
 			  
 		  }
			
			
		//} catch (AtomException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
	//	}
 			
 	}
 	*/
/*
 	public void clearMap() {
 		kwMapEntry.clear();
 	}
 	*/
/*
 	public void put(KWHashMapEntry entry) {
 		kwMapEntry.put(entry.getKey(), entry);
 		
 	}
 */
 	public void print(ServletContext context,PrintWriter printWriter) {
 		/*
 		Iterator <String> iterator = kwMapEntry.keySet().iterator();
 		
		while (iterator.hasNext()) {			
			String  key= (String)iterator.next();
			context.log("\nprint at the KWServerMessageWrapper:"+key);
			KWHashMapEntry mapEntry=(KWHashMapEntry) kwMapEntry.get(key);
			
			
			
		}
		*/
 		
 	}
/*
 	public String describeString() {
 		StringBuffer sb = new StringBuffer();
        Iterator <String> iterator = kwMapEntry.keySet().iterator();
 		
		while (iterator.hasNext()) {			
			String  key= (String)iterator.next();
			KWHashMapEntry entry=(KWHashMapEntry) kwMapEntry.get(key);
				
			//sb.append(entry.describeString());
			//sb.append(entry.describeString()); 
			
			
		}
		return sb.toString();
 	}
 	
 	*/


	
	

}