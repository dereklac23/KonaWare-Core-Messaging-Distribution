package konaware.client.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import konaware.atom.LocalContainer;
import konaware.util.StateOperation;


public class MenuLayer2 extends JPanel {

	public  enum STATE {PRESYSTEM, INACTIVE, ACTIVE};
	private enum MENUTYPE {FILE, EDIT, CLOUD, HELP};
	//private STATE state=STATE.INACTIVE;
	private JTextArea taDisplay = new JTextArea(10,8);
	 
	private LocalContainer globalContainer;
	private PanelProperties panelProperties ;
	//SOClientReceive soReceive= null;
	//StateOperation stateOperation =null;
	StateOperation sOperation =null;
	public MenuLayer2 (LocalContainer locL1) {
		
		JPanel panel = new JPanel();
		
        LocalContainer localContainerL2 = new LocalContainer(locL1, LocalContainer.LEVEL_TYPE.LEVEL3);
		localContainerL2.taTextArea = taDisplay;
        sOperation = new StateOperation(localContainerL2);
        
		
	    panelProperties = new PanelProperties(globalContainer);
		
		panel.setLayout(new GridLayout(1,4));
	    panel.add(new MenuObject( MENUTYPE.FILE));
	    panel.add(new MenuObject( MENUTYPE.EDIT));
	    panel.add(new MenuObject( MENUTYPE.CLOUD));
	    panel.add(new MenuObject( MENUTYPE.HELP));
	  
	    setLayout(new BorderLayout());
	    add(BorderLayout.NORTH, panel);
	    add(BorderLayout.CENTER, panelProperties);
	    
	    JScrollPane jsp=new JScrollPane(taDisplay, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	    add(BorderLayout.SOUTH, jsp);
	    
	     
	   
	   
	  
	}
	
	 public void setState(STATE _st, File _file) {
		 if (_st== STATE.ACTIVE) {
			//fso.executeState(FileLevelService.SYSTEM, FileStateType.PROVISION, _file); 
		 }
	 }
	 JButton btnNew=null, btnClose=null, btnSaveAs=null, btnOpen=null; //group file
	 JComboBox cmbMessageArray  =null;
	 JButton btnCloudGo=null;
	 public JPanel getVerticalPanel(String _title, MENUTYPE mt) {
		
		JPanel panel = new JPanel();
		JFileChooser fileChooser = new JFileChooser();
		if (mt == MENUTYPE.FILE) {
			panel.setLayout(new GridLayout(4,1));
			panel.add(new JLabel("File") );
			panel.add(btnNew = new JButton("New") );
			panel.add(btnOpen = new JButton("Open"));
			panel.add(btnClose = new JButton("Close") );
			panel.add(btnSaveAs = new JButton("Save As") );
			
			btnNew.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	 // Show a message dialog when the button is clicked
	              	 int returnVal = fileChooser.showOpenDialog(panel);

	                   if (returnVal == JFileChooser.APPROVE_OPTION) {
	                       File file = fileChooser.getSelectedFile();
	                       //fso.executeState(FileLevelService.FILE, FileStateType.CREATE,globalContainer);
	                       panelProperties.setVisible(true);
	   					
	                   } else {
	                   }
	              }
	          });

	     
		} else if (mt == MENUTYPE.EDIT) {
			panel.add(new JLabel("Edit") );
		} else if ( mt == MENUTYPE.CLOUD) {
			panel.add(new JLabel("Cloud operation:") );
			String items[] = {"Send", "Delete", "List"};
			panel.add(cmbMessageArray=new JComboBox(items));
			cmbMessageArray.add(fileChooser);
			panel.add(btnCloudGo = new JButton("Cloud 'Go'"));
			btnCloudGo.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	
	            	sOperation.execute(StateOperation.SERVICE_LEVEL.COMMUNICATION,
	        				StateOperation.SERVICE_EXECUTION.COMMUNICATE);
	        				
	            }
	          });

		} else if (mt == MENUTYPE.HELP) {
			panel.add( new JLabel("Help") );
		}
		return panel;
		 
	 }
	 
	 class MenuObject extends JButton {
		 
		 MenuObject(MENUTYPE mt) {
			 if (mt== MENUTYPE.FILE) {
				 super.add(getVerticalPanel("File", MENUTYPE.FILE));				 
			 } else if (mt == MENUTYPE.EDIT) {
				 super.add(getVerticalPanel("Edit", MENUTYPE.EDIT));
			 } else if (mt == MENUTYPE.CLOUD) {
				 super.add(getVerticalPanel("Cloud", MENUTYPE.CLOUD));
			 } else if (mt == MENUTYPE.HELP) {
				 super.add(getVerticalPanel("HELP", MENUTYPE.HELP));
			 }
		 }
	 }
}
