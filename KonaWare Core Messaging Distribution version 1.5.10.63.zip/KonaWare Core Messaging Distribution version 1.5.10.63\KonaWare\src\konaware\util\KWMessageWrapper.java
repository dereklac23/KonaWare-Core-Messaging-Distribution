package konaware.util;

import java.awt.Dimension;
import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;

import konaware.atom.AtomCore;
import konaware.atom.AtomException;
import konaware.atom.KWHashMapEntry;
import konaware.atom.LocalContainer;
//import konaware.util.KWAtom.KWTYPE;

/*
 * 
 * The wrapper is used to house the KWHashMap to be transported using a BufferedWriter or
 * BufferedReader. This wrapper is shared for both client and server API.
 * 
 * To use this wrapper as part of the HttpServlet api, put this jar file (KonaWareCoreMessage_1xx.jar)
 * into the WEB-INF/lib. Make sure you do not extract the jar file.
 * 
 * To import on Eclipse, you use the import->file system to package the jar into the WEB/lib 
 * directory. Next, add the path in Build Path -=> Configure Build Path.
 * 
 * 
 * 
d */

public class KWMessageWrapper {
	private PrintWriter printWriter=null;
    StringBuffer returnBuffer = new StringBuffer();
 	int contentLength=27;
 //	LinkedList <KWAtom>    kwList= new LinkedList<KWAtom>();
 	//HashMap <String,KWAtom[]> kwMapArray=
 		//	 new HashMap<String,KWAtom[]>();
 	
 	//Map<String, KWAtom[]> aMap =  Collections.synchronizedMap(kwMapArray);
 	
 	HashMap <String,KWAtom[]> kwMapHME=
			 new HashMap<String,KWAtom[]>();
 	
 	Map<String, KWAtom[]> eMap =  Collections.synchronizedMap(kwMapHME);
 	private static char DIV='/';		 
 	
 	/*
 	 * 
 	 * If the hostname, context, and servlet name is given, this is a post HttpServlet request.
 	 * A kw-atom (also known as a James Clear Data Type, is the fundamental building block 
 	 * of a KWHashMap that is housed in the KWMessageWrapper.
 	 * Alternative to kw-atom, there is kw-octet-stream which is used for file upload and download. 
 	 * 
 	 * 
 	 */
 	private HttpURLConnection connection=null;
 	private String contextName =null, servletName=null, hostName =null;
 	public KWMessageWrapper() {
 		
 	}
 	private URI getURI(String _hostname, String _context, String _servlet) 
 			throws URISyntaxException {
 		return new URI(_hostname+ DIV + _context + DIV + _servlet);
 	}
 	URL urlString;
 	public KWMessageWrapper(String _hostname, String _context, String _servletname) 
 				 throws StateOperationException {
 		   try {
 	  	      URI uri = getURI(_hostname, _context, _servletname);
 			   urlString = uri.toURL();
 			  //connection = (HttpConnection) 
 			  System.out.println("url is"+ urlString.toString());
 			  //connection = (HttpURLConnection)url.openConnection();
 			  contextName = _context;
 			  servletName=_servletname;
 		   } catch (IOException ioe ) {
 			   throw new StateOperationException ("IOE Exception within KWMessageWrapper");
 		   } catch (URISyntaxException uri) {
 			   throw new StateOperationException ("URI Syntax within KWMessageWrapper");
 		   }
 	}


 	

/*
 * This KWMessageWrapper constructor takes in the file name for file upload and download requests.
 * If the deposition argument is "download" then it is saved to the local client with fileName as the file persistent name. 
 * If the deposition argument is  "upload" then it is uploaded to the HttpServer with the context path being the root and the
 * fileName is as file persistent name. 
 * 
 * 
 */
private LocalContainer globalContainer=null;
public KWMessageWrapper(LocalContainer gc) {
	globalContainer = gc;
}
private URL url=null;
public KWMessageWrapper(URI hostname, String context, String servletname, String fileName) 
		 throws StateOperationException  {
	 try {

	
	  urlString= hostname.toURL();		
	  connection = (HttpURLConnection)urlString.openConnection(); 
	  connection.setRequestMethod("POST");
	  connection.setDoOutput(true);
	 } catch (IOException ioe) {
		throw new StateOperationException("IO exception with KWrapper"); 
	 } 
}
    /*
	public void put(String _key, KWAtom _map) throws AtomException {
 		if (_key==null) {
 			throw new AtomException("Key is null"); 			
 		} else if (_map==null) {
 			throw new AtomException("Data is null");
 			
 		}
 		KWAtom atomPair [] = new KWAtom[2];
 		atomPair[0] = new KWAtom(KWAtom.KWTYPE.STRING);
 		atomPair[1] = _map;
 		aMap.put(_key, atomPair);
 		
 	}
 	*/
/*

	public KWAtom get(String _key) {
 		KWAtom mapPair []=( KWAtom[]) aMap.get(_key);
 		return mapPair[1];
 	}
*/

	public KWMessageWrapper(PrintWriter pw) throws IOException {
		printWriter =pw;
	}
	
	
	public void add(String data) {
		
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.STRING);
		map[1].setData(data);
		
	
		
	}
	
	
	public void add(long data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.LONG);
		map[1].setData(String.valueOf(data));
		
		
	}

	public void add(double data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.DOUBLE);
		map[1].setData(String.valueOf(data));
	}

	public void add(float data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.FLOAT);
		map[1].setData(String.valueOf(data));
	}

	public void add(boolean data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.BOOLEAN);
		map[1].setData(String.valueOf(data));
	}

	public void add(char data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.CHAR);
		map[1].setData(String.valueOf(data));
	}

	public void add(short data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.SHORT);
		map[1].setData(String.valueOf(data));
	}

	public void add(byte data) {
		KWAtom map []= new KWAtom[2];
		map[1]= new KWAtom(KWAtom.KWTYPE.BYTE);
		map[1].setData(String.valueOf(data));
	}
	
   public KWAtom getDataEntry(String _key) {
     KWAtom [] mapArray =eMap.get(_key);
     return mapArray[1];
   }
  

   public void put(String _key, KWAtom _entry) throws AtomException {
	   KWAtom entryKey = new KWAtom(_key);
	   entryKey.setData(_key);
	   KWAtom pairEntry [] = new KWAtom[2];
	   pairEntry[0] = entryKey;
	   pairEntry[1] = _entry;
       eMap.put(_key, pairEntry);
    }
   public void put(KWHashMapEntry entry) {
	   String key=entry.getKeyAtom().getString();
	   KWAtom pair[] = new KWAtom [2];
	   
	   pair[0]=  entry.getKeyAtom();
	   pair[1]=  entry.getDataAtom();
	   eMap.put(key, pair);
   }
 
    public synchronized DimensionStateOperation getDSO (KWHashMapEntry _widthEntry, 
    		                      KWHashMapEntry _heightEntry) throws AtomException {
    	
    	return  new DimensionStateOperation(_widthEntry, _heightEntry);
    	
    	
    }
    public void Send(KWAtom atom) throws IOException {
    	printWriter.println(atom.tokenType);
    	printWriter.println(atom.getData());
    }
    
	public void Send() throws IOException {	  
		Iterator <String> iterator = eMap.keySet().iterator();
		while (iterator.hasNext()) {			
			String  key= (String)iterator.next();
			KWAtom pair[] =(KWAtom[]) eMap.get(key);
			printWriter.println(pair[0].getString());
			printWriter.println(pair[1].getString());	
			
		}
	}
	
	public String DescribeEachItem() {
		returnBuffer.setLength(0);
		Iterator <String> iterator = eMap.keySet().iterator();
		while (iterator.hasNext()) {			
			String  key= (String)iterator.next();
			KWAtom pair[] =(KWAtom[]) eMap.get(key);
			if (pair[0]!=null && pair [1] != null) {
			printWriter.println(pair[0].getString());
			printWriter.println(pair[1].getString());
			}
			
		}
		return returnBuffer.toString();
	}
	
	public String DescribeString() {
		return returnBuffer.toString();
	}
	/*
	public String DescribeEachItemString() {
	 StringBuffer sbReturn = new StringBuffer();
	// Iterator iter=kwMapHME.listIterator();
//	 while (iter.hasNext()) {
		// KWAtom atom = (KWAtom)iter.next();
	//	 sbReturn.append(atom.tokenType +":"+atom.getData()+"\n");
	 }
	 //return sbReturn.toString();
	*/
	
	public void ReceiveFillMap() throws StateOperationException {
//		 try {
//		 	  connection = (HttpURLConnection)urlString.openConnection();		 	  
	//		  connection.setRequestMethod("POST");
		//	  connection.setDoOutput(true);
		/*
			  BufferedReader in = new BufferedReader(
					new InputStreamReader(connection.getInputStream()));
					*/
			  String token=null, line=null, key=null;
			  KWAtom pair[] = new KWAtom [2];
			  /*
			       while ((token=in.readLine()) !=null) {
			    	   
			    	   KWAtom atomKey= new KWAtom(token);
			    	   System.out.println("\nReceiveFill map token:<"+token+">");
			    	   key  = token;
			    	   atomKey.setData(in);
			    	   KWAtom atomData=null;
			    	   if ((token=in.readLine()) !=null) {
			    		   atomData = new KWAtom(token);   
			    	   } else {
			    		   throw new StateOperationException("Protocol mismatch in ReceiveFillMap 1");
			    	   }
			    	   if ((line=in.readLine()) !=null) {
			    		   atomData.setData(line);   
			    	   } else {
			    		   throw new StateOperationException("Protocol mismatch in ReceiveFillMap 2");
			    	   }
			    	   pair[0]= atomKey;
			    	   pair[1]= atomData;
			    	   
			    	   //KWHashMapEntry entry = new KWHashMapEntry(pair);
			    	   
			    	   
			    	   eMap.put(key, pair);
			    	   
			    	     
				         returnBuffer.append("token:"+pair[0].getString() +":"+pair[1].getString());	    	   
			       } 
			         */
				//	in.close();
			       /*
		       } catch (ProtocolException pe) {
		    	   
		    	   System.out.println("pro e");
		    	   throw new StateOperationException("\nprotocol error"+pe.toString());
		       } catch (IOException ioe) {
		    	   System.out.println("ioe");
		    	   throw new StateOperationException("\nerror"+ioe.toString());
		       } catch (AtomException ae) {
		    	   System.out.println("Miss match protocol for ReceiveFilMap routine");
		       }
		       */
	}
	
	//!!@doGet
	public void doGet() throws StateOperationException {
	       //try {
		/*
	      connection = (HttpURLConnection)urlString.openConnection(); 
		  connection.setRequestMethod("GET");
		  BufferedReader in = new BufferedReader(
				new InputStreamReader(connection.getInputStream()));
		  String token=null;
		       while ((token=in.readLine()) !=null) {
		    	   
		    	 //  AtomCore aCore = AtomCore.getAtom(token);
		    	   
		    	   
		    	   
		    	   
		    	   
			         
			       	    	   
		       }
		         
				in.close();
	       } catch (ProtocolException pe) {
	    	   throw new StateOperationException(pe.toString());
	       } catch (IOException ioe) { 
	    	   System.out.println("\nioe error");
	    	   throw new StateOperationException(ioe.toString());
	       } /*catch (AtomException ae) {
	    	   System.err.println("Procol mismatch data line is null");
	       }*/
		
	}


	
public void doPostBiDirection() throws StateOperationException {
	 String token=null;
	 String line=null;
	      try {
		  connection.setRequestMethod("POST");
		  connection.setDoOutput(true);
		  PrintWriter pw= new PrintWriter(connection.getOutputStream());
		  String header = "POST /"+contextName+"/"+servletName+" HTTP/1.1"+"\n\n";		  
		  pw.write(header);		  
		  pw.write("Host: "+hostName+"\n");
		  pw.write("Content-Type: application/x-www-form-urlencoded\n");
		  pw.write("Content-Length: "+contentLength+"\n");
		  pw.write("kw-atom");
		  pw.close();
		  KWAtom map=null;	  
		  BufferedReader in = new BufferedReader(
				new InputStreamReader(connection.getInputStream()));
		 
		  
		  while ((line = in.readLine()) !=null) {
			  
			  KWAtom key= new KWAtom(line);  
			  KWAtom data = new KWAtom(in);
			  KWAtom pair[] = new KWAtom[2];
			  pair[0] = key;
			  pair[1]= data;
			  eMap.put(line , pair);
			   
		  }
		  
		    	   
			         	    	   
		        
		  in.close();
	      } catch (ProtocolException pe) {
	    	   throw new StateOperationException(pe.toString());
	       } catch (IOException ioe) {
	    	   throw new StateOperationException(ioe.toString());
	       }  catch (AtomException ae) {
				  System.err.println("Error in protcol inputstream reading for token"+token);
			  }
	}

public void doPost2() throws StateOperationException   {
	try {
    connection=(HttpURLConnection)urlString.openConnection(); 
	connection.setRequestMethod("POST");
	connection.setDoOutput(true);
	PrintWriter pw= new PrintWriter(connection.getOutputStream());
    String header = "POST /"+contextName+"/"+servletName+" HTTP/1.1"+"\n\n";		  
	pw.write(header);		  
	pw.write("Host: "+hostName+"\n");
	pw.write("Content-Type: application/x-www-form-urlencoded\n");
	pw.write("Content-Length: "+contentLength+"\n");
	pw.write("kw-octet-stream\n");
	pw.close();
	KWAtom map=null;	  
	  BufferedReader in = new BufferedReader(
			new InputStreamReader(connection.getInputStream()));
	  String token=null;
	  String line=null;
	       while ((token=in.readLine()) !=null) {
	    	   /*
	    	   System.out.println("\n reading line of input"+token);
	    	   KWAtom atom1 = new KWAtom(token);
	    	   line = in.readLine();
	    	   atom1.setData(line);
	    	   
	    	   KWAtom atom2 = new KWAtom(in);
	    	   line = in.readLine();
	    	   atom2.setData(line);
	    	   
	    	   KWAtom pair [] = new KWAtom[2];
               eMap.put(atom1.getData(), pair);
		         */
		        // returnBuffer.append(line);
	       }
	in.close();
	
	
	}  catch (MalformedURLException mfe) {
		throw new StateOperationException(mfe.toString());
	} catch (ProtocolException pe) {
		throw new StateOperationException(pe.toString());
	} catch (IOException ioe) {
		System.out.println("ioe exception in doPost:" +(ioe ==null));
		throw new StateOperationException(ioe.toString());
	} 
		  
}
/*
	public Dimension getRealmDimension()  throws AtomException {
 		Dimension dim= new Dimension();
 		KWAtom atWidth = kwMap.get(RealmRender2.REALM_BORDER_X);
 		KWAtom atHeight = kwMap.get(RealmRender2.REALM_BORDER_Y); 		
 		if (atWidth ==null || atHeight ==null) {
 			throw new AtomException(RealmRender2.REALM_BORDER_X +" or " + RealmRender2.REALM_BORDER_Y +" attribute not found");
 		} 			
        dim.width= atWidth.getInt();
 		dim.height= atHeight.getInt();
 		return dim;
 		
 	}
 	
 		  PrintWriter pw= new PrintWriter(connection.getOutputStream());
	  String header = "POST /"+context+"/"+servletname+" HTTP/1.1"+"\n\n";		  
	  pw.write(header);		  
	  pw.write("Host: "+hostname+"\n");
	  pw.write("Content-Type: application/x-www-form-urlencoded\n");
	  pw.write("Content-Length: "+contentLength+"\n");
	  //pw.write("octet-stream");	  
	  pw.write("kw-octet-stream\n");
	  pw.write(fileName+"\n");
	  pw.close();
	  KWAtom map=null;	  
	  BufferedReader in = new BufferedReader(
			new InputStreamReader(connection.getInputStream()));
	  String token=null;
	  String line=null;
	       while ((token=in.readLine()) !=null) {
	    	   KWAtom map1 = new KWAtom(token);
		         map1.setData(in);
		         kwList.add( map1);
		         line = "token:"+map1.tokenType +":"+map1.getData();
		         returnBuffer.append(line);
		         	    	   
	       }
	         
			in.close();

*/
}
