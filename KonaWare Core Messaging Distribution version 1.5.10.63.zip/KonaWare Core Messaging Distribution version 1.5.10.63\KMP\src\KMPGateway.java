package konaware.server;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import konaware.atom.KWHashMapEntry;
//import konaware.atom.KWHashMapEntry;
import konaware.server.util.DimensionServerStateOperation;
import konaware.server.util.LocalServerContainer;

/**
 * Servlet implementation class GeneralKMP
 */
@WebServlet(
		urlPatterns = { "/KMPGateway" }, 
		initParams = { 
				@WebInitParam(name = "load-on-startup", value = "1", description = "The Global Servlet Initialization Entry Point")
		})
public class KMPGateway extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public final static String GLOBAL_CONTAINER="global.container";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public KMPGateway() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = request.getRequestDispatcher("KMP");
		rd.forward(request, response);
	}

	
	public static DimensionServerStateOperation getDSO(ServletContext _context, String _width, String _height) {
		
		int width  = (int)Integer.parseInt(_width);
		int height = (int)Integer.parseInt(_height);
		_context.log("\nCreating DSO");		 
		KWHashMapEntry mapWidth  = new KWHashMapEntry(RealmSpace.BOARD_PROVOISION_X_STRING, width);
		KWHashMapEntry mapHeight  = new KWHashMapEntry(RealmSpace.BOARD_PROVOISION_X_STRING, height);
	    DimensionServerStateOperation dso = new DimensionServerStateOperation(Integer.parseInt(_width),
	    		Integer.parseInt(_height));
		return dso;
		 
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = request.getRequestDispatcher("KMP");
		rd.forward(request, response);
		servletKMP.doPost(request, response);
	}
	
	 private static final String SERVLET_CONTEXT_KEY_INIT_PARAMETER = "KMP";

	konaware.server.KMP servletKMP;
    public void destroy()
    {
       // servletKMP.destroy();
    }

    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException
    {
        servletKMP.service(req, res);
    }
    
    public void init() throws ServletException
    {
    	
    	servletKMP = 
    			new konaware.server.KMP("General Gateway to be used for inter-process communcation among over konaware.server.* servlets");
    			 
        servletKMP.pointerGateway=this;
        //getServletContext().setAttribute("context", servletKMP);
    	getServletContext().setAttribute(KMPGateway.GLOBAL_CONTAINER, new LocalServerContainer());
    }


}
