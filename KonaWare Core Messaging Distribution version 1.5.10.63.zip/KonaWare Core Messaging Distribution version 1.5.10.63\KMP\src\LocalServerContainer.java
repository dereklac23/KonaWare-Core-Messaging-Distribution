package konaware.server.util;

public class LocalServerContainer {

	public LocalServerContainer() {
		
	}
}
