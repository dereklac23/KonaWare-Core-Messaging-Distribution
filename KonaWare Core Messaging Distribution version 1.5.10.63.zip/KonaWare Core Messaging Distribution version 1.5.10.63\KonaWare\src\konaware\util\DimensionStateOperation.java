package konaware.util;

import java.awt.Color;
import java.awt.Graphics;
import java.io.PrintWriter;

import konaware.atom.KWHashMapEntry;

public class DimensionStateOperation {
	
	//public int  width =0, height=0;
	/*
    public final static String
		  BOARD_WIDTH ="board.width", BOARD_HEIGHT = "board.height"; 
	*/
	public KWHashMapEntry eWidth=null, eHeight=null;
	public DimensionStateOperation(KWHashMapEntry _eWidth, KWHashMapEntry _eHeight) {
		System.out.println("\nAllocating DSO"+ _eWidth.getKeyAtom().describeString() +":"+
	                      _eHeight.getKeyAtom().describeString());
		eWidth = _eWidth;
		eHeight= _eHeight;
		 
		 
	 }
	 public void print(PrintWriter pw) {
		
		 
		 eWidth.Print(pw);
		 eHeight.Print(pw);
	     
	 }
	 public int getWidth() {
		 return Integer.parseInt(eWidth.getDataAtom().getData());
	 }
	 
	 public int getHeight() {
		 return Integer.parseInt(eHeight.getDataAtom().getData());
	 }
	 public String getDescribeString() {
		StringBuffer sb = new StringBuffer();
		sb.append("\n Describing DSO"+ getWidth() + ":"+ getHeight());
		return sb.toString();
	 }

	 public void paintComponent(Graphics g) {
		 int width = Integer.parseInt(eWidth.getDataAtom().getString());
		 int height = Integer.parseInt(eHeight.getDataAtom().getString());
		 g.setColor(Color.PINK);
		 g.fillRect(0, 0, width, height);				          
		 g.setColor(Color.GRAY);
		 g.fillRect(10, 10, width-20, height-20);
	 }
}
