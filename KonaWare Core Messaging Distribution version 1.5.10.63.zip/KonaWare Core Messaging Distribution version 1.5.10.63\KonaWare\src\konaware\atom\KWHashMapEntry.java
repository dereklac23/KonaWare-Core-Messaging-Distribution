package konaware.atom;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

import konaware.util.KWAtom;
import konaware.util.KWMessageWrapper;

public class KWHashMapEntry {
    private KWAtom key=null, data=null;
    
	public KWHashMapEntry(String _key, KWAtom _data) {
		key = new KWAtom(KWAtom.KWTYPE.STRING);
		System.out.println("\nallocating new key"+ _key);
		key.setData(_key);
		data=_data;
		System.out.println("\nallocating data"+ data.describeString());
	    	
	} 
	
	
	public KWAtom getKeyAtom() {
		return key;
	}
	public KWAtom getDataAtom() {
		return data;
	}
	public String getKey() {
		return key.getData();
	}
	
	public KWHashMapEntry(String _key, int _data) {
		System.out.println("\n!!!Creating a new hash map entry"+ _key);
		key = new KWAtom(KWAtom.KWTYPE.STRING);
		key.setData(_key);
		
		data= new KWAtom (KWAtom.KWTYPE.INT);		
	    data.setData(Integer.toString(_data));
		
	}
	public KWHashMapEntry (String _key) {
		key = new KWAtom(KWAtom.KWTYPE.STRING);
		key.setData(_key);
		
		data= new KWAtom (KWAtom.KWTYPE.STRING);		
	    data.setData(_key);
	}
	
	
	public void Send(KWMessageWrapper mWrap) throws AtomException  {
		try {
		mWrap.Send(key);
		mWrap.Send(data);
		} catch (IOException ioe) {
			throw new AtomException(ioe.toString());
		}
	}
	public void Print(PrintWriter printWriter) {
	   	key.printString(printWriter);
	   	data.printString(printWriter);
	}
	public KWHashMapEntry(BufferedReader bufferedReader) {
	
		  String token = null;
		  try {
		  while ((token = bufferedReader.readLine())!=null) {
			  KWAtom atomKey = new KWAtom(token);
			  
			  
			  String dataToken = bufferedReader.readLine();
			  if (dataToken ==null) {
				  throw new AtomException ("Error in receiving key part of the exchange protocol for KWHashMapEntry");
			  }
			  atomKey.setData(dataToken);
			  
			  
			  token= bufferedReader.readLine();
			  if (token==null) {
				  throw new AtomException ("Error in receiving key part of the exchange protocol for KWHashMapEntry");
			  }

			  
			  KWAtom atomData = new KWAtom(token);
			  dataToken = bufferedReader.readLine();
			  if (dataToken ==null) {
				  throw new AtomException ("Error in receiving data part of the exchange protocol for KWHashMapEntry");
			  }
			  atomData.setData(dataToken);
			  key = atomKey;
			  data = atomData;
			  
			  
		  }
		  
		  } catch (IOException ioe) {
			  System.err.println("IOE in reading into KWHashMapEntry");
		  } catch (AtomException aoe) {
			  System.err.println("Protocol mismatch in KWHashMapEntry");
		  }
	}
	public String printString() {
		StringBuffer sb = new StringBuffer ();
		sb.append(key.getString());
		sb.append(data.getString());
	    return sb.toString();	
	}
}
