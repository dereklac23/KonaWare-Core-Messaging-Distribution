package konaware.server.util;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import jakarta.servlet.ServletContext;
import konaware.server.atom.AtomCore;
import konaware.server.atom.AtomException;
import konaware.server.atom.IntegerAtom;

import konaware.server.atom.KWServerHashMapEntry;
import konaware.server.atom.StringAtom;  

//import konaware.atom.HWHashMapEntry;
/*
 * 
 * The wrapper is used to house the KWHashMap to be transported using a BufferedWriter or
 * BufferedReader. This wrapper is shared for both client and server API.
 * 
 * To use this wrapper as part of the HttpServlet api, put this jar file (KonaWareCoreMessage_1xx.jar)
 * into the WEB-INF/lib. Make sure you do not extract the jar file.
 * 
 * To import on Eclipse, you use the import->file system to package the jar into the WEB/lib 
 * directory. Next, add the path in Build Path -=> Configure Build Path.
 * 
 * 
 * 
 */

public class KWServerMessageWrapper {

	public PrintWriter printWriter=null;
    
    private BufferedReader bufferedReader =null;
 	HashMap <String, KWServerHashMapEntry> kwMapEntry = 
 			new HashMap<String, KWServerHashMapEntry>();
    Map<String, KWServerHashMapEntry> eMap =  Collections.synchronizedMap(kwMapEntry);
	        private static char DIV='/';
	public ServletContext context=null;
		 	

 	/*
 	 * 
 	 * If the hostname, context, and servlet name is given, this is a post HttpServlet request.
 	 * A kw-atom (also known as a James Clear Data Type, is the fundamental building block 
 	 * of a KWHashMap that is housed in the KWMessageWrapper.
 	 * Alternative to kw-atom, there is kw-octet-stream which is used for file upload and download. 
 	 * 
 	 * 
 	 * 
 	 */  
 	public void Provision( BufferedReader _br, PrintWriter _pW) {
       printWriter = _pW;
       bufferedReader = _br;
       
       
 	}
 	public KWServerMessageWrapper() {
 		
 	}
 	public void Put(String key, KWServerHashMapEntry _entry) {
 	   eMap.put(key, _entry);	
 	}
 	public void Put(KWServerHashMapEntry _entry) {
 		eMap.put(_entry.getKey(), _entry);
 	}
 	public KWServerHashMapEntry Get(String _key) {
 		return eMap.get(_key);
 	}
 	public void Put(DimensionServerStateOperation _dso) {
 		Put(_dso.eWidth);
 		Put(_dso.eHeight);
 	}
 	public void Send() {
 		  
          Set<String> keySet=eMap.keySet();
          
          if (context!=null) {
              context.log("\nkey size"+keySet.size());
          }
          for (Map.Entry<String, KWServerHashMapEntry> entry : eMap.entrySet()) {
        	  
        	  if (context!=null) {
        		  context.log("\nSending Realm for x and y border");
        	  } 
        	  String key= entry.getKey();
        	  KWServerHashMapEntry mapEntry = entry.getValue();
        	  
        	  StringAtom atomString = mapEntry.getKeyAtom();
        	  AtomCore   atomData   = mapEntry.getDataAtom();
        	  if (atomData instanceof IntegerAtom) {
        		  IntegerAtom atomDataI = (IntegerAtom)atomData;
        		  atomString.print(printWriter);
        		  atomDataI.print(printWriter);
        	  }
        	  
        	  }
          
 		
 	}
 	
 	public void doComGet(ServletContext _context) {
 		_context.log("\nDo Com Get");
 		Send();
 	}
 	public void print(ServletContext context,PrintWriter printWriter) {
 		
 	}

	
	

}
