package konaware.util;

import java.awt.Color;
import java.awt.Graphics;
import java.io.PrintWriter;

import konaware.atom.IntegerAtom;
import konaware.atom.KWHashMapEntry;


public class DimensionStateOperation {
	public final static String BOARD_PROVISION_X_STRING="board.x.provision";
	public final static String BOARD_PROVISION_Y_STRING="board.y.provision";
	
	public KWHashMapEntry eWidth=null, eHeight=null;
	public DimensionStateOperation(KWHashMapEntry _eWidth, KWHashMapEntry _eHeight) {
		eWidth = _eWidth;
		eHeight= _eHeight;
		 
		 
	 }
	 public void print(PrintWriter pw) { 
		 eWidth.Print(pw);
		 eHeight.Print(pw);	     
	 }
	 public int getWidth() {
		 IntegerAtom atomI = (IntegerAtom)eWidth.getDataAtom();
		 return atomI.getInteger();
	 }
	 
	 public int getHeight() {
		 IntegerAtom atomI = (IntegerAtom)eHeight.getDataAtom();
		 return atomI.getInteger();
	 }
	 
	 public String getDescribeString() {
		StringBuffer sb = new StringBuffer();
		sb.append("\n Describing DSO"+ getWidth() + ":"+ getHeight());
		return sb.toString();
	 }

	 public void paintComponent(Graphics g) {
		 int width = getWidth();
		 int height = getHeight();
		 
		 g.setColor(Color.PINK);
		 
		 g.fillRect(0, 0, width, height);				          
		 
	 }
}
