package wepiano;  
import javax.sound.midi.MidiDevice;

public class MidiStructure {
    	private MidiDevice device =null;
    	private MidiDevice.Info nameInfo=null;
    	private int maxTransmitter=0;
    	
    	public MidiStructure (MidiDevice _device) {
    		device=_device;
    		nameInfo = _device.getDeviceInfo();
    		maxTransmitter = _device.getMaxTransmitters();
    	}
    	public MidiStructure () {
    		
    	}
    	public String getInfo() {
    		return nameInfo.getDescription();
    	}
    	
    }