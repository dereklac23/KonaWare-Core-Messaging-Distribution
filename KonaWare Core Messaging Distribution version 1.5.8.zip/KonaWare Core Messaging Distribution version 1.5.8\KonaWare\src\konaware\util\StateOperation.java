package konaware.util;

import java.awt.Dimension;
import java.awt.Graphics;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/*
 * 
 * The FileStateManager is used to manage the creation of folders and the content at the sub-level for both the Server and
 * the Client.
 * 
 * 
 */
public class StateOperation {
	   public enum SHARE_CLASS {
		   ROOT,
		   SIBLING,
		   DEFAULT,
	   }

	
	   public enum SERVICE_LEVEL {
		   KERNEL,
		   SYSTEM,
		   FILE,
           COMMUNICATION,
		   REALM
	   }

  
   public enum SERVICE_EXECUTION {
	   INSTALL_IO,
	   INSTALL_GUI_SETS,
	   INSTALL_OPERATION_CLASS,
	   COMMUNICATE,
	   PROPAGATE
   }
   LinkedList <ClientExecutionFunction> listStatus= new LinkedList<ClientExecutionFunction>();
   JTextArea taOutput = new JTextArea ();
   LocalContainer localContainer=null;
   public ClientExecutionFunction cef;
   public StateOperation( LocalContainer _loC) {
	   
               
	   localContainer = _loC;
	    
	   
	   listStatus.add(new ClientExecutionFunction(
			   _loC,
			   SERVICE_LEVEL.SYSTEM,
			   SERVICE_EXECUTION.PROPAGATE
			   ));
	   
	   listStatus.add(new ClientExecutionFunction(_loC,
			   SHARE_CLASS.ROOT,
			   SERVICE_LEVEL.COMMUNICATION,
			   SERVICE_EXECUTION.INSTALL_GUI_SETS
			   ));
	  
	   listStatus.add(new ClientExecutionFunction(_loC,
			   SERVICE_LEVEL.COMMUNICATION,
			   SERVICE_EXECUTION.COMMUNICATE
			   ));

   }
   private boolean hasServiceMatch(SERVICE_LEVEL _sLevel, SERVICE_EXECUTION _sExecution, SHARE_CLASS _shareClass) {
	   Iterator iter = listStatus.iterator();
	   ClientExecutionFunction fes =null;
	   
	   while (iter.hasNext())  {
		   fes = (ClientExecutionFunction)iter.next();
		   if (fes.serviceLevel == _sLevel && fes.serviceExecution == _sExecution && fes.shareClass == _shareClass) {
			   return true;
		   }
	   
	   }
	   return false;
   }
   
   private boolean hasServiceMatch(SERVICE_LEVEL _sLevel, SERVICE_EXECUTION _sExecution) {
	   Iterator iter = listStatus.iterator();
	   ClientExecutionFunction fes =null;
	   
	   while (iter.hasNext())  {
		   fes = (ClientExecutionFunction)iter.next();
		   if (fes.serviceLevel == _sLevel && fes.serviceExecution == _sExecution ) {
			   return true;
		   }
	   
	   }
	   return false;
	   
   }

   
   public void execute(SERVICE_LEVEL _sLevel, SERVICE_EXECUTION _sExecution)  {
	     if (!hasServiceMatch(_sLevel , _sExecution)) {
	    	 return;
	     }
		
		 if (_sLevel == SERVICE_LEVEL.SYSTEM && _sExecution== SERVICE_EXECUTION.PROPAGATE) {
			 localContainer.soClientProvision = new SOClientProvision();
			  
		 } else if (_sLevel== SERVICE_LEVEL.COMMUNICATION && _sExecution== SERVICE_EXECUTION.COMMUNICATE) {
			 localContainer.soClientCommunicate = new SOClientCommunicate(localContainer);
			 localContainer.soClientCommunicate.doExecute();
		 }
	  		   
	   
   }
   
   public void execute(SERVICE_LEVEL _sLevel, SERVICE_EXECUTION _sExecution, SHARE_CLASS _sClass)  {
	     if (!hasServiceMatch(_sLevel , _sExecution, _sClass)) {
	    	 return;
	     }
		
		 if (_sLevel == SERVICE_LEVEL.COMMUNICATION && _sExecution == SERVICE_EXECUTION.INSTALL_GUI_SETS && 
				 _sClass == SHARE_CLASS.ROOT) {
			 System.out.println("level for gui"+ localContainer.getLevel());
			 localContainer.soClientInstallGui= new SOClientInstallGui(localContainer);
			 localContainer.soClientInstallGui.doExecute();
			 
			  
		 } 
	  		   
	   
 }
 
      
	public interface ExecCallable {
		//public abstract void doExecute(LocalContainer localContainer) throws AtomException ;
		public abstract void doExecute();
			
		
		
	}
	
	
	
	
	public class ClientExecutionFunction {
		 
		
		private String actionLable=null;
		private String descripition=null;
		private String errorLabel=null;
		public ExecCallable fec=null;
		
		
		public SOClientProvision fecProvision=null;
		public SOClientCommunicate fecReceive=null;
		
		
		public SHARE_CLASS shareClass=null;
		public SERVICE_LEVEL serviceLevel  = null;
		public SERVICE_EXECUTION serviceExecution= null;
		public ClientExecutionFunction(
				LocalContainer _localC,
				SHARE_CLASS _shareClass,
				SERVICE_LEVEL _serviceLevel,
				SERVICE_EXECUTION _serviceExecution) {
		  localContainer = _localC;
		  shareClass = _shareClass;
		  serviceLevel = _serviceLevel;
		  serviceExecution =_serviceExecution;
		  
		}
		
		public ClientExecutionFunction(
				LocalContainer _localC,
				SERVICE_LEVEL _serviceLevel,
				SERVICE_EXECUTION _serviceExecution) {
		  localContainer = _localC;		  
		  serviceLevel = _serviceLevel;
		  serviceExecution =_serviceExecution;
		  
		}

		
		
		
	}
	
	
	
	
	
	
	
	
	
	public class SOClientProvision implements ExecCallable {
        JTextField tfHost=null, tfContext=null, tfServlet=null;
        
        public SOClientProvision () {
        	
        	
        }
		public void doExecute() {
			// TODO Auto-generated method stub
			//localContainer.globalContainerPointer.soClientProvision =this;
				
		}
		
		
		
	}
	
	
	
	
	
	
	
	public class SOClientCommunicate implements ExecCallable {
		private LocalContainer containerPointer=null;
		
	    public SOClientCommunicate (LocalContainer _loc) {
          containerPointer = _loc;
        }
 
	
		@Override
		public void doExecute() {
			// TODO Auto-generated method stub
			localContainer.taTextArea.append("hello");
			try {
            LocalContainer globalPointer=localContainer.getGlobalContainer();
			KWMessageWrapper wrapper=null;
			
				 wrapper =
						new KWMessageWrapper(new URI(globalPointer.tfHostName.getText()),
								globalPointer.tfContextName.getText(), 
								globalPointer.tfServletName.getText());
				 
				 globalPointer.kwMessageWrapper= wrapper;
				 localContainer.taTextArea.append("gc level:"+localContainer.levelNumber.toString());
				 wrapper.ReceiveFillMap();
				} catch (IOException  | URISyntaxException uri) {
					System.out.println("error in connection");
					localContainer.taTextArea.append("\nError in connection");
				} catch (AtomException ae) {
					System.out.println("\nAtom exception"+ ae.toString());
				} catch (StateOperationException soe) {
					localContainer.taTextArea.append("\nState opeation"+soe.toString());
				}
				
			
			/*
				KWMessageWrapper wrapper =localContainer.globalContainerPointer.kwMessageWrapper;
				try {
					//wrapper.ReceiveFillMap();
					//System.out.println(wrapper.DescribeEachItemString());
				} catch (StateOperationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			
				*/

			
		}



		
	}
	
	
	public class SOClientInstallGui implements ExecCallable {
		
	    
	    public JTextField tfHost=null, tfContext=null, tfServlet=null;
	    public LocalContainer globalContainerPointer=null, localContainer=null;
	    public JTextArea taDisplay=null;
	    
        public SOClientInstallGui (LocalContainer _localContainer) {
        	localContainer = _localContainer;
        	
        	
        	try {
			globalContainerPointer=localContainer.getGlobalContainer();
			taDisplay=localContainer.taTextArea;
        	taDisplay.append("hello menu 1:"+localContainer.tfHostName.getText());
            } catch (AtomException e) {
			// TODO Auto-generated catch block
			   taDisplay.append("\nAtom Exception");
		    }
        
        }

		@Override
		public void doExecute() {
			
		
			globalContainerPointer.tfServletName =
					localContainer.tfServletName;
			globalContainerPointer.tfContextName =
					localContainer.tfContextName;
			globalContainerPointer.tfHostName =
					localContainer.tfHostName;


			localContainer.taTextArea.append("gc level:"+globalContainerPointer.levelNumber.toString());
			
			
 			
			
		}//doExe


		
	}


	
	
	
}
