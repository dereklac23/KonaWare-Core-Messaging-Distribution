package konaware.util;

import java.io.IOException;

public class KWHashMapEntry {
    private KWAtom key=null, data=null;
    
	public KWHashMapEntry(String _key, KWAtom _data) {
		key = new KWAtom(KWAtom.KWTYPE.STRING);
		key.setData(_key);
	    data=_data;	
	}
	
	
	public KWAtom getKeyAtom() {
		return key;
	}
	public KWAtom getDataAtom() {
		return data;
	}
	
	public KWHashMapEntry(String _key, int _data) {
		key = new KWAtom(KWAtom.KWTYPE.STRING);
		key.setData(_key);
		
		data= new KWAtom (KWAtom.KWTYPE.INT);		
	    data.setData(Integer.toString(_data));
		
	}
	public KWHashMapEntry (KWAtom pairAtom[]) {
		key = pairAtom[0];
		data = pairAtom[1];
	}
	public void Send(KWMessageWrapper mWrap) throws AtomException  {
		try {
		mWrap.Send(key);
		mWrap.Send(data);
		} catch (IOException ioe) {
			throw new AtomException(ioe.toString());
		}
	}
	
}
