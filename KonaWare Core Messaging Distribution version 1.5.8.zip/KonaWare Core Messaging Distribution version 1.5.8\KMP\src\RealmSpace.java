package konaware.server;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import konaware.util.LocalContainer;
import konaware.util.KWMessageWrapper;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.imageio.ImageIO;

/**
 * Servlet implementation class ClockPng
 */
@WebServlet("/RealmSpace")
public class RealmSpace extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RealmSpace() {
        super();
        // TODO Auto-generated constructor stub
    }
    private BufferedImage createClockImage() {
        GregorianCalendar cal = new GregorianCalendar();

        BufferedImage img = new BufferedImage(400, 400, BufferedImage.TYPE_3BYTE_BGR);
        Graphics2D g = img.createGraphics();

        // white background
        g.setColor(Color.ORANGE);
        g.fillRect(0, 0, 400, 400);

        // draw black circle around clock
        g.setColor(Color.BLACK);
        g.setStroke(new BasicStroke(5));
        g.drawOval(20, 20, 360, 360);

        // draw hour hand
        double hourRad = cal.get(Calendar.HOUR) * 2 * Math.PI / 12 - 0.5 * Math.PI;
        g.drawLine(200, 200, 200 + (int) (100 * Math.cos(hourRad)), 
                   200 + (int) (100 * Math.sin(hourRad)));

        // draw minute hand
        double minuteRad = cal.get(Calendar.MINUTE) * 2 * Math.PI / 60 - 0.5 * Math.PI;
        g.drawLine(200, 200, 200 + (int) (170 * Math.cos(minuteRad)), 
                   200 + (int) (170 * Math.sin(minuteRad)));
        return img;
    }



	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		process(request, response);
		
	}


	
  private void processParameters(HttpServletRequest request, LocalContainer gc) throws ServletException, IOException {
	  LocalContainer gc = (LocalContainer)request.getAttribute("global.container");
	  String boardXString = 
			  request.getParameter(DimensionStateOperation.BOARD_X);
	  String boardYString = 
			  request.getParameter(DimensionStateOperation.BOARD_y);
	  
	  if (boardXString !=null && boardYString !=null && gc !=null) {
			
			ServletContext con = request.getServletContext();
			con.log("log: x, y"+ boardXString+":"+ boardYString);
			//KWMessageWrapper wmw = new KWMessageWrapper();
			
			//gc.kwLinkedList.add("");
		}
		
  }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		processParameters(request);


	}
	
	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException , IOException {
		
	    processParameter(request);	
		
		
		
		
					
		  
		response.setContentType("image/png");
		OutputStream os = response.getOutputStream();
		ImageIO.write(createClockImage(), "PNG", os);  // write image as PNG (more)		
	}

}
