package konaware.util;

import java.awt.Color;
import java.awt.Graphics;

public class DimensionStateOperation {
	
	public int  width =0, height=0;
    public final static String
		  BOARD_WIDTH ="board.width", BOARD_HEIGHT = "board.height"; 
	public DimensionStateOperation(KWAtom _widthAtom, KWAtom _heightAtom) {
			 if (_widthAtom !=null) {
				 width= _widthAtom.getInt();
				 height= _heightAtom.getInt();
				 
			 }
		 }
	
	 public DimensionStateOperation(KWHashMapEntry eWidth, KWHashMapEntry eHeight) {
		 String keyWidth = eWidth.getKeyAtom().getData();
		 String keyHeight = eWidth.getKeyAtom().getData();
		 width = Integer.parseInt(eWidth.getDataAtom().getData());
		 height = Integer.parseInt(eHeight.getDataAtom().getData());
		 
		 
		 
	 }
	 public void paintComponent(Graphics g) {
		 g.setColor(Color.PINK);
		 g.fillRect(0, 0, width, height);
		 g.setColor(Color.GRAY);
		 g.fillRect(10, 10, width-20, height-20);
	 }
}
