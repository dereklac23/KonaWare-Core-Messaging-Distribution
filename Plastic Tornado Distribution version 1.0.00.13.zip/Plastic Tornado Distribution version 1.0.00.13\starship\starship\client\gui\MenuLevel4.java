package starship.client.gui;
import starship.atom.*;
import starship.util.*;

import starship.util.RealmRenderFunction;

import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/


public class MenuLevel4 extends JDialog {
    private int width=0, height=0;
    
    private JPanel panelTopGui=null;
    JTextField jtfUser=null, jtfPassword=null;
    JButton    btnSend=null, btnConnect=null, btnTools=null;
    JTextField jtfURL =null;
    public enum STATE {INACTIVE, ACTIVE};
    public STATE stateCode =STATE.INACTIVE; 
    private CenterCanvas cCanvas=null;
    
    JPanel panelCredential=null, panelURL=null;
    public LocalContainer globalContainerL1=null;

    public MenuLevel4(int _w, int _h, LocalContainer _gcL1) {
    	super();
        
		globalContainerL1 = _gcL1;
	    width=_w; height=_h;
	    JPanel panel =(JPanel) super.getContentPane();  
	    panel.add(cCanvas = new CenterCanvas(_w, _h));
        
		  
		  super.addWindowListener(new WindowAdapter()
		  {
		      @Override
		      public void windowClosing(WindowEvent e)
		      {
		        MenuLevel4 rb = (MenuLevel4)e.getWindow();
		        rb.setState(STATE.INACTIVE);
		      }
		  });
		  
		  setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
		  panel.setSize(_w+225, _h+50);		  
		  super.setSize(_w+225, _h+50);
    }
	

	public void setState(STATE st) {
		this.setState(st, null);
		 
	}
	
	private LocalContainer globalContainerPointer =null;

	public void setState(STATE st, LocalContainer _globalP) {
		if (st == STATE.ACTIVE) {
			jtfUser.setEnabled(false);
			jtfPassword.setEnabled(false);
			btnConnect.setEnabled(false);
			
			btnTools.setEnabled(true);
			jtfURL.setEnabled(true);
			btnSend.setEnabled(true);
			globalContainerPointer=_globalP;
			

			globalContainerPointer.realmRenderFunction.setDSO(globalContainerPointer.getDSO());
			cCanvas.setRRF(globalContainerPointer.realmRenderFunction);
			
			
			super.revalidate();
			super.setVisible(true);
			
		} else if (st == STATE.INACTIVE) {
			jtfUser.setEnabled(true);
			jtfPassword.setEnabled(true);
			btnConnect.setEnabled(true);			
			btnTools.setEnabled(false);
			jtfURL.setEnabled(false);
			btnSend.setEnabled(false);			
			setVisible(false);
			
		}

	}

	 class BrowserWindowAdaptor extends WindowAdapter {
		 private MenuLevel4 realmBrowser;
		 public BrowserWindowAdaptor (MenuLevel4 rb) {
			 realmBrowser=rb;
		 }
	 }
	 }
