package starship.client.gui;
import starship.atom.*;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

import starship.util.*
;public class FileProperties  extends JPanel {
	private JTable tableList  = new JTable(new MyTableModel());
	private LocalContainer globalContainer=null;
	

     
    public FileProperties(LocalContainer gc) {
		globalContainer = gc;
		JScrollPane scrollPane = new JScrollPane(tableList);
		add(scrollPane);
		tableList.setPreferredScrollableViewportSize(new Dimension(KWLauncherFrame.WIDTH-30, KWLauncherFrame.HEIGHT/3));
		
		}
	
	ArrayList <FileObject > fileList = new ArrayList<FileObject>();
	public void populate(File _directory) {
		File files[] =_directory.listFiles();
		for (int i=0; i < files.length; i++) {
			fileList.add(new FileObject(files[i]));
		}
		tableList.revalidate();
		
	}
    public void execute() {
    	int rowSelected = tableList.getSelectedRow();
    	if (rowSelected == -1) {
    		return;
    	}
    	FileObject fObj = fileList.get(rowSelected);
    	char [] bufferChar = new char[1024];
    	try {
			//PrintWriter pWriter = new PrintWriter(fObj.file);
			BufferedReader bReader = new BufferedReader(new FileReader(fObj.file));
			int lengthRead=0;
			int totalRead=0;
			do {
			lengthRead=bReader.read(bufferChar, 0, bufferChar.length);
			if (lengthRead == bufferChar.length) {
				String line =    new String(bufferChar);
				System.out.println("\n"+ line);
				totalRead += bufferChar.length;
				
			} else if (lengthRead > 0 && lengthRead < bufferChar.length) {
				String line = new String(bufferChar, 0, lengthRead);
				totalRead +=lengthRead;
				System.out.println("\n"+line);
			} else {
				System.out.println("\nnone of these"+ lengthRead);
				break;
			}
			
			
			} while (true);
			
			System.out.println("\nClosing"+totalRead);
			bReader.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch ( IOException ioe) {
		   System.err.println("ioe");	
		}
    	
    	
    }

	
	class MyTableModel extends AbstractTableModel {
	    private String[] columnNames = {"File Name", "Uploaded", "Diff"};
	    
	
	    public int getColumnCount() {
	        return 3;
	    }

	    public int getRowCount() {
	        return fileList.size();
	    }

	    public String getColumnName(int col) {
	        return columnNames[col];
	    }

	    public Object getValueAt(int row, int col) {
	    	FileObject fObj = (FileObject)fileList.get(row);
	        if (col==0) {
	        	return fObj.fileName;
	        } else if (col==1) {
	        	return fObj.bUploaded();
	        }
	        return null;
	    }

	   
	    /*
	     * Don't need to implement this method unless your table's
	     * editable.
	     */
	    public boolean isCellEditable(int row, int col) {
	        //Note that the data/cell address is constant,
	        //no matter where the cell appears onscreen.
	        return (false);
	        
	    }
       
	    /*
	     * Don't need to implement this method unless your table's
	     * data can change.
	     */
	    public void setValueAt(Object value, int row, int col) {
	       
	        fireTableCellUpdated(row, col);
	    }
	    
	    
	}
	
	public class FileObject {
		private String fileName =null;
		private File file = null;
		private Boolean bUploaded=false;
		private Boolean bDiff=false;
		public FileObject (File _file) {
		  fileName=_file.getName();
		  file = _file;
		}
		public String  bUploaded() {
			Boolean bValue=Boolean.valueOf(bUploaded);
			return bValue.toString();
		}
		public String bDiff() {
			if (!bUploaded) {
				return "";
			} else if (bDiff) {
				return "true";						
			} else {
				return "false";
			}
		}
	}

	
	
}
