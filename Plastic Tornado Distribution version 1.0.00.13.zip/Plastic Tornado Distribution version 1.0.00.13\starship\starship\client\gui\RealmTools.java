package starship.client.gui;

import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;



public class RealmTools extends JDialog {
	private int width=0, height=0;
	public enum STATE {INACTIVE, ACTIVE};
    public STATE stateCode =STATE.INACTIVE;
    
	public RealmTools(int _w, int _h) {
		super();
		
		
		width=_w; height=_h;
		JPanel panel =(JPanel) super.getContentPane();

		panel.add(new JButton("New"));
		super.addWindowListener(new WindowAdapter()
		  {
		      @Override
		      public void windowClosing(WindowEvent e)
		      {
		        		    	  
		        RealmTools rt = (RealmTools)e.getWindow();
		        rt.setState(STATE.INACTIVE);
		      }
		  });
		setSize(_w, _h);	
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	}
	void setState(STATE _st) {
		if (_st== STATE.INACTIVE) {
			setVisible(false);
		} else if (_st == STATE.ACTIVE) {
			setVisible(true);
		}
	}
}
