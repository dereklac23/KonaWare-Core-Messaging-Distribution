package releasetool;
import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;

class DirectoryObject {
		public int version[] = new int[5];
		public String prefix=null;
		public File root=null, docRelease=null;
		  public HashMap <String, DirectoryObject> doMap = 
					new HashMap<String, DirectoryObject>();
		  public Map<String, DirectoryObject> eMap =  Collections.synchronizedMap(doMap);
		  public File fileDirectoryTarget=null;
		public DirectoryObject () {
			
		}
		public DirectoryObject(File _targetF) {
			fileDirectoryTarget=_targetF;
		}
		public DirectoryObject(String key, File tomcatDir) {
			eMap.put(key,  new DirectoryObject(tomcatDir));
		}
		public boolean isKCM() {
			return (prefix !=null) && (!prefix.endsWith(".zip"));
			
		}
		public DirectoryObject (String _prefix,Matcher matcher)  throws KCMException {
			if (matcher ==null) {
				throw new KCMException("\nRegex did not get any matches");
			}
			
			prefix = matcher.group(0);
			for (int i=1; i < version.length; i++) {
				version[i] = Integer.parseInt(matcher.group(i));				
			}
			prefix = _prefix;
		}
		public DirectoryObject (File _root,String _prefix,Matcher matcher)  throws KCMException {
			System.out.println("\nprefix"+_prefix);
			if (matcher ==null) {
				throw new KCMException("\nRegex did not get any matches for");
			}
			
			prefix = matcher.group(0);
			for (int i=1; i < version.length; i++) {
				System.out.println("\nGetting version from matcher");
				version[i] = Integer.parseInt(matcher.group(i));				
			}
			prefix = _prefix;
			root =_root;
			File  docDirectory= new File(root, "doc");
			docRelease = new File(docDirectory, "release");
		}

		
		public boolean compare(int target[]) {

			return compare(target,1);
			
		}
		public boolean compare(int target[], int index) {

		
			      if (index == (target.length-1) && target[index] >= version[index]) {
			    	  return true;
			      } else if (index == (target.length-1)) {
			    	  return false;
			      }
			      
			      
			      else if (target[index]	>= version[index]) {
					  return compare(target, index+1);
				  } 
				  
				
				return false;
		}
		
		public String getVersionString() {
			StringBuffer sb = new StringBuffer();
			for (int i=1; i < version.length; i++) {
			sb.append(version[i]);
		}
			return sb.toString();
	}
}