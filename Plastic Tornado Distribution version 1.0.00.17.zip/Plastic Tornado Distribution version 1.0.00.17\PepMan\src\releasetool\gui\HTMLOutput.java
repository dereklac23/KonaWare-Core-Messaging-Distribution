package releasetool.gui;

import javax.swing.JEditorPane;

public class HTMLOutput extends JEditorPane {
  private String HEADER="<html>", ENDER="</HTML>";
  private enum TAG {NULL,P, UL, UI, TABLE};
  private HElement pElement=null;
  private StringBuffer pBuffer=new StringBuffer();
		  
  public HTMLOutput() {
	  super();
	  setContentType("text/html");
	  pElement = new HElement(TAG.P);
	  
	  
  }
  public void printPage() {
	  super.setText(pBuffer.toString());
  }
  public void attachP(String _bodyText) {
	  pBuffer.append("<p>");
	  pBuffer.append(_bodyText);
	  pBuffer.append("</p>");
	  
  }
  public void attachHeader() {
	  pBuffer.setLength(0);
	  pBuffer.append(HEADER);
  }
  public void attachEnder() {
	  pBuffer.append(ENDER);
	  
  }
  public class HElement {
	  private TAG tag = TAG.NULL;
	  public HElement(TAG _t) {
		  tag = _t;
	  }
	  
  }
  
}
