package releasetool;
import releasetool.gui.*;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;





public class PepMan implements ChangeListener {
	

	private static PepMan releaseTool =null;
	private  enum PANEL_TYPE {  SETTINGS,DISTRIBUTION, CUBE_CONTROL, PVM, HELP};
	private String targetDirString="d:\\dev";
	PathUtil pathUtil=null;
    PathUtil pathHtml =null;
	private HTMLOutput htmlOutput=null;
	
	
	JComboBox<ButtonSelection> jCombo[];
	JComboBox comboPointer=null;
	private PanelStruct panelArray [] = new PanelStruct[PANEL_TYPE.values().length];

	ButtonSelection selectPointer= null;
	JPanel framePanel=null;
	private JFrame globalFrame=null;
	public  PepMan() {
		
		    globalFrame= new JFrame("PepMan");
		    framePanel = (JPanel) globalFrame.getContentPane();
	        globalFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        globalFrame.setSize(1000, 500);
	        // Add a label to the frame
	        JLabel label = new JLabel("Release Tool!", JLabel.CENTER);
	        framePanel.setLayout(new BorderLayout());
	        
	        
	        jCombo = new JComboBox[PANEL_TYPE.values().length];
	        jCombo[PANEL_TYPE.SETTINGS.ordinal()] = new JComboBox ();
	        jCombo[PANEL_TYPE.SETTINGS.ordinal()].setRenderer(new ComboRenderer(this));
	        jCombo[PANEL_TYPE.DISTRIBUTION.ordinal()] = new JComboBox ();
	        jCombo[PANEL_TYPE.DISTRIBUTION.ordinal()].setRenderer(new ComboRenderer(this));
	        
	        
	        jCombo[PANEL_TYPE.SETTINGS.ordinal()].addItem(new ButtonSelection(ButtonSelection.BSTypeSettings.GTML,"GTML resource folder")); 
	        jCombo[PANEL_TYPE.SETTINGS.ordinal()].addItem(new ButtonSelection(ButtonSelection.BSTypeSettings.STAGGING,"Temporary folder for staging file for assembly"));
	        
	        
	        jCombo[PANEL_TYPE.DISTRIBUTION.ordinal()].addItem(new ButtonSelection(ButtonSelection.BSTypeDistribution.COPY_KCM,"Copy files from Stagging to Plastic Tornado Distribution.")); 
	        jCombo[PANEL_TYPE.DISTRIBUTION.ordinal()].addItem(new ButtonSelection(ButtonSelection.BSTypeDistribution.COPY_TOMCAT,
	        		"Copy files from Stagging to Tomcat webapps.\nThe name of the War file will be the context name."));	        
	        jCombo[PANEL_TYPE.DISTRIBUTION.ordinal()].addItem(new ButtonSelection(ButtonSelection.BSTypeDistribution.LOAD_GTML,"Load private files from GTML resource folder.")); 
	        
	        framePanel.add(BorderLayout.NORTH, getNorthPanel());
	        framePanel.add(BorderLayout.CENTER, getCenterPanel());
	        
	        //globalFrame.pack();
	        globalFrame.setLocationRelativeTo(null);
	        globalFrame.setVisible(true);	    
	        
	        performProvision();	        

	}
	
	private void performProvision() {
		File fileTarget = new File(targetDirString);		
		pathUtil = new PathUtil(fileTarget, menuHtml);
		pathHtml = new PathUtil( menuHtml, jCombo[PANEL_TYPE.DISTRIBUTION.ordinal()]);
		
		
		
		}

	
	public static void main(String args[] ) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
		
	}
	private static void createAndShowGUI() {
        // Create the frame
		releaseTool = new PepMan();      
    }
	
    private JPanel controlPanel =null;
    private JButton btnGo =null;
	private JPanel getNorthPanel() {
  		controlPanel= new JPanel();   
		   
		   btnGo=new JButton("Go");
	       btnGo.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	try {
	            	if (selectPointer==null) {
	            		 
	            	} else if (selectPointer.typeDistribution == ButtonSelection.BSTypeDistribution.COPY_KCM) {
	            		performCopy();
	            	} else if (selectPointer.typeDistribution == ButtonSelection.BSTypeDistribution.COPY_TOMCAT) {
	            		performCopyWar2Tomcat();
	            	} else if (selectPointer.typeDistribution == ButtonSelection.BSTypeDistribution.LOAD_GTML) {
	            		performLoadGtml();
	            		
	            		
	            	}
	            	
	            	} catch  (KCMException kcp) {
	            		
	            	} catch (IOException ioe) {
	            		System.out.println("\nIOE"+ ioe.toString());
	            	}
	            	
	            }
	        });

		controlPanel.add(comboPointer=jCombo[PANEL_TYPE.SETTINGS.ordinal()]);
		controlPanel.add(btnGo);
		
		return controlPanel;
	}
	
	
	
	
	private MenuHtml menuHtml = null;

	private MenuSettings menuSettings=null;
	private JTabbedPane tabbedPane=null;
	private JPanel getCenterPanel()  {
		JPanel panel = new JPanel();
		tabbedPane = new JTabbedPane();	
		
		
		ComboRenderer comboRSettings = new ComboRenderer(this);		
		panelArray[PANEL_TYPE.SETTINGS.ordinal()] = new PanelStruct(comboRSettings,"Settings", 
				"Basement layer 1 for settings.\nExamples would be staging directories for files assembly.", KeyEvent.VK_1);
		tabbedPane.addTab(panelArray[PANEL_TYPE.SETTINGS.ordinal()].title,panelArray[PANEL_TYPE.SETTINGS.ordinal()].comp);		
		JPanel panelLayer1 =(JPanel)panelArray[PANEL_TYPE.SETTINGS.ordinal()].comp;
		panelLayer1.removeAll();
		menuSettings = new MenuSettings();
		panelLayer1.add(BorderLayout.NORTH, menuSettings);
		
		
		
		
		ComboRenderer comboDistribution = new ComboRenderer(this);
	    panelArray[PANEL_TYPE.DISTRIBUTION.ordinal()] = new PanelStruct(comboDistribution,"Distribution", 
	    		"Basement layer  0 for local file  and working directory.", KeyEvent.VK_0);
		tabbedPane.addTab(panelArray[PANEL_TYPE.DISTRIBUTION.ordinal()].title,panelArray[PANEL_TYPE.DISTRIBUTION.ordinal()].comp);		
		JPanel panelLayer0 =(JPanel)panelArray[PANEL_TYPE.DISTRIBUTION.ordinal()].comp;
		panelLayer0.removeAll();
		menuHtml= new MenuHtml();		       
		panelLayer0.add(BorderLayout.NORTH, menuHtml); 		
		
		panel.add(tabbedPane);
		tabbedPane.addChangeListener(this);
		return panel;
	}
	private void performCopy() throws IOException {		
		pathUtil.performCopy();
	}
	
  
	private void performCopyWar2Tomcat () throws KCMException {
		File fileTarget = new File(targetDirString);
		pathUtil = new PathUtil(fileTarget, menuHtml);		
		pathUtil.performCopyWar2Tomcat();
		
	}
	private void performLoadGtml() {
		pathHtml.loadHtmlPage();
	}
	
	private class MyModel extends DefaultComboBoxModel {
		
	}
	public class MyActionListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
	@Override
	public void stateChanged(ChangeEvent e) {
		
		int index = tabbedPane.getSelectedIndex();
		comboPointer=jCombo[index];
		controlPanel.removeAll();
		controlPanel.add(btnGo);
		controlPanel.add(comboPointer);
		controlPanel.repaint();
		globalFrame.validate();
		
		
		// TODO Auto-generated method stub
		
	}
}


