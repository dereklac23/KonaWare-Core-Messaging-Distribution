package releasetool;

import java.awt.Component;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class ComboRenderer extends JLabel
                           implements ListCellRenderer {
        
        private PepMan releaseTool=null;
        public ComboRenderer(PepMan rT) {
            setOpaque(true);
            setHorizontalAlignment(CENTER);
            setVerticalAlignment(CENTER);
            releaseTool = rT;
        }
 
        /*
         * This method finds the image and text corresponding
         * to the selected value and returns the label, set up
         * to display the text and image.
         */
        public Component getListCellRendererComponent(
                                           JList list,
                                           Object value,
                                           int index,
                                           boolean isSelected,
                                           boolean cellHasFocus) {
         
        	
        	ButtonSelection bSelect = (ButtonSelection)value;
        	releaseTool.selectPointer=bSelect;
 
            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            } else {
                setBackground(list.getBackground());
                setForeground(list.getForeground());
            }
 
            setText(bSelect.getLabel());
 
            return this;
        }
 
     

		
    }