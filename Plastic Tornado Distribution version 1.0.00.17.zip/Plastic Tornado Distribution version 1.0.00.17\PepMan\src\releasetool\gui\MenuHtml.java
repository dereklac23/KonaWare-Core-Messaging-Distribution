package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.IOException;

import javax.swing.event.*;


import javax.swing.JPanel;
import javax.swing.JTextArea;

public class MenuHtml extends JPanel {
    public HTMLOutput editorHtml=null;	
    private String htmlIndexPage=null;
	public MenuHtml() {
		super();
		add(BorderLayout.NORTH, editorHtml=new HTMLOutput());
		
		editorHtml.setContentType("text/html");
		
		editorHtml.addHyperlinkListener(new HCustomListener());
		editorHtml.setPreferredSize(new Dimension(400,200));
		editorHtml.attachHeader();
		
		editorHtml.attachP("Welcome to the Distribution page!");
		editorHtml.attachP("This is a manual page to download the proper Java, Tomcat distrubution to be extracted and provisioned.");
		
		editorHtml.attachEnder();
		editorHtml.printPage();	
		
		
		
	}
	
	
	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			System.out.println("Event entered");
			// TODO Auto-generated method stub
			
		}
	
	}


}
