package konaware.server.util;

public class LocalServerContainer {
    public DimensionServerStateOperation dso=null;
	public LocalServerContainer() {
		
	}
}
