package starship.client.gui;


import starship.*;
import starship.util.*;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

import starship.atom.LocalContainer;


public class MessageProperties  extends JPanel {
	private JTable tableList  = new JTable(new MyTableModel());
	private LocalContainer globalContainer=null;
 
    public MessageProperties(LocalContainer gc) {
       globalContainer = gc;
		
		JScrollPane scrollPane = new JScrollPane(tableList);
		add(scrollPane);
		tableList.setPreferredScrollableViewportSize(new Dimension(KWLauncherFrame.WIDTH-30, KWLauncherFrame.HEIGHT/3));
		
    }

	
	class MyTableModel extends AbstractTableModel {
	    private String[] columnNames = {"Name", "Value"};
	    private String[][] data = {
	    		{"File name", ""},
	    		{"X Pos", "0"},
	    		{"Y Pos", "0"}
	    };

	    public int getColumnCount() {
	        return 2;
	    }

	    public int getRowCount() {
	        return data.length;
	    }

	    public String getColumnName(int col) {
	        return columnNames[col];
	    }

	    public Object getValueAt(int row, int col) {
	        return data[row][col];
	    }

	   
	    /*
	     * Don't need to implement this method unless your table's
	     * editable.
	     */
	    public boolean isCellEditable(int row, int col) {
	        //Note that the data/cell address is constant,
	        //no matter where the cell appears onscreen.
	        return (col ==1);
	        
	    }

	    /*
	     * Don't need to implement this method unless your table's
	     * data can change.
	     */
	    public void setValueAt(Object value, int row, int col) {
	        data[row][col] = (String)value;
	        fireTableCellUpdated(row, col);
	    }
	    
	}

	
	
}
