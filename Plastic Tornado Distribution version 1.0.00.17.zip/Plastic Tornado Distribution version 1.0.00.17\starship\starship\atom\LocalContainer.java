package starship.atom;
import starship.util.*;


import javax.swing.JTextArea;
import javax.swing.JTextField;


public class LocalContainer {
 

  
  public KWMessageWrapper messageWrapper=null;
  
  public enum LEVEL_TYPE {LEVEL0, LEVEL1, LEVEL2, LEVEL3}
  public LEVEL_TYPE levelNumber= LEVEL_TYPE.LEVEL0;  
  //System output
  public JTextArea taTextArea=null;
  
  //Layer 1 data set
  public JTextField tfHostName, tfContextName, tfServletName;
  public DimensionStateOperation dso=null;
  public SOClientProvision soClientProvision=null;
  
  //Layer 2
  public KWMessageWrapper kwMessageWrapper=null;
  public SOClientCommunicate2 soClientCommunicate=null;
  public SOClientInstallGui  soClientInstallGui=null;
  
  //Layer 3
  
  public RealmRenderFunction realmRenderFunction ;
  public int realmBorderWidth=0, realmBorderHeight=0;
  
  
  
  public LocalContainer globalContainerPointer =null, localContainer=null;
  public LocalContainer() {
	  
  }
  public LocalContainer (int _w, int _h) {
  	    realmBorderWidth = _w;
	    realmBorderHeight=_h;
	  
  }
  public LocalContainer(JTextField _tfHostname, JTextField _tfServletName, JTextField _tfContextName) {
	  tfHostName = _tfHostname;
	  tfServletName = _tfServletName;
	  tfContextName = _tfContextName;
	  
  }
  
  public LocalContainer(LocalContainer _globalC, LEVEL_TYPE _lt)  {
	  levelNumber=_lt;
	  if (_lt == LEVEL_TYPE.LEVEL0) {
		  localContainer = _globalC;
		  realmRenderFunction = new RealmRenderFunction();
	  }
	  globalContainerPointer=_globalC;	  
	  
	  
  }
  public RealmRenderFunction getRRF() {
	  if (levelNumber == LEVEL_TYPE.LEVEL0) {
		  return realmRenderFunction;
	  } else if (globalContainerPointer !=null) {
		  return globalContainerPointer.getRRF();
	  }
	  return null;
	  
  }


  public void setDSO(DimensionStateOperation _dso ) {
	  getGlobalContainer().dso=_dso;
  }
  public DimensionStateOperation getDSO() {
	  
	  if (levelNumber == LEVEL_TYPE.LEVEL0) {
		  return localContainer.dso;
	  } else 
		  return globalContainerPointer.getDSO();
	  
  }
  public LocalContainer getGlobalContainer() {
	  if (levelNumber == LEVEL_TYPE.LEVEL0) 
		  return localContainer;
	  else return globalContainerPointer.getGlobalContainer();
	  
  }

   
  
}
