package releasetool;

public class ButtonSelection {
    public String label=null;
    public enum BSTypeDistribution  {PROVISION, COPY_KCM, COPY_TOMCAT,LOAD_GTML,NULL};
    
    public BSTypeDistribution typeDistribution=BSTypeDistribution.NULL;
    
    public enum BSTypeSettings {STAGGING, GTML, NULL};
    public BSTypeSettings typeDirectory = BSTypeSettings.NULL;
    
    
    
    public ButtonSelection(BSTypeSettings _bType,String _text) {
  	  label = _text;
  	  typeDirectory = _bType;
  	}
    
    public ButtonSelection(BSTypeDistribution _bType,String _text) {
  	  label = _text;
  	  typeDistribution = _bType;
  	}
    public String getLabel() {
    	return label;
    }
	
}
