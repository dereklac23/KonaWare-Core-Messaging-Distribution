
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk



This distribution KMP Message proof version 1 contains the:
KonaWare Gateway service in the 

KMP directory with all the source code to the KMP Gateway Servlet

The KonaWare Client Launcher in the 

KonaWare directory with all the source code to the KMP Gateway Servlet

the KMP.war file contains the compiled source to be deployed on Tomcat.

To run KonaWare launcher double-click on the runnable jar (KonaWar.jar) or type "java -jar KonaWare.jar"






In order to test of the KMP Gateway is working, deploy the KMP.war file use the following URL:
http://localhost:8080/KMP/KMP

Should see the following text:

string
KWGateway 0.1
int
4269

Next ping the KonaWare Gateway on the KonaWare Launcher Java Application:

KonaWare Launcher, go to the "Development" tab. Make sure the URL is the same as the KMP Gateway:
http://localhost:8080/KMP/KMP

You see the following responses:
KWGateway 0.1
4269
Response code verified match!
 