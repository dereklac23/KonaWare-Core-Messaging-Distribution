package konaware.util;

import java.io.*;

import java.util.Hashtable;

/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

public class FileFilterSh implements FilenameFilter {

	  private Hashtable filters = new Hashtable();

	  private String description = "unverified";

	  private String fullDescription = null;
	
	  
  public FileFilterSh() {
	       //super();
//	       directoryPointerRoot=_directory;
	       filters.put("sh", this);
	       filters.put("jar", this);
	       filters.put("xml", this);
	       filters.put("gz", this);
	       filters.put("bat", this);
	 }
  
  @Override
	public boolean accept(File dir, String name) {
	  System.out.print("Checking file:"+name);		
		 if (dir != null) {
			   
		      String extension = getExtension(name);
		      if (filters.get(extension)!=null) {
		        return true;
		      }
		    
		    	
	
	}
		 return false;
  }
	
	
	public String getExtension(String name) {
		
		System.out.print("\nChecking file:"+name);
		
	      int i = name.lastIndexOf('.');
	      if (i > 0 && i < name.length() - 1) {
	        return name.substring(i + 1).toLowerCase();
	      }
	    
	    return null;
	  }

	
}

