package konaware.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

 
public class KWMap {
    public String token=null;
    public String payload=null;
    int     payloadInt=0;
    long    payloadLong =0;
    double  payloadDouble =0.0;
    float   payloadFloat = 0.0f;
    boolean payloadBoolean =false;
    char    payloadChar ='0';
    short   payloadShort=0;
    byte    payloadByte=0;
    static public String HEADER_TEXT ="KWGateway 0.1";
    static public int HEADER_INT = 4269;
    public KWTYPE type =KWTYPE.NULL;
    public int ordinal=0;
	public enum KWTYPE  {
			STRING , INT, LONG, DOUBLE,
			FLOAT, BOOLEAN, CHAR, SHORT, BYTE, NULL;
	}
	public static KWMap kwTokenMap[] = new KWMap[KWTYPE.values().length];
    public KWMap() {
    	
    }
    public KWMap(String _tok) {
    	if (_tok.equals("string")) {
    		token=_tok;
    		ordinal = KWTYPE.STRING.ordinal();    		
  		    kwTokenMap[ordinal] = new KWMap();
  		    kwTokenMap[ordinal].type=KWTYPE.STRING;
    	} else if (_tok.equals("int")) {
    		token=_tok;
    		ordinal = KWTYPE.INT.ordinal();
    		kwTokenMap[ordinal] = new KWMap();
  		    kwTokenMap[ordinal].type=KWTYPE.INT;
    	} else if (_tok.equals("long")) {
    		token=_tok;
    		ordinal = KWTYPE.INT.ordinal();
    		kwTokenMap[ordinal] = new KWMap();
  		    kwTokenMap[ordinal].type=KWTYPE.LONG;    		
    	} else if (_tok.equals("double")) {
    		token=_tok;
    		ordinal = KWTYPE.DOUBLE.ordinal();
    		kwTokenMap[ordinal] = new KWMap();
  		    kwTokenMap[ordinal].type=KWTYPE.DOUBLE;    		
    	} else if (_tok.equals("float")) {
    		token=_tok;
    		ordinal = KWTYPE.FLOAT.ordinal();
    		kwTokenMap[ordinal] = new KWMap();
  		    kwTokenMap[ordinal].type=KWTYPE.FLOAT;
    	}else if (_tok.equals("boolean")) {
    		token=_tok;
    		ordinal = KWTYPE.BOOLEAN.ordinal();
    		kwTokenMap[ordinal] = new KWMap();
  		    kwTokenMap[ordinal].type=KWTYPE.BOOLEAN;
    	}else if (_tok.equals("char")) {
    		token=_tok;
    		ordinal = KWTYPE.CHAR.ordinal();
    		kwTokenMap[ordinal] = new KWMap();
  		    kwTokenMap[ordinal].type=KWTYPE.CHAR;
    	} else if (_tok.equals("short")) {
    		token=_tok;
    		ordinal = KWTYPE.SHORT.ordinal();
    		kwTokenMap[ordinal] = new KWMap();
  		    kwTokenMap[ordinal].type=KWTYPE.SHORT;
    	}else if (_tok.equals("byte")) {
    		token=_tok;
    		ordinal = KWTYPE.BYTE.ordinal();
    		kwTokenMap[ordinal] = new KWMap();
  		    kwTokenMap[ordinal].type=KWTYPE.BYTE;
    	}
    
    }
    
    public KWTYPE getType() {
    	return kwTokenMap[ordinal].type;
    }
	public KWMap(KWTYPE _type) {
		
	  switch (_type) {
	  
	  case KWTYPE.STRING:
		  ordinal = KWTYPE.STRING.ordinal();
		  type = KWTYPE.STRING;
		  kwTokenMap[ordinal] = new KWMap();
		  kwTokenMap[ordinal].token = "string";
	  break;
	  
	  case KWTYPE.INT:
		  type = KWTYPE.INT;
		  ordinal = KWTYPE.INT.ordinal();
		  kwTokenMap[ordinal] = new KWMap();
		  kwTokenMap[ordinal].token = "int";
		  break;
	  
	  case KWTYPE.LONG:
		  type = KWTYPE.LONG;
		  ordinal = KWTYPE.LONG.ordinal();
		  kwTokenMap[ordinal] = new KWMap();
		  kwTokenMap[ordinal].token = "long";
		  break;
	  
	  case KWTYPE.DOUBLE:
		  type = KWTYPE.DOUBLE;
		  ordinal = KWTYPE.DOUBLE.ordinal();
		  kwTokenMap[ordinal] = new KWMap();
		  kwTokenMap[ordinal].token = "double";
		  break;
	
	  case KWTYPE.FLOAT:
		  type = KWTYPE.FLOAT;
		  ordinal = KWTYPE.FLOAT.ordinal();
		  kwTokenMap[ordinal] = new KWMap();
		  kwTokenMap[ordinal].token = "float";
		  break;
		  
	  case KWTYPE.BOOLEAN:
		  type = KWTYPE.BOOLEAN;
		  ordinal = KWTYPE.BOOLEAN.ordinal();
		  kwTokenMap[ordinal] = new KWMap();
		  kwTokenMap[ordinal].token = "boolean";
		  break;

	  case KWTYPE.CHAR:
		  type = KWTYPE.CHAR;
		  ordinal = KWTYPE.CHAR.ordinal();
		  kwTokenMap[ordinal] = new KWMap();
		  kwTokenMap[ordinal].token = "char";
		  break;

	  case KWTYPE.SHORT:
		  type = KWTYPE.SHORT;
		  ordinal = KWTYPE.SHORT.ordinal();
		  kwTokenMap[ordinal] = new KWMap();
		  kwTokenMap[ordinal].token = "short";
		  break;

	  case KWTYPE.BYTE:
		  type = KWTYPE.BYTE;
		  ordinal = KWTYPE.BYTE.ordinal();
		  kwTokenMap[ordinal] = new KWMap();
		  kwTokenMap[ordinal].token = "byte";
		  break;

	  }
	 
	}
	
	public String getString() {
		if (type  != KWTYPE.STRING) {
			return null;
		} else {
			return kwTokenMap[ordinal].payload;
		}
	}
	
	public int getInt() {
		if (type  != KWTYPE.INT) {
			return 0;
		} else {
			return Integer.parseInt(kwTokenMap[ordinal].payload);
		}
	}
	public long getLong() {
		if (type  != KWTYPE.LONG) {
			return 0;
		} else {
			return Long.parseLong(kwTokenMap[ordinal].payload);
		}
	}
	
	public double getDouble() {
		if (type  != KWTYPE.DOUBLE) {
			return 0;
		} else {
			return Double.parseDouble(kwTokenMap[ordinal].payload);
		}
	}
	
	public float getFloat() {
		if (type  != KWTYPE.FLOAT) {
			return 0;
		} else {
			return Float.parseFloat(kwTokenMap[ordinal].payload);
		}
	}
	public boolean getBoolean() {
		if (type  != KWTYPE.BOOLEAN) {
			return false;
		} else if (kwTokenMap[ordinal].payload.equals("true")) {
			return true;
			
		} else {
		 return false;
		}
	}
	
	public char getChar() {
		if (type  != KWTYPE.CHAR) {
			return 0;
		} else {
			return kwTokenMap[ordinal].payload.charAt(0);
		}
	}
	
	public int getByte() {
		if (type  != KWTYPE.BYTE) {
			return 0;
		} else {
			return Byte.parseByte(kwTokenMap[ordinal].payload);
		}
	}
	
	
	public void printString(PrintWriter pw) {
		KWMap kwm = kwTokenMap[ordinal];
		
		if (kwm.token !=null && kwm.payload !=null) {
			pw.println(kwm.token);
			pw.println(kwm.payload);
		}
	}
	

	public String describeString() {
		KWMap kwm = kwTokenMap[ordinal];
		StringBuffer sb= new StringBuffer();
		if (kwm.token!=null) {
			sb.append(kwm.token);
			sb.append(":");
		} 
		if (kwm.payload !=null) {
			sb.append(kwm.payload);
		}
		return sb.toString();
	}
 public KWMap getInstance (String _payload) {
	KWMap mInstance = kwTokenMap[ordinal];	
	mInstance.ordinal=ordinal;
	mInstance.payload=_payload;	
	return mInstance;		
	}
 
  static  public KWMap getInstance(BufferedReader br) throws IOException {
	   String token= br.readLine();
	   if (token==null) {
		   return null;
	   }
	   KWMap map= new KWMap(token);
	   map.kwTokenMap[map.ordinal] =map;
	   
	   
	   return map.getInstance(br.readLine());
	   
   }
   public void write(PrintWriter pw) {
	       pw.println(kwTokenMap[ordinal].token);
	   	   pw.println(kwTokenMap[ordinal].payload);
   }
   public void read(BufferedReader br) {
	   try {
		String token= br.readLine();
		KWMap map = new KWMap(token);
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
   }
 
	
}
