package konaware.client.gui;

import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/


public class RealmBrowser extends JPanel {
    private int width=0, height=0;
    
    private JPanel panelTopGui=null;
    private JTextField jtfUser=null, jtfPassword=null;
    private CenterCanvas cCanvas=null;
	public RealmBrowser(int _w, int _h) {
		super();
      //add(BorderLayout.NORTH,panelTopGui = new PanelTopGui());
	  //add(BorderLayout.CENTER, cCanvas=new CenterCanvas(_w, _h));
	  //cCanvas.setSize(_w, _h);
	  //super.setSize(_w, _h);
	   width=_w; height=_h;
	}
	@Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Custom drawing code goes here
        g.setColor(Color.PINK);
        g.fillRect(0, 0, width, height); // Draw a blue rectangle
    }
	  
	 	 
	 
	 public class PanelTopGui extends JPanel {
		public PanelTopGui() {			
			//setLayout(new FlowLayout());
			add(new JLabel("User name:"));
			add(jtfUser=new JTextField (10));
			add(new JLabel("Password:"));
			add(jtfPassword = new JTextField(10));
			
		}
	 }
	 public class CenterCanvas extends JPanel {
		 
		    public CenterCanvas(int _w, int _h) {
			 setSize(_w, _h);
			 System.out.println("width:"+width+":"+height);
			 
		 }
		    @Override
		    protected void paintComponent(Graphics g) {
		        super.paintComponent(g);
		        // Custom drawing code goes here
		        g.setColor(Color.RED);
		        g.fillRect(0, 0, width, height); // Draw a blue rectangle
		    }
		 
		 

		 
	 }
}
