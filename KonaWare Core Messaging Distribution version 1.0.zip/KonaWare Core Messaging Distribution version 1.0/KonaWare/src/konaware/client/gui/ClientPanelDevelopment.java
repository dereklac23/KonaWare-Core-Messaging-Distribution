package konaware.client.gui;
import java.awt.GridBagConstraints;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import konaware.util.KWMap;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

public class ClientPanelDevelopment extends JPanel {

	public ClientPanelDevelopment() {
		    
		
	}
	private String strUrl = "http://localhost:8080/KMP/KMP";
	private JTextField jtfUrl=null;
	private JPanel getUrlPanel() {
		JPanel jPanel  = new JPanel();
		jtfUrl= new JTextField(35);
		jPanel.setLayout(new FlowLayout());
		jPanel.add(jtfUrl);
		jtfUrl.setText(strUrl);
		jPanel.add(jBTNPost = new JButton("Ping"));
		return jPanel;
	}
	private JButton jBTNPost = null;
	private JTextArea jtaOutput=null;
	public JPanel getPanelURL() {
			
			JPanel jPanel = new JPanel();
			
			jPanel.add(getUrlPanel(),BorderLayout.SOUTH );
			jPanel.add(jtaOutput = new JTextArea(20,50), BorderLayout.CENTER);
			GridBagConstraints c = new GridBagConstraints();
			
			
			jBTNPost.addActionListener(new ActionListener() {
		            public void actionPerformed(ActionEvent e) {
		            	doURIConnection();
		            }
			 }
			 );
			 
			return jPanel;
	}
	  private void doURIConnection() {
		  try {
		  
		  URI uri = new URI(jtfUrl.getText());
		  
		
		  URL url = uri.toURL();
		  HttpURLConnection con = (HttpURLConnection)url.openConnection(); 
		  con.setRequestMethod("GET");
		  HashMap <String, KWMap > hashP = new HashMap<String, KWMap>();
		  KWMap map=null;	  
		  
		  BufferedReader in = new BufferedReader(
				new InputStreamReader(con.getInputStream()));
		         do {
		         map = KWMap.getInstance(in);
		         
		         if (map !=null && map.token!=null) {
		         hashP.put(map.token, map);
		         
		         } else {
		        	 break;
		         }
		         } while (true);		        
		        	        
		        
				in.close();
				con.disconnect();
				StringBuffer sb = new StringBuffer();
				for (String key : hashP.keySet()) {
					KWMap map1 = (KWMap)hashP.get(key);
					sb.append(map1.payload);
					sb.append('\n');
				}
				 in.close();
				String targetString = sb.toString();	
				jtaOutput.append(sb.toString());
				if (targetString.equals(KWMap.HEADER_TEXT+"\n"+KWMap.HEADER_INT+"\n")) {
					jtaOutput.append("Response code verified match!");
				} else  {
					jtaOutput.append("Response code not matched!");
				}
             
				
	  } catch (Exception e) {
		  e.printStackTrace();
		  jtaOutput.append(e.toString());
	  }
	  
      }

}
