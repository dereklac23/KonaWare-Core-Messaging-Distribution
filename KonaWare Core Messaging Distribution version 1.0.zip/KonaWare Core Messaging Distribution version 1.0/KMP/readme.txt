

In order to test of the KMP Gateway is working, use the following URL:
http://localhost:8080/KMP/KMP

Should see the following text:

string
KWGateway 0.1
int
4269

Next run the Java Application:

KWLaundcher, go to the "Development" tab. Make sure the URL is the same as the KMP Gateway:
http://localhost:8080/KMP/KMP

You see the following responses:
KWGateway 0.1
4269
Response code verified match!
 