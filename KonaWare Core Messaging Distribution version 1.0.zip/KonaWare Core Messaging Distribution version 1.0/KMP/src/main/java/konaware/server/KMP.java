package konaware.server;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import konaware.util.KWMap;

import java.io.IOException;
import java.io.PrintWriter;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

/**
 * Servlet implementation class KMP
 */
@WebServlet("/KMP")
public class KMP extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public KMP() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		  ServletContext context = getServletContext();
		  //String returnStr = getStringFormInputStreamString(request);
		  
		  PrintWriter printWriter= response.getWriter();
		  //System.out.println(printWriter)
		  KWMap map1 = new KWMap(KWMap.KWTYPE.STRING);
		  
		  KWMap mapInstance = map1.getInstance(KWMap.HEADER_TEXT);
		  mapInstance.write(printWriter);
		  KWMap map2 = new KWMap(KWMap.KWTYPE.INT);	
		  
		  mapInstance = map2.getInstance(String.valueOf(KWMap.HEADER_INT));
		  context.log("The ordinal is ..."+mapInstance.ordinal);
		  context.log("The token is ..."+ mapInstance.kwTokenMap[mapInstance.ordinal].token);
		  mapInstance.write(printWriter);
		  context.log("!!Here is visitor's message v2");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
