package konaware.util;
import konaware.client.gui.*;
import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class KWLauncherFrame extends JFrame {
	MainPanelCreator puc=null;
	//ClientMenuDevelopment cms=null;
	public static int WIDTH=800, HEIGHT=550;
	public KWLauncherFrame () {
    super("KonaWare.Installer.Java");
	puc=new MainPanelCreator();
	
    super.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    super.setSize(WIDTH,HEIGHT);
    
   
    //frameMain.getContentPane().add(BorderLayout.NORTH,  panelUtilCreator.getTopPanel()); // Adds Button to content pane of frame
    JPanel pane =  (JPanel) getContentPane();
    pane.add(BorderLayout.CENTER, puc.getTabbedPane());
    //pane.add(BorderLayout.NORTH, cms= new ClientMenuDevelopment());
    super.setVisible(true);
    
    super.addWindowListener(new WindowAdapter()
		  {
		      public void windowClosing(WindowEvent e)
		      {
		        //stateState(STATE.INACTIVE); 
		    	  puc.setStateClose();
		        
		      }
		  });
	}
}
