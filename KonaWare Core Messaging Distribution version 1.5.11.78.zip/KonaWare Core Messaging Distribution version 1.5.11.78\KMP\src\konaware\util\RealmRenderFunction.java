package konaware.util;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import konaware.atom.AtomException;
import konaware.util.StateOperation.ClientExecutionFunction;
import konaware.util.StateOperation.ExecCallable;

import konaware.util.StateOperation.SERVICE_EXECUTION;


public class RealmRenderFunction  implements ExecCallable{
	ClientExecutionFunction fef = null;
	public static final String REALM_BORDER_X = "realm.provision.border.x", REALM_BORDER_Y ="realm.provision.border.y";
	public DimensionStateOperation  dso;
	public void setRealmDimension(KWMessageWrapper _kW)  throws AtomException {

 		
 		KWAtom atWidth =  new KWAtom(KWAtom.KWTYPE.INT); 
 		KWAtom atHeight = new KWAtom(KWAtom.KWTYPE.INT);
 		atWidth.setData(Integer.toString(600));
 		atHeight.setData(Integer.toString(700));
 		
 		//dso= new DimensionStateOperation(atWidth, atHeight);
 		if (atWidth ==null || atHeight ==null) {
 			throw new AtomException(REALM_BORDER_X +" or " + REALM_BORDER_Y +" attribute not found");
 		}
 			
 		
 		
		
 	}

	KWMessageWrapper kwMap=null;
	public RealmRenderFunction (ClientExecutionFunction _fileE) {
		fef=_fileE;
	}
    public RealmRenderFunction() {
    	
    }
	public void setDSO(DimensionStateOperation _dso) {
		dso = _dso; 
	}
	@Override
	public void doExecute() {
		// TODO Auto-generated method stub
		
	}
	
}