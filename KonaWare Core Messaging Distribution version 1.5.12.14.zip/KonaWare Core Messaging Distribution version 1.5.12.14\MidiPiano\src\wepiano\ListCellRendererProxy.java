package wepiano;

import java.awt.Component;

import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class ListCellRendererProxy implements ListCellRenderer {
  private final ListCellRenderer<String> delegate;

  public ListCellRendererProxy(ListCellRenderer<String> delegate) {
    this.delegate = delegate;
  }
  

@Override
public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
		boolean cellHasFocus) {
	// TODO Auto-generated method stub
	return null;
}
}