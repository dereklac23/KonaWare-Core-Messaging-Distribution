package wepiano;

import javax.swing.JFrame;

public class WePianoLauncher extends JFrame {

	public WePianoLauncher() {
		
		
	}
}
