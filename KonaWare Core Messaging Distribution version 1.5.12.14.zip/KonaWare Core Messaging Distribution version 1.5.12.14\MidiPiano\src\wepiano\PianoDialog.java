package wepiano;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JPanel;

public class PianoDialog extends JPanel {
	  public PianoDialog() {
		  add(new JButton("piano"));
		  super.setPreferredSize(new Dimension(100,200)); 
		  
		  
		  
		 
		
	}
	}