package konaware.util;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JPanel;

import konaware.client.gui.RealmBrowser;
import konaware.util.StateOperation.RenderCallable;
import konaware.util.StateOperation.ServiceType;

public class RealmRender implements RenderCallable {
    private GlobalContainer globalContainer =null;
    private JPanel panel=null;
    public static final String REALM_BORDER_X = "realm.provision.border.x", REALM_BORDER_Y ="realm.provision.border.y";
    private RealmBrowser.STATE stateCode= RealmBrowser.STATE.INACTIVE;
    private Color colorInactive = Color.PINK, colorActive = Color.LIGHT_GRAY, fontColor = Color.BLACK;
    private Dimension realmDimension =null;
    
    
	
	private RenderDimension renderDimension = null;
	@Override
	public void doRender(ServiceType _st) {
		// TODO Auto-generated method stub
		if (_st == ServiceType.PROVISION) {
		KWAtom atomWidth = globalContainer.getAtom(REALM_BORDER_X);
		KWAtom atomHeight = globalContainer.getAtom(REALM_BORDER_Y);
		renderDimension = new RenderDimension(atomWidth, atomHeight);
		}
	}
	public Dimension getDimension() {
		return new Dimension ((int)(renderDimension.width), (int)(renderDimension.height));
	}
	public RealmRender(JPanel _jp) {
		panel = _jp;
	}
	public RealmRender(GlobalContainer _gc) {
		globalContainer = _gc;
	}
	
	public void paintComponent(Graphics g) {
	        
	        // Custom drawing code goes here
	        switch (stateCode) {
	        case INACTIVE: g.setColor(colorInactive); break;
	        case ACTIVE: g.setColor(colorActive);break;
			default:
				g.setColor(colorInactive);
				break;
	        }
	        
	        if (realmDimension!=null) {
	        g.fillRect(0, 0, realmDimension.width, realmDimension.height); // Draw a blue rectangle
	        g.setColor(fontColor);
	        
	        }
	        
	        g.fillRect(20, 20, realmDimension.width-40, realmDimension.height-40); // Draw a blue rectangle
	    } //paintComponent
	
	 protected class RenderDimension {
		 public int  width =0, height=0;
		 public RenderDimension(KWAtom _widthAtom, KWAtom _heightAtom) {
			 if (_widthAtom !=null) {
				 width= _widthAtom.getInt();
				 height= _heightAtom.getInt();
				 
			 }
		 }
	 }
}
