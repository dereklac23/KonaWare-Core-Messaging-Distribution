package konaware.util;

public class KWHashMap {
    private KWAtom key=null, data=null;
    
	public KWHashMap(String _key, KWAtom _data) {
		key = new KWAtom(KWAtom.KWTYPE.STRING);
		key.setData(_key);
	    data=_data;	
	}
	
	
	public KWAtom getKeyAtom() {
		return key;
	}
	public KWAtom getDataAtom() {
		return data;
	}
	
}
