package konaware.util;

import java.awt.Graphics;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JPanel;
import javax.swing.JTextArea;

/*
 * 
 * The FileStateManager is used to manage the creation of folders and the content at the sub-level for both the Server and
 * the Client.
 * 
 * 
 */
public class StateOperation {
   public enum FileStateType {
	   
	   CREATE,	   
	   DELETE,
	   CLEAN,
	   DISPLAY,
	   PROVISION,
	   HALT_SERVICE,
	   RESUME_SERVICE,	
	   
	   SEND,
	  
	   
   }
   public enum ServiceType {
	   PROVISION,
	   RENDER,
   }
   public enum FileLevelService {
	   KERNEL,
	   SYSTEM,
	   FILE,
	   CLOUD,
	   REALM
   }
   LinkedList <FileExecutionStatus> listStatus=null;
   JTextArea taOutput = new JTextArea ();
   public StateOperation(JTextArea _jTA) {
	   taOutput = _jTA;
	   listStatus = new LinkedList<FileExecutionStatus>();
	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.FILE,
			   FileStateType.CREATE, 
			   "Please select the working directory for local file storage.",
			   "The default will be the working directory of the KonaWare distribution upon the process startup.",
			   "Error: There is disk error in the local file storage or working directory."));
	   
	   
	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.SYSTEM,
			   FileStateType.PROVISION, 
			   "Creates a root directory if it does not already exist",
			   "The operation is aborted if the directory already exists. It needs to be manually removed.",
			   "Error: The directory exists. Needs to be manually removed."));
	   
	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.FILE,
			   FileStateType.CLEAN, 
			   "Removes all the content within the root.",
			   "Removes all the files recursively. The content cannot be recovered.\n",               
			   "Error occured during system delete."));
	   

	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.FILE,
			   FileStateType.DISPLAY,
			   "Display at the content within the target directory.",
			   "The target directory can go down to lower levels of the file system."+
			   "Certain content that can be  filtered are highlighted.",
			   "The file(s) is corrupted."));
               
	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.FILE,
			   FileStateType.PROVISION,
			   "Installs artifacts at the  index.xml file at the root directory.",
			   "The index.xml is installed."+
			   "If the index.xml exists, it is overwritten. Use File-DISPLAY option to check the\n"+
			     "and prompt the user for validation.",
			   "The system is not running until the file system is properly provisioned."));
	   
	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.CLOUD,
			   FileStateType.SEND,
			   "Send the basic KWHashMap map to the cloud service: KMP.",
			   "The KWMessage has been sent."+
			   "The KMP services receives and has processed the KWHashMap\n"+
			     "and prompt the user for validation.",
			   "Operation fail: Check if KMP is up and the url context is KMP{x}/KMP. For example KMP4/KMP."));
	   
	  
   }
   public void executeState(FileLevelService _fls, FileStateType _fst, File _file)  {
	   Iterator iter = listStatus.iterator();
	   FileExecutionStatus fes =null;
	   while (iter.hasNext())  {
		 fes = (FileExecutionStatus)iter.next();
		 if (fes.fls == _fls && fes.fst == _fst) {
			 fes.fec.doExecute(_file);
		 }
	   }
		   
	   
   }
   public void executeState(FileLevelService _fls, FileStateType _fst, GlobalContainer gc)  {
	   Iterator iter = listStatus.iterator();
	   FileExecutionStatus fes =null;
	   while (iter.hasNext())  {
		 fes = (FileExecutionStatus)iter.next();
		 if (fes.fls == _fls && fes.fst == _fst) {
			 fes.fec.doExecute(gc);
		 }
	   }
		   
	   
   }
	public interface FileExecCallable {
		public abstract void doExecute(File _file) ;
		public abstract void doExecute(GlobalContainer gc);
			
		
	}
	public interface RenderCallable {
		public abstract void doRender(ServiceType serviceType);
		
	}
	
	
	
	public class FileSetWorkingDirectory implements FileExecCallable {

		@Override
		public void doExecute(File _file) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void doExecute(GlobalContainer gc) {
			// TODO Auto-generated method stub
			
		}
		
	}
	public class FileSystemCreate implements FileExecCallable {

		@Override
		public void doExecute(File _file) {
			// TODO Auto-generated method stub
			taOutput.setText("Creating a new "+_file.getAbsolutePath());
		}

		@Override
		public void doExecute(GlobalContainer  gc) {
			// TODO Auto-generated method stub
			
		}
		
	}
	public class CloudSend  implements FileExecCallable {
		public void doExecute(File _file) {
			// TODO Auto-generated method stub
			taOutput.setText("\nSending the File Object to the cloud"+_file.getAbsolutePath());
		}

		@Override
		public void doExecute(GlobalContainer gc) {
			String returnString=null;
			try {
				
			
				KWMessageWrapper kmw  = new KWMessageWrapper(gc);
				kmw.Send();
				  
				returnString = kmw.DescribeEachItemString();
				System.out.println("\nreturn string:\n"+returnString);
			
				
				gc.CloudSend();
			} catch (StateOperationException soe) {
				soe.print(taOutput);
			} catch (IOException ioe) {
				taOutput.append("\nError: ioe"+ioe.toString());
			}
		
			if (returnString !=null) {
			taOutput.append("\n"+returnString);
			}
			
			
			taOutput.append("\nCloud send successful");
			// TODO Auto-generated method stub
			
		}
		
	}
	public class FileExecutionStatus {
		private  FileStateType fst=null;
		private  FileLevelService fls;
		private String actionLable=null;
		private String descripition=null;
		private String errorLabel=null;
		public FileExecCallable fec = null;
		public FileExecutionStatus(FileLevelService _fls,FileStateType _fst,  
				String actionLabel, String description, String errorLabel) {
		  fst = _fst;
		  fls =_fls;
		  if (fst==FileStateType.PROVISION && fls == FileLevelService.SYSTEM) {
			 fec = new FileSetWorkingDirectory();
			 
		  } else if (fst==FileStateType.CREATE && fls == FileLevelService.FILE) {
			  fec = new FileSystemCreate();
			  
		  }else if (fst==FileStateType.SEND && fls == FileLevelService.CLOUD) {
			  fec = new CloudSend();
			  
		  }
		  
		}
		
		
	}
}
