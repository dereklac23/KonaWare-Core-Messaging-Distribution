package konaware.client.gui;

import konaware.util.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import konaware.util.AtomException;
import konaware.util.GlobalContainer;
import konaware.util.KWAtom;
import konaware.util.KWMessageWrapper;
import konaware.util.StateOperation;
import konaware.util.RealmRender;

/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/ 

 


public class ClientRealmBrowsing extends JPanel {
    
    private PanelTopGui panelTopGui=null;
    RealmBrowser realmBrowser=null;
    RealmTools   realmTools=null;
    private ClientMenuDevelopment cms =null;
    private int width=0, height=0;
    
	public ClientRealmBrowsing(int _width, int _height) {
		    width=_width;
		    height=_height;
		    //setLayout(new FlowLayout());
		    realmBrowser = new RealmBrowser(_width, _height);
		    realmTools = new RealmTools(25, 400);
		    //cms = new ClientMenuSystem();
            add(BorderLayout.NORTH, new PanelTopGui());
          //  add(BorderLayout.CENTER, cms= new ClientMenuSystem());
            realmBrowser.setState(RealmBrowser.STATE.INACTIVE);
            realmTools.setState(RealmTools.STATE.INACTIVE);
 	      
	}
	JPanel panelCredential=null, panelURL=null;
	
	 public void setStateClose() {
		 realmBrowser.setState(RealmBrowser.STATE.INACTIVE);
         realmTools.setState(RealmTools.STATE.INACTIVE);
         //cms.setStateClose();
         
         realmBrowser.dispose();
         realmTools.dispose();
	 }
	 private GlobalContainer globalContainerL2=null;
	 private RealmRender realmRender ;
	 public class PanelTopGui extends JPanel {
			public PanelTopGui() {
				GridLayout gridLayout = new GridLayout(2,1);
		        GridBagConstraints c = new GridBagConstraints();
		        setFont(new Font("SansSerif", Font.PLAIN, 14));
		        setLayout(gridLayout);
		        
				panelCredential = new JPanel();
				panelURL= new JPanel();
				realmBrowser.panelCredential= panelCredential;
				realmBrowser.panelURL = panelURL;
				panelCredential.add(new JLabel("User name:"));
				panelCredential.add(realmBrowser.jtfUser=new JTextField (12));
				
				panelCredential.add(new JLabel("Password:"));
				panelCredential.add(realmBrowser.jtfPassword=new JTextField (12));
				panelCredential.add(realmBrowser.btnConnect= new JButton("Connect"));
				
				panelURL.add(realmBrowser.jtfURL = new JTextField(35));
		        panelURL.add(realmBrowser.btnSend = new JButton("Send"));
				panelURL.add(realmBrowser.btnTools = new JButton("Tools"));
					
				globalContainerL2 = new GlobalContainer(width, height);
			    realmRender = new RealmRender(globalContainerL2);
				
				//kmw.add(
		        realmBrowser.btnConnect.addActionListener(new ActionListener() {
		            @Override
		            public void actionPerformed(ActionEvent e) {
		            	
		            	realmBrowser.setState(RealmBrowser.STATE.ACTIVE, realmRender);
		            	
		            	//cms.setState(ClientMenuSystem.STATE.ACTIVE);
		            }
		        });
		        
		        realmBrowser.btnTools.addActionListener(new ActionListener() {
		            @Override
		            public void actionPerformed(ActionEvent e) {
		            	
		            	realmTools.setState(RealmTools.STATE.ACTIVE);
		            }
		        });
			
			
		          
			       add(realmBrowser.panelCredential);
			       add(realmBrowser.panelURL);
			       
				
				
			}
	 }
}
	

