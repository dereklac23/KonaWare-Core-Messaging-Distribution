package konaware.client.gui;

import konaware.util.AtomException;
import konaware.util.KWAtom;

public class KWHashMap {
 public KWHashMap() {
	 
 }
 private KWAtom key=null, data=null;
 public void add(KWAtom _akey, KWAtom _adata) throws AtomException {
	 String keyString=null;
	 String dataString=null;
   	 if (_akey ==null ) {
   		 throw new AtomException("Key is null");
   	 } else if (_adata ==null) {
   		 throw new AtomException("Data is null");
   	 } else if ((keyString=_akey.getData()) ==null) {
   		 throw new AtomException("Atom of data key is null");
   		 
   	 } else if ((dataString =_adata.getData())==null) {
   		throw new AtomException("Atom of data is null");
   	 }
     key = _akey;
     data=_adata;
}
 public KWAtom getKey() {
	 return key;
	 
 }
 public KWAtom getData() {
    return data;
}
}