package konaware.util;
import konaware.client.gui.*;

import konaware.*;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

import konaware.KWLauncher;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/


public class PanelUtilCreator {
	 final JFileChooser fileChooser = new JFileChooser();
	 private JButton selectDirTomcat=null;
	 PathUtil pathUtil=new PathUtil();
	 private  enum PANEL_TYPE { BIOS, LOGGING, SERVICES, DEVELOPMENT, DEPLOYMENT, BROWSING};
	 private PanelStruct panelArray [] = new PanelStruct[PANEL_TYPE.values().length];
	 private ClientPanelServices cps;
	 private ClientRealmBrowsing cpb;
	 private ClientMenuDevelopment cmd;
	 private GlobalContainer globalContainerL1 = null; 
	  
	public PanelUtilCreator() {
		
		
		//cpb = new ClientRealmBrowsing();
	}

	/** Returns an ImageIcon, or null if the path was invalid. */
    protected static ImageIcon createImageIcon(String path) {
        java.net.URL imgURL = KWLauncher.class.getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }
    private int ClientRealmBrowsingWidth=400, ClientRealmBrowsingHeight=600;
	public JTabbedPane getTabbedPane() {
		JTabbedPane tabbedPane = new JTabbedPane();
		panelArray[PANEL_TYPE.BIOS.ordinal()] = new PanelStruct("BIOS", "Basic Input and Output", KeyEvent.VK_1);
		tabbedPane.addTab(panelArray[PANEL_TYPE.BIOS.ordinal()].title,panelArray[PANEL_TYPE.BIOS.ordinal()].comp);
		
		panelArray[PANEL_TYPE.LOGGING.ordinal()] = new PanelStruct("Logging", "Polling the Log4J files", KeyEvent.VK_2);
		tabbedPane.addTab(panelArray[PANEL_TYPE.LOGGING.ordinal()].title,panelArray[PANEL_TYPE.LOGGING.ordinal()].comp);
		
		
		panelArray[PANEL_TYPE.SERVICES.ordinal()] = new PanelStruct("Services", "Connect to KonaWare Engine for message relay", KeyEvent.VK_3);
		tabbedPane.addTab(panelArray[PANEL_TYPE.SERVICES.ordinal()].title,panelArray[PANEL_TYPE.SERVICES.ordinal()].comp);
		
		panelArray[PANEL_TYPE.DEVELOPMENT.ordinal()] = new PanelStruct("Layer 1", "Create core KWMessage to be uploaded.", KeyEvent.VK_4);
		tabbedPane.addTab(panelArray[PANEL_TYPE.DEVELOPMENT.ordinal()].title,panelArray[PANEL_TYPE.DEVELOPMENT.ordinal()].comp);

		
		panelArray[PANEL_TYPE.DEPLOYMENT.ordinal()] = new PanelStruct("Layer 2", "Additional KWMessage tags to be sent to cloud.", KeyEvent.VK_5);
		tabbedPane.addTab(panelArray[PANEL_TYPE.DEPLOYMENT.ordinal()].title,panelArray[PANEL_TYPE.DEPLOYMENT.ordinal()].comp);
		
		
		panelArray[PANEL_TYPE.BROWSING.ordinal()] = new PanelStruct("Layer 3", "Callback to receive KWMessage for rendering.", KeyEvent.VK_6);
		tabbedPane.addTab(panelArray[PANEL_TYPE.BROWSING.ordinal()].title,panelArray[PANEL_TYPE.BROWSING.ordinal()].comp);

		
		//Global Init
		globalContainerL1=		new GlobalContainer(GlobalContainer.LEVEL_TYPE.LEVEL1);
		cmd = new ClientMenuDevelopment (globalContainerL1);
		cmd.installGlobalContainer(globalContainerL1);
		
		//ADDING specific GUI to the panes
		
		JPanel panelBIOS =(JPanel)panelArray[PANEL_TYPE.BIOS.ordinal()].comp;
		panelBIOS.removeAll();
		panelBIOS.add(BorderLayout.NORTH, globalContainerL1.getBIOSPanel());
		panelBIOS.add(BorderLayout.CENTER,   getJTablePanel());
		
		
		JPanel panelServices =(JPanel)panelArray[PANEL_TYPE.SERVICES.ordinal()].comp;
		panelServices.removeAll();
		cps = new ClientPanelServices();
		panelServices.add(BorderLayout.NORTH, cps.getPanelURL());
		
		
		JPanel panelDevelopment =(JPanel)panelArray[PANEL_TYPE.DEVELOPMENT.ordinal()].comp;
		panelDevelopment.removeAll();
		panelDevelopment.add(BorderLayout.NORTH, cmd);
		

		
		JPanel panelBrowsingMain = (JPanel) panelArray[PANEL_TYPE.BROWSING.ordinal()].comp;
		panelBrowsingMain.removeAll();
		cpb=new ClientRealmBrowsing(ClientRealmBrowsingWidth,ClientRealmBrowsingHeight);
		panelBrowsingMain.add(BorderLayout.CENTER, cpb);
		
		
		
		
	    
        
		return tabbedPane;
	}
	
   public void setStateClose() {
      cpb.setStateClose();
    
    }
	private JScrollPane getJTablePanel() {
		  
		  String[][] data = {
		            {"1", "C:\\USERS\\DEREK\\ECLIPSE-WORKSPACE", "12/22/2024"},
		            {"2", "E:\\DEV\\HELLOWORLD1", "12/23/2024"},
		            
		        };

		        // Column names
		        String[] columnNames = {"War file", "Directory", "Date"};

		        // Create JTable
		        JTable table = new JTable(data, columnNames);

		        // Add the table to a scroll pane
		        JScrollPane scrollPane = new JScrollPane(table);
		        return scrollPane;
		  
	  }
	 
	 public JPanel getTomcatPanel() {
		 
		    JPanel panel = new JPanel(); // the panel is not visible in output
	        selectDirTomcat= new JButton("Select $TOMCAT directory");
	        panel.add(selectDirTomcat);
	        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	        selectDirTomcat.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                // Show a message dialog when the button is clicked
	            	 int returnVal = fileChooser.showOpenDialog(panel);

	                 if (returnVal == JFileChooser.APPROVE_OPTION) {
	                     File file = fileChooser.getSelectedFile();
	                     //				System.out.println("file dire:"+file.getCanonicalPath());
						if (pathUtil.checkTomcatDirectory(file)) {
							selectDirTomcat.setEnabled(false);
							
						} else {
							System.out.println("$TOMCAT directory not verified");
						}
	                 } else {
	                 }
	            }
	        });

	        return panel;
	  }
}
