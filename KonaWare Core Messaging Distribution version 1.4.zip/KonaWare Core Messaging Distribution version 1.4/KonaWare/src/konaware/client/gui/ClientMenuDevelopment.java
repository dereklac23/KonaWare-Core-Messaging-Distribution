package konaware.client.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class ClientMenuDevelopment extends JPanel {

	public  enum STATE {INACTIVE, ACTIVE};
	private enum MENUTYPE {FILE, EDIT, WINDOW, HELP};
	private STATE state=STATE.INACTIVE;
	
	public ClientMenuDevelopment () {
		state=STATE.ACTIVE;
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1,4));
	    panel.add(new MenuObject( MENUTYPE.FILE));
	    panel.add(new MenuObject( MENUTYPE.EDIT));
	    panel.add(new MenuObject( MENUTYPE.WINDOW));
	    panel.add(new MenuObject( MENUTYPE.HELP));
	  
	    setLayout(new BorderLayout());
	    add(BorderLayout.NORTH, panel);
	    
	    
	  
		
	}
	 private class MenuObject extends JButton {
		 MenuObject(MENUTYPE mt) {
			 if (mt== MENUTYPE.FILE) {
				 super.add(new JButton("File"));				 
				 
			 } else if (mt == MENUTYPE.EDIT) {
				 super.add(new JButton("EDIT"));
				 
			 } else if (mt == MENUTYPE.WINDOW) {
				 super.add(new JButton("Windows"));
			 } else if (mt == MENUTYPE.HELP) {
				 super.add(new JButton("Help"));
			 }
		 }
	 }
}
