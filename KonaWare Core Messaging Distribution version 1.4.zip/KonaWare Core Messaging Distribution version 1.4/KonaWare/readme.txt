

In order to test of the KMP Gateway is working, use the following URL:
http://localhost:8080/KMP/KMP

Should see the following text:

string
KWGateway 0.1
int
4269

Next run the Java Application:

KWLauncher, go to the "Development" tab. Make sure the URL is the same as the KMP Gateway:
http://localhost:8080/KMP/KMP

You see the following responses:
KWGateway 0.1
4269
Response code verified match!
 


This version, "KonaWare Core Messaging.zip" has two options for HTTP pipe transfer: kw-atom and kw-octet-stream. Both are assembled to a KWHashMap using the KWMessageWrapper as an utility.


To deploy the War file after you package it from the konaware-core-api.jar, make you the jar file is located at KMP/src/main/WEB-INF/lib. It has to be a jar file and not extract. Next add the classpath into your build-path. Because the HttpServlet requires servlet.jar make sure you download the servlet.jar file from Apache.

If you don't have the right  classpath correctly, Eclipse will show up in the IDE as unknown API. 
If you don't have KonaWareMessageCore_1.24.jar then Tomcat will complain you do not have not have the konaware.util.* classes.

To package KonaWareMessageCore_1.24.jar (or whatever name you want to call it), use the export option to export the KonaWare directory. They contain the konaware.util dclasses. 

The javadoc is located in KonaWare/doc directory.