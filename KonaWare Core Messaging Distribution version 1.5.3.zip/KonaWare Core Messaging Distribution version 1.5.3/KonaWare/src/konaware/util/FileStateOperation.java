package konaware.util;

import java.util.LinkedList;

/*
 * 
 * The FileStateManager is used to manage the creation of folders and the content at the sub-level for both the Server and
 * the Client.
 * 
 * 
 */
public class FileStateOperation {
   public enum FileStateType {
	   
	   CREATE,	   
	   DELETE,
	   CLEAN,
	   DISPLAY,
	   PROVISION,
	   HALT_SERVICE,
	   RESUME_SERVICE,	   	   
	   
   }
   public enum FileLevelService {
	   KERNEL,
	   SYSTEM,
	   FILE,
	   CLOUD
   }
   
   public FileStateOperation() {
	   
	   LinkedList <FileExecutionStatus> listStatus = new LinkedList<FileExecutionStatus>();
	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.FILE,
			   FileStateType.CREATE, 
			   "Please select the working directory for local file storage.",
			   "The default will be the working directory of the KonaWare distribution upon the process startup.",
			   "Error: There is disk error in the local file storage or working directory."));
	   
	   
	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.SYSTEM,
			   FileStateType.PROVISION, 
			   "Creates a root directory if it does not already exist",
			   "The operation is aborted if the directory already exists. It needs to be manually removed.",
			   "Error: The directory exists. Needs to be manually removed."));
	   
	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.FILE,
			   FileStateType.CLEAN, 
			   "Removes all the content within the root.",
			   "Removes all the files recursively. The content cannot be recovered.\n",               
			   "Error occured during system delete."));
	   

	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.FILE,
			   FileStateType.DISPLAY,
			   "Display at the content within the target directory.",
			   "The target directory can go down to lower levels of the file system."+
			   "Certain content that can be  filtered are highlighted.",
			   "The file(s) is corrupted."));
               
	   listStatus.add(new FileExecutionStatus(
			   FileLevelService.FILE,
			   FileStateType.PROVISION,
			   "Installs artifacts at the  index.xml file ate the root directory.",
			   "The index.xml is installed."+
			   "If the index.xml exists, it is overwritten. Use File-DISPLAY option to check the\n"+
			     "and prompt the user for validation.",
			   "The system is not running until the file system is properly provisioned."));
	   
	   
   }
	public interface FileExecCallable {
		public abstract void doExecute() ;
			
		
	}
	
	public class FileSetWorkingDirectory implements FileExecCallable {

		@Override
		public void doExecute() {
			// TODO Auto-generated method stub
			
		}
		
	}
	public class FileExecutionStatus {
		private  FileStateType fst=null;
		private  FileLevelService fls;
		private String actionLable=null;
		private String descripition=null;
		private String errorLabel=null;
		private FileExecCallable fec = null;
		public FileExecutionStatus(FileLevelService _fls,FileStateType _fst,  
				String actionLabel, String description, String errorLabel) {
		  fst = _fst;
		  fls =_fls;
		  if (fst==FileStateType.PROVISION && fls == FileLevelService.SYSTEM) {
			  
		  }
		  
		}
		
		
	}
}
