package konaware.util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import konaware.client.gui.ClientMenuDevelopment;

public class GlobalContainer {
  private File localDirectory=null;
  private File tomcatDirectory =null;
  public JPanel panel=null;  
  public JButton btnLocal=null, btnTomcat=null;
  //private JTextArea taOutput=null;
  private PathUtil pathUtil = new PathUtil();
  public ClientMenuDevelopment cmd=null;
  
  private JFileChooser fileChooserWorking = new JFileChooser(), fileChooserTomcat = new JFileChooser();
  public GlobalContainer () {
	   panel=new JPanel();
	   fileChooserWorking.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	   
	   fileChooserTomcat.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	   
	   btnLocal= new JButton("Select LOCAL directory for disk storage");	   
       btnLocal.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               // Show a message dialog when the button is clicked
           	 int returnVal = fileChooserWorking.showOpenDialog(panel);

                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooserWorking.getSelectedFile();                    
					if (file.isDirectory()) {
						btnLocal.setEnabled(false);
						fileChooserWorking.setCurrentDirectory(file);
						cmd.setStatus(ClientMenuDevelopment.STATE.ACTIVE,"\nWorking directory has been set properly.");
					} else {
						cmd.setStatus(ClientMenuDevelopment.STATE.INACTIVE,"\nWorking directory not set properly.");
					}
                } else {
                }
           }
       });
  
       
	   btnTomcat= new JButton("Select TOMCAT directory");	   
       btnTomcat.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               // Show a message dialog when the button is clicked
           	 int returnVal = fileChooserTomcat.showOpenDialog(panel);

                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooserTomcat.getSelectedFile();
                   
					if (pathUtil.checkTomcatDirectory(file)) {
						btnTomcat.setEnabled(false);
						fileChooserTomcat.setCurrentDirectory(file);
						
					} else {
						System.out.println("WORKING not set properly.");
					}
                } else {
                }
           }
       });
       panel.add(btnLocal);
       panel.add(btnTomcat);
       
  }
 
  
}
