package konaware.client.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import konaware.util.FileStateOperation;
import konaware.util.GlobalContainer;

public class ClientMenuDevelopment extends JPanel {

	public  enum STATE {PRESYSTEM, INACTIVE, ACTIVE};
	private enum MENUTYPE {FILE, EDIT, WINDOW, HELP};
	private STATE state=STATE.INACTIVE;
	private JTextArea taDisplay = null;
	private FileStateOperation fso= new FileStateOperation();
	private GlobalContainer globalContainer;
	public ClientMenuDevelopment (GlobalContainer gContainer) {
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1,4));
	    panel.add(new MenuObject( MENUTYPE.FILE));
	    panel.add(new MenuObject( MENUTYPE.EDIT));
	    panel.add(new MenuObject( MENUTYPE.WINDOW));
	    panel.add(new MenuObject( MENUTYPE.HELP));
	  
	    setLayout(new BorderLayout());
	    add(BorderLayout.NORTH, panel);
	    add(BorderLayout.CENTER, taDisplay = new JTextArea(20,30));
	    
	    setState(STATE.PRESYSTEM);
	    globalContainer = gContainer;
	    //globalContainer.setOutput(taDisplay);
	}
	 public void setStatus(STATE _st, String _displayString) {
		 setState(_st);
		 taDisplay.setText(_displayString);
	 }
	 public void installGlobalContainer (GlobalContainer gC) {
		 globalContainer = gC;
		 globalContainer.cmd = this;
	 }
	 public void setState(STATE _st) {
		 if (_st == STATE.PRESYSTEM) {
			 state=_st;
			 btnNew.setEnabled(false);
			 btnClose.setEnabled(false);
			 btnSaveAs.setEnabled(false);
			 taDisplay.setText("Working directory is not set.\n"+
			  "Go to the BIOS tab and click on 'Select $WORKING Directory'\n"+
			  "button to select the proper directory.");
		 } 
	 }
	 JButton btnNew=null, btnClose=null, btnSaveAs=null, btnOpen=null; //group file
	 
	 public JPanel getVerticalPanel(String _title, MENUTYPE mt) {
		
		JPanel panel = new JPanel();
		
		if (mt == MENUTYPE.FILE) {
			panel.setLayout(new GridLayout(4,1));;
			panel.add(new JLabel("File") );
			panel.add(btnNew = new JButton("New") );
			panel.add(btnOpen = new JButton("Open"));
			panel.add(btnClose = new JButton("Close") );
			panel.add(btnSaveAs = new JButton("Save As") );
			
			btnNew.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {	            	
	            	
	            }
	     
		
			});
		} else if (mt == MENUTYPE.EDIT) {
			panel.add(new JLabel("Edit") );
		} else if ( mt == MENUTYPE.WINDOW) {
			panel.add(new JLabel("Windows") );
			
		} else if (mt == MENUTYPE.HELP) {
			panel.add( new JLabel("Help") );
		}
		return panel;
		 
	 }
	 
	 class MenuObject extends JButton {
		 
		 MenuObject(MENUTYPE mt) {
			 if (mt== MENUTYPE.FILE) {
				 super.add(getVerticalPanel("File", MENUTYPE.FILE));				 
			 } else if (mt == MENUTYPE.EDIT) {
				 super.add(getVerticalPanel("Edit", MENUTYPE.EDIT));
			 } else if (mt == MENUTYPE.WINDOW) {
				 super.add(getVerticalPanel("Windows", MENUTYPE.WINDOW));
			 } else if (mt == MENUTYPE.HELP) {
				 super.add(getVerticalPanel("HELP", MENUTYPE.HELP));
			 }
		 }
	 }
}
