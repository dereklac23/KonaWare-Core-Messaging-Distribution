package konaware.client.gui;

import java.awt.BorderLayout;


import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/


public class RealmBrowser extends JDialog {
    private int width=0, height=0;
    
    private JPanel panelTopGui=null;
    JTextField jtfUser=null, jtfPassword=null;
    JButton    btnSend=null, btnConnect=null, btnTools=null;
    JTextField jtfURL =null;
    public enum STATE {INACTIVE, ACTIVE};
    public STATE stateCode =STATE.INACTIVE; 
    private CenterCanvas cCanvas=null;
    
    JPanel panelCredential=null, panelURL=null;
    
    
	public RealmBrowser(int _w, int _h) {
		super();
        
	    width=_w; height=_h;
	    JPanel panel =(JPanel) super.getContentPane();  
        panel.add(new CenterCanvas(_w,_h));
		  
		  super.addWindowListener(new WindowAdapter()
		  {
		      @Override
		      public void windowClosing(WindowEvent e)
		      {
		        RealmBrowser rb = (RealmBrowser)e.getWindow();
		        rb.setState(STATE.INACTIVE);
		      }
		  });
		  
		  setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		  panel.setSize(_w, _h);		  
		  super.setSize(_w, _h);
		  
	}
	
	
	 	 
	public void setState(STATE st) {
		if (st == STATE.ACTIVE) {
			jtfUser.setEnabled(false);
			jtfPassword.setEnabled(false);
			btnConnect.setEnabled(false);
			
			btnTools.setEnabled(true);
			jtfURL.setEnabled(true);
			btnSend.setEnabled(true);
			super.setVisible(true);
			
		} else if (st == STATE.INACTIVE) {
			jtfUser.setEnabled(true);
			jtfPassword.setEnabled(true);
			btnConnect.setEnabled(true);
			
			btnTools.setEnabled(false);
			jtfURL.setEnabled(false);
			btnSend.setEnabled(false);
			
			setVisible(false);
			
		}
	}

	 public class CenterCanvas extends JPanel {
		    private Color colorInactive = Color.pink;
		    private Color colorActive = Color.LIGHT_GRAY;
		    private int width=0, height=0;
		    
		    public CenterCanvas(int _w, int _h) {
		     setSize(_w, _h);
			 
		    }
		    @Override
		    protected void paintComponent(Graphics g) {
		        super.paintComponent(g);
		        // Custom drawing code goes here
		        switch (stateCode) {
		        case INACTIVE: g.setColor(colorInactive); break;
		        case ACTIVE: g.setColor(colorActive);break;
				default:
					g.setColor(colorInactive);
					break;
		        }
		        
		        g.fillRect(0, 0, width, height); // Draw a blue rectangle
		    } //paintComponent
		 
		 

		 
	 }
	 class BrowserWindowAdaptor extends WindowAdapter {
		 private RealmBrowser realmBrowser;
		 public BrowserWindowAdaptor (RealmBrowser rb) {
			 realmBrowser=rb;
		 }
	 }
}
