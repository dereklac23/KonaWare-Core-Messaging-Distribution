package wepiano;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.util.Vector;

import javax.swing.DefaultListCellRenderer;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

class CellRenderer extends JLabel implements ListCellRenderer {
  protected ListCellRendererProxy defaultRenderer =null; 
		  
  Vector<String> vectorList=null;
  public CellRenderer (Vector<MidiStructure> vectorList) {
	  super.setSize(new Dimension(100,100));
	  super.setPreferredSize(new Dimension(100,100));
	  setText("label x");
	  //super.updateUI();
	  
  }
  public Component getListCellRendererComponent(JList list, Object value, int index,
      boolean isSelected, boolean cellHasFocus) {
    Font theFont = null;
    Color theForeground = null;
    Icon theIcon = null;
    String theText = null;
    
    JLabel renderer = (JLabel) defaultRenderer.getListCellRendererComponent(list, value, index,
        isSelected, cellHasFocus);
    renderer.setText("hello");
    renderer.setPreferredSize(new Dimension(10, 200));
    System.out.println("cell render invoked"+index);
    if (value instanceof String) {
    	System.out.println("object is string");
    } else     if (value instanceof MidiStructure) {
      MidiStructure mS = (MidiStructure)value;
      
    } else {
      theFont = list.getFont();
      theForeground = list.getForeground();
      theText = "";
    }
    if (!isSelected) {
      renderer.setForeground(theForeground);
    }
    if (theIcon != null) {
      renderer.setIcon(theIcon);
    }
    renderer.setText(theText);
    renderer.setFont(theFont);
    return renderer;
  }


}