package starship.util;

import javax.swing.JTextArea;
import javax.swing.JTextField;

import starship.atom.LocalContainer;
import starship.util.ExecCallable;

//!!InstallGui
public class SOClientInstallGui implements ExecCallable {


public JTextField tfHost=null, tfContext=null, tfServlet=null;
public LocalContainer globalContainerPointer=null, localContainerL1=null;
public JTextArea taDisplay=null;

public SOClientInstallGui (LocalContainer _localContainerL1) {
	localContainerL1 = _localContainerL1;
	globalContainerPointer = _localContainerL1.getGlobalContainer();
	
	
	
	globalContainerPointer=localContainerL1.getGlobalContainer();
	taDisplay=localContainerL1.taTextArea;
	taDisplay.append("hello menu 1:"+localContainerL1.tfHostName.getText());
    

}

@Override
public void doExecute() {
	

	globalContainerPointer.tfServletName =
			localContainerL1.tfServletName;
	globalContainerPointer.tfContextName =
			localContainerL1.tfContextName;
	globalContainerPointer.tfHostName =
			localContainerL1.tfHostName;

	localContainerL1.taTextArea.append("gc level:"+globalContainerPointer.levelNumber.toString());
	
	
}//doExe



}
