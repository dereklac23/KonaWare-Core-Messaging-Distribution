package konaware.client.gui;
import java.awt.GridBagConstraints;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import konaware.util.KWAtom;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/
import konaware.util.KWMessageWrapper;

public class ClientPanelDevelopment extends JPanel {

	public ClientPanelDevelopment() {
		    
		
	}
	JComboBox comboBox =null;
	private String strUrl = "http://localhost:8080/KMP/KMP";
	private JTextField jtfUrl=null;
	String cItem [] = {"Get", "Post","File-Upload"};
	private JPanel getUrlPanel() {
		JPanel jPanel  = new JPanel();
		
		comboBox = new JComboBox (cItem);
		
		
		jtfUrl= new JTextField(35);
		jPanel.setLayout(new FlowLayout());
		jPanel.add(comboBox);
		jPanel.add(jtfUrl);
		jtfUrl.setText(strUrl);
		jPanel.add(jBTNPost = new JButton("Ping"));
		return jPanel;
	}
	private JButton jBTNPost = null;
	private JTextArea jtaOutput=null;
	public JPanel getPanelURL() {
			
			JPanel jPanel = new JPanel();
			
			jPanel.add(getUrlPanel(),BorderLayout.SOUTH );
			jPanel.add(jtaOutput = new JTextArea(20,50), BorderLayout.CENTER);
			GridBagConstraints c = new GridBagConstraints();
			
			
			jBTNPost.addActionListener(new ActionListener() {
		            public void actionPerformed(ActionEvent e) {
		            	
		            	if (cItem[comboBox.getSelectedIndex()].equals("Get")) {
		            		doURIGet();
		            	} else if (cItem[comboBox.getSelectedIndex()].equals("Post")) {
		            	    doURIPost();
		            	} else if (cItem[comboBox.getSelectedIndex()].equals("File-Upload")) {
		            		doFileUploadPost();
		            	}
		            	
		            }
			 }
			 );
			 
			return jPanel;
	}
	private void doFileUploadPost() {
		try {
			KWMessageWrapper kmw  = new KWMessageWrapper(
					new  URI(jtfUrl.getText()),
				   "KMP4","KMP", "File-Upload.png") ;
		} catch (URISyntaxException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println("Error with the file upload");
		}
	}
	 private void doURIPost() {
		try {
			KWMessageWrapper kmw  = new KWMessageWrapper(
				new  URI(jtfUrl.getText()),
			   "KMP4","KMP") ;
			String returnString = kmw.DescribeEachItemString();
			System.out.println("\nreturn string:\n"+returnString);
			jtaOutput.append(returnString);
			
		} catch (Exception e) {
			
			System.out.println("IOE"+e.getMessage());
			e.printStackTrace();
		}
		System.out.println("done with post");
		
			
		
				
		
				
	 }
	 private void doURIConnection2() {
		  URI uri;
		try {
			  uri = new URI(jtfUrl.getText());
			  URL url = uri.toURL();
			  
			  
			  HttpURLConnection con = (HttpURLConnection)url.openConnection(); 
			  con.setRequestMethod("POST");
			  con.setDoOutput(true);
			  PrintWriter pw= new PrintWriter(con.getOutputStream());
			  
			  pw.write("POST /KMP2/KMP HTTP/1.1");
			  pw.write("Host: http://localhost:8080");
			  pw.write("Content-Type: application/x-www-form-urlencoded");
			  pw.write("Content-Length: 27");
			  pw.write("field1=value1&field2=value2");
			  pw.close();
			  
			  
			  BufferedReader in = new BufferedReader(new 
					  InputStreamReader(con.getInputStream()));
				String line =in.readLine();
			  System.out.println(line);
			 
			  
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException ioe) {
		System.out.println(ioe.toString());	
		}
		  
			
		
	 }
	 private void doURIGet() {
		 URI uri;
		try {
			uri = new URI(jtfUrl.getText());
			 KWMessageWrapper kwm = new KWMessageWrapper(uri) ;
			 
			 jtaOutput.append("Get request completed [1]:\n"+kwm.DescribeEachItemString());
			 //jtaOutput.append(kwm.DescribeString());
		} catch (URISyntaxException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 
	 }
	  private void doURIConnection() {
		  try {
		  
		  URI uri = new URI(jtfUrl.getText());
		  
		
		  URL url = uri.toURL();
		  HttpURLConnection con = (HttpURLConnection)url.openConnection(); 
		  con.setRequestMethod("GET");
		  
		  KWAtom atom=null;	  
		  
		  BufferedReader in = new BufferedReader(
				new InputStreamReader(con.getInputStream()));
		        String line;
		         while ((line =in.readLine())!=null)  {
		         
		         atom = new KWAtom (line);
		         
		         if (atom !=null && atom.tokenType!=null) {
		         atom.setData(in.readLine());
		                
		         
		         } else {
		        	 break;
		         }
		         } 		        
		        	        
		        
				in.close();
				con.disconnect();
				StringBuffer sb = new StringBuffer();
				
				 in.close();
				 String targetString =sb.toString();	
				jtaOutput.append(sb.toString());
				if (targetString.equals(KWAtom.HEADER_TEXT+"\n"+KWAtom.HEADER_INT+"\n")) {
					jtaOutput.append(targetString);
					jtaOutput.append("Response code verified match!");
				} else  {
					jtaOutput.append(targetString);
					jtaOutput.append("Response code not matched!");
				}
             
				
	  } catch (Exception e) {
		  e.printStackTrace();
		  jtaOutput.append(e.toString());
	  }
	  
      }

}
