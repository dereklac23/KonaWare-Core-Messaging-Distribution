package konaware.util;

import java.util.LinkedList;

/*
 * 
 * The FileStateManager is used to manage the creation of folders and the content at the sub-level for both the Server and
 * the Client.
 * 
 * 
 */
public class FileStateManager {
   public enum FileStateType {
	   CREATE_ROOT,	   
	   DELETE_ROOT,
	   CLEAN_ROOT,
	   HALT_SERVICE,
	   RESUME_SERVICE,
	   DIR_RECURSIVE,
	   DIR_FILE,
	   TIME
	   
	   
   }
   public FileStateManager() {
	   LinkedList <FileExecutionStatus> listStatus = new LinkedList<FileExecutionStatus>();
	   listStatus.add(new FileExecutionStatus(FileStateType.CLEAN_ROOT, 1,
			   "Creates a root directory if it does not already exist",
			   "Removes the directory and restart from clean slate"));
               
	   
	   
   }
	
	
	public class FileExecutionStatus {
		public FileExecutionStatus(FileStateType fst, int level, String actionLabel, String errorLabel) {
			
		}
		
	}
}
