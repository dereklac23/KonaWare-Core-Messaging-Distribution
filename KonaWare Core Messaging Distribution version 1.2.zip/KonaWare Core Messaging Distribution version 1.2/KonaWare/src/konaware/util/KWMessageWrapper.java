package konaware.util;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import konaware.util.KWAtom.KWTYPE;

/*
 * 
 * The wrapper is used to house the KWHashMap to be transported using a BufferedWriter or
 * BufferedReader. This wrapper is shared for both client and server API.
 * 
 * To use this wrapper as part of the HttpServlet api, put this jar file (KonaWareCoreMessage_1xx.jar)
 * into the WEB-INF/lib. Make sure you do not extract the jar file.
 * 
 * To import on Eclipse, you use the import->file system to package the jar into the WEB/lib 
 * directory. Next, add the path in Build Path -=> Configure Build Path.
 * 
 * 
 * 
 */

public class KWMessageWrapper {
	private PrintWriter printWriter=null;
    StringBuffer returnBuffer = new StringBuffer();
 	int contentLength=27;
 	LinkedList <KWAtom> kwList= new LinkedList<KWAtom>();
	public KWMessageWrapper(URI hostname) throws URISyntaxException, IOException {
	      URL url = hostname.toURL();
		  HttpURLConnection con = (HttpURLConnection)url.openConnection(); 
		  con.setRequestMethod("GET");
		  BufferedReader in = new BufferedReader(
				new InputStreamReader(con.getInputStream()));
		  String token=null;
		       while ((token=in.readLine()) !=null) {
		    	   KWAtom map1 = new KWAtom(token);
			         map1.setData(in);
			         kwList.add( map1);
			         returnBuffer.append("token:"+map1.tokenType +":"+map1.getData());	    	   
		       }
		         
				in.close();
				 
	}

	
/*
 * 
 * If the hostname, context, and servlet name is given, this is a post HttpServlet request.
 * A kw-atom (also known as a James Clear Data Type, is the fundamental building block 
 * of a KWHashMap that is housed in the KWMessageWrapper.
 * Alternative to kw-atom, there is kw-octet-stream which is used for file upload and download. 
 * 
 * 
 */
public KWMessageWrapper(URI hostname, String context, String servletname) 
			 throws URISyntaxException, IOException  {
		
		  URL url = hostname.toURL();		
		  HttpURLConnection con = (HttpURLConnection)url.openConnection(); 
		  con.setRequestMethod("POST");
		  con.setDoOutput(true);
		  PrintWriter pw= new PrintWriter(con.getOutputStream());
		  String header = "POST /"+context+"/"+servletname+" HTTP/1.1"+"\n\n";		  
		  pw.write(header);		  
		  pw.write("Host: "+hostname+"\n");
		  pw.write("Content-Type: application/x-www-form-urlencoded\n");
		  pw.write("Content-Length: "+contentLength+"\n");
		  pw.write("kw-atom");
		  pw.close();
		  KWAtom map=null;	  
		  BufferedReader in = new BufferedReader(
				new InputStreamReader(con.getInputStream()));
		  String token=null;
		  String line=null;
		       while ((token=in.readLine()) !=null) {
		    	   KWAtom map1 = new KWAtom(token);
			         map1.setData(in);
			         kwList.add( map1);
			         line = "token:"+map1.tokenType +":"+map1.getData();
			         returnBuffer.append(line);
			         	    	   
		       }
		         
				in.close();
	}

/*
 * This KWMessageWrapper constructor takes in the file name for file upload and download requests.
 * If the deposition argument is "download" then it is saved to the local client with fileName as the file persistent name. 
 * If the deposition argument is  "upload" then it is uploaded to the HttpServer with the context path being the root and the
 * fileName is as file persistent name. 
 * 
 * 
 */
public KWMessageWrapper(URI hostname, String context, String servletname, String fileName) 
		 throws URISyntaxException, IOException  {
	
	  URL url = hostname.toURL();		
	  HttpURLConnection con = (HttpURLConnection)url.openConnection(); 
	  con.setRequestMethod("POST");
	  con.setDoOutput(true);
	  PrintWriter pw= new PrintWriter(con.getOutputStream());
	  String header = "POST /"+context+"/"+servletname+" HTTP/1.1"+"\n\n";		  
	  pw.write(header);		  
	  pw.write("Host: "+hostname+"\n");
	  pw.write("Content-Type: application/x-www-form-urlencoded\n");
	  pw.write("Content-Length: "+contentLength+"\n");
	  //pw.write("octet-stream");	  
	  pw.write("kw-octet-stream\n");
	  pw.write(fileName+"\n");
	  pw.close();
	  KWAtom map=null;	  
	  BufferedReader in = new BufferedReader(
			new InputStreamReader(con.getInputStream()));
	  String token=null;
	  String line=null;
	       while ((token=in.readLine()) !=null) {
	    	   KWAtom map1 = new KWAtom(token);
		         map1.setData(in);
		         kwList.add( map1);
		         line = "token:"+map1.tokenType +":"+map1.getData();
		         returnBuffer.append(line);
		         	    	   
	       }
	         
			in.close();
}

	public KWMessageWrapper(PrintWriter pw) throws IOException {
		printWriter =pw;
	}
	public void add(String data) {
		KWAtom map = new KWAtom(KWTYPE.STRING);
		map.setData(data);
		kwList.add(map);
	}
	
	
	public void add(long data) {
		KWAtom map = new KWAtom(KWTYPE.LONG);
		map.setData(String.valueOf(data));
		kwList.add(map);
	}

	public void add(double data) {
		KWAtom map = new KWAtom(KWTYPE.DOUBLE);
		map.setData(String.valueOf(data));
		kwList.add(map);
	}

	public void add(float data) {
		KWAtom map = new KWAtom(KWTYPE.FLOAT);
		map.setData(String.valueOf(data));
		kwList.add(map);
	}

	public void add(boolean data) {
		KWAtom map = new KWAtom(KWTYPE.BOOLEAN);
		map.setData(String.valueOf(data));
		kwList.add(map);
	}

	public void add(char data) {
		KWAtom map = new KWAtom(KWTYPE.CHAR);
		map.setData(String.valueOf(data));
		kwList.add(map);
	}

	public void add(short data) {
		KWAtom map = new KWAtom(KWTYPE.SHORT);
		map.setData(String.valueOf(data));
		kwList.add(map);
	}

	public void add(byte data) {
		KWAtom map = new KWAtom(KWTYPE.BYTE);
		map.setData(String.valueOf(data));
		kwList.add(map);
	}

	

	public void Send() throws IOException {
		Iterator iter = kwList.iterator();
		
		while (iter.hasNext()) {
			
			KWAtom atom= (KWAtom)iter.next();
			printWriter.println(atom.tokenType);
			printWriter.println(atom.getData());
			//System.out.println("number of loops"+counter);
			
		}
		
	}
	
	public String DescribeString() {
		return returnBuffer.toString();
	}
	public String DescribeEachItemString() {
	 StringBuffer sbReturn = new StringBuffer();
	 Iterator iter=kwList.listIterator();
	 while (iter.hasNext()) {
		 KWAtom atom = (KWAtom)iter.next();
		 sbReturn.append(atom.tokenType +":"+atom.getData()+"\n");
	 }
	 return sbReturn.toString();
	}

}
