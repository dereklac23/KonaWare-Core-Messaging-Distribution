

In order to test of the KMP Gateway is working, use the following URL:
http://localhost:8080/KMP/KMP

Should see the following text:

string
KWGateway 0.1
int
4269

Next run the Java Application:

KWLauncher, go to the "Development" tab. Make sure the URL is the same as the KMP Gateway:
http://localhost:8080/KMP/KMP. Select the Post or Get Request in the combo box. 

You see the following responses:
KWGateway 0.1
4269
Response code verified match!
 

The source for the server is located in KMP.
The source for the client is located in KonaWare.
The shared library is in Konaware/src/konaware/util

The package KonaWareMessageCore_1.24_01xx.jar contains the shared library for both the server and the client.
This jar needs to be added to WEB-INF/lib directory to be packaged into a war file. The library has to be in a jar
file and not extracted; otherwise, your Servlet will complain the konaware.util.* cannot be located. 
