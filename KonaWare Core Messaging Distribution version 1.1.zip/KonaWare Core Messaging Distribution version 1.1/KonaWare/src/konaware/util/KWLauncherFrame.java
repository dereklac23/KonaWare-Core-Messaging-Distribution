package konaware.util;
import konaware.client.gui.*;
import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

public class KWLauncherFrame extends JFrame {
	PanelUtilCreator puc=null;
	public KWLauncherFrame () {
    super("KonaWare.Installer.Java");
	puc=new PanelUtilCreator();
	
    super.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    super.setSize(600,500);
    
    //JButton button = new JButton("Press");
    //frameMain.getContentPane().add(BorderLayout.NORTH,  panelUtilCreator.getTopPanel()); // Adds Button to content pane of frame
   
    super.getContentPane().add(BorderLayout.CENTER, puc.getTabbedPane());	       
    super.setVisible(true);
    
    super.addWindowListener(new WindowAdapter()
		  {
		      public void windowClosing(WindowEvent e)
		      {
		        //stateState(STATE.INACTIVE); 
		    	  puc.setStateClose();
		        
		      }
		  });
	}
}
